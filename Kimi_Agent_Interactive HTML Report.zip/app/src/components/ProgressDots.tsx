import { motion } from 'framer-motion'

interface Screen {
  id: string
  title: string
}

interface ProgressDotsProps {
  screens: Screen[]
  current: number
  onSelect: (index: number) => void
}

export default function ProgressDots({ screens, current, onSelect }: ProgressDotsProps) {
  return (
    <div className="fixed right-6 top-1/2 -translate-y-1/2 z-50 flex flex-col gap-2.5">
      {screens.map((screen, i) => (
        <motion.button
          key={screen.id}
          onClick={() => onSelect(i)}
          whileHover={{ scale: 1.3 }}
          whileTap={{ scale: 0.9 }}
          className="group relative flex items-center justify-end"
        >
          <motion.div
            className={`w-2.5 h-2.5 rounded-full transition-colors duration-300 ${
              i === current
                ? 'bg-[#00d4aa]'
                : i < current
                ? 'bg-white/40'
                : 'bg-white/15'
            }`}
            animate={i === current ? { scale: [1, 1.3, 1] } : {}}
            transition={{ duration: 1.5, repeat: Infinity }}
          />
          <div className="absolute right-5 px-2.5 py-1 rounded-md glass-panel text-xs text-white/70 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
            {screen.title}
          </div>
        </motion.button>
      ))}
    </div>
  )
}
