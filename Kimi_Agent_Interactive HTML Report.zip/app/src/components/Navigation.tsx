import { motion } from 'framer-motion'
import { ChevronLeft, ChevronRight } from 'lucide-react'

interface NavigationProps {
  current: number
  total: number
  onPrev: () => void
  onNext: () => void
}

export default function Navigation({ current, total, onPrev, onNext }: NavigationProps) {
  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-4">
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={onPrev}
        disabled={current === 0}
        className="w-10 h-10 rounded-full glass-panel flex items-center justify-center text-white/70 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-opacity"
      >
        <ChevronLeft size={20} />
      </motion.button>

      <div className="glass-panel rounded-full px-5 py-2 flex items-center gap-3">
        <span className="text-xs font-medium text-white/50 uppercase tracking-wider">
          {current + 1} / {total}
        </span>
      </div>

      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={onNext}
        disabled={current === total - 1}
        className="w-10 h-10 rounded-full glass-panel flex items-center justify-center text-white/70 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-opacity"
      >
        <ChevronRight size={20} />
      </motion.button>
    </div>
  )
}
