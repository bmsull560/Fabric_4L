import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Code, FileText, HardHat, Headphones } from 'lucide-react'
import AnimatedCounter from '../components/AnimatedCounter'

const segments = [
  {
    id: 'it',
    icon: Code,
    name: 'IT Workers',
    count: 2000,
    hours: 15,
    annualValue: 25.2,
    useCases: [
      'Code generation & debugging',
      'Automated documentation',
      'Ticket triage & resolution',
      'Incident response acceleration',
    ],
    color: '#00d4aa',
  },
  {
    id: 'corporate',
    icon: FileText,
    name: 'Corporate Knowledge',
    count: 4000,
    hours: 10,
    annualValue: 33.6,
    useCases: [
      'Email & meeting automation',
      'Report generation',
      'Data analysis & insights',
      'Cross-team alignment',
    ],
    color: '#00a3e0',
  },
  {
    id: 'field',
    icon: HardHat,
    name: 'Field Technicians',
    count: 3000,
    hours: 6,
    annualValue: 15.1,
    useCases: [
      'Real-time documentation lookup',
      'Safety procedure retrieval',
      'Error-code interpretation',
      'Predictive maintenance insights',
    ],
    color: '#5dade2',
  },
  {
    id: 'cs',
    icon: Headphones,
    name: 'Customer Service',
    count: 1000,
    hours: 8,
    annualValue: 6.7,
    useCases: [
      'Call summarization',
      'Knowledge retrieval',
      'Script generation',
      'Billing explanation automation',
    ],
    color: '#85c1e9',
  },
]

export default function WorkforceScreen() {
  const [active, setActive] = useState<string>('corporate')
  const activeSeg = segments.find((s) => s.id === active) || segments[1]

  return (
    <div className="w-full h-full flex flex-col items-center justify-center px-8 md:px-20 relative">
      <div className="max-w-5xl w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-4"
        >
          <span className="text-[10px] uppercase tracking-[3px] text-[#00d4aa]/70">
            04 / Workforce Model
          </span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-4xl md:text-5xl font-bold text-white mb-3"
        >
          Productivity Across
          <span className="text-gradient"> Every Segment</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="text-lg text-white/50 mb-8 max-w-2xl"
        >
          10,000 employees. Four distinct segments. Each with tailored Copilot
          use cases and measurable productivity gains.
        </motion.p>

        {/* Segments selector */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-8">
          {segments.map((seg, i) => (
            <motion.button
              key={seg.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + i * 0.08 }}
              onClick={() => setActive(seg.id)}
              whileHover={{ y: -2 }}
              className={`glass-panel rounded-xl p-5 text-left transition-all ${
                active === seg.id
                  ? 'border-2'
                  : 'border border-white/10 hover:border-white/20'
              }`}
              style={
                active === seg.id
                  ? { borderColor: seg.color, backgroundColor: `${seg.color}10` }
                  : {}
              }
            >
              <seg.icon
                size={22}
                style={{ color: active === seg.id ? seg.color : 'rgba(255,255,255,0.4)' }}
                className="mb-3"
              />
              <div className="text-white font-semibold text-sm mb-0.5">
                {seg.name}
              </div>
              <div className="text-white/30 text-xs">{seg.count.toLocaleString()} employees</div>
            </motion.button>
          ))}
        </div>

        {/* Active segment detail */}
        <AnimatePresence mode="wait">
          <motion.div
            key={active}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
            className="glass-panel rounded-xl p-6 md:p-8"
            style={{ borderLeft: `4px solid ${activeSeg.color}` }}
          >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Stats */}
              <div className="space-y-4">
                <div>
                  <div className="text-white/40 text-xs uppercase tracking-wider mb-1">
                    Hours Saved / Month
                  </div>
                  <div
                    className="text-3xl font-black"
                    style={{ color: activeSeg.color }}
                  >
                    <AnimatedCounter value={activeSeg.hours} suffix=" hrs" />
                  </div>
                </div>
                <div>
                  <div className="text-white/40 text-xs uppercase tracking-wider mb-1">
                    Annual Value
                  </div>
                  <div
                    className="text-3xl font-black"
                    style={{ color: activeSeg.color }}
                  >
                    <AnimatedCounter
                      value={activeSeg.annualValue}
                      prefix="$"
                      suffix="M"
                      decimals={1}
                    />
                  </div>
                </div>
                <div>
                  <div className="text-white/40 text-xs uppercase tracking-wider mb-1">
                    Headcount
                  </div>
                  <div className="text-2xl font-bold text-white">
                    {activeSeg.count.toLocaleString()}
                  </div>
                </div>
              </div>

              {/* Use cases */}
              <div className="md:col-span-2">
                <h4 className="text-white font-semibold text-sm mb-4">
                  Primary Copilot Use Cases
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {activeSeg.useCases.map((uc, i) => (
                    <motion.div
                      key={uc}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.08 }}
                      className="flex items-center gap-3"
                    >
                      <div
                        className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                        style={{ backgroundColor: activeSeg.color }}
                      />
                      <span className="text-white/60 text-sm">{uc}</span>
                    </motion.div>
                  ))}
                </div>

                {/* Mini bar chart */}
                <div className="mt-6">
                  <div className="text-white/40 text-xs uppercase tracking-wider mb-3">
                    Hours Saved Comparison (All Segments)
                  </div>
                  <div className="flex items-end gap-3 h-24">
                    {segments.map((seg) => (
                      <div key={seg.id} className="flex-1 flex flex-col items-center gap-1.5">
                        <motion.div
                          className="w-full rounded-t-md relative group"
                          style={{ backgroundColor: seg.color }}
                          initial={{ height: 0 }}
                          animate={{ height: `${(seg.hours / 18) * 100}%` }}
                          transition={{ delay: 0.3, duration: 0.6, ease: 'easeOut' }}
                        >
                          <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-[10px] text-white/60 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                            {seg.hours} hrs
                          </div>
                        </motion.div>
                        <span
                          className="text-[9px] uppercase tracking-wider"
                          style={{
                            color: seg.id === active ? seg.color : 'rgba(255,255,255,0.3)',
                          }}
                        >
                          {seg.id}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  )
}
