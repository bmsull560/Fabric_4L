import { motion } from 'framer-motion'
import { ArrowRight, TrendingUp, Zap, Shield } from 'lucide-react'

interface CoverScreenProps {
  onNext: () => void
}

export default function CoverScreen({ onNext }: CoverScreenProps) {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute top-[-20%] right-[-10%] w-[500px] h-[500px] rounded-full border border-white/[0.04]"
          animate={{ rotate: 360 }}
          transition={{ duration: 60, repeat: Infinity, ease: 'linear' }}
        />
        <motion.div
          className="absolute top-[-10%] right-[-5%] w-[350px] h-[350px] rounded-full border border-white/[0.03]"
          animate={{ rotate: -360 }}
          transition={{ duration: 45, repeat: Infinity, ease: 'linear' }}
        />
        <motion.div
          className="absolute bottom-[10%] left-[-5%] w-[300px] h-[300px] rounded-full bg-[#00d4aa]/[0.03] blur-3xl"
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
        />
        {/* Floating particles */}
        {Array.from({ length: 12 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 rounded-full bg-[#00d4aa]/30"
            style={{
              left: `${10 + Math.random() * 80}%`,
              top: `${10 + Math.random() * 80}%`,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0.2, 0.6, 0.2],
            }}
            transition={{
              duration: 3 + Math.random() * 3,
              repeat: Infinity,
              delay: Math.random() * 3,
              ease: 'easeInOut',
            }}
          />
        ))}
      </div>

      {/* Accent bar left */}
      <motion.div
        className="absolute left-0 top-0 w-1.5 h-full"
        style={{
          background: 'linear-gradient(180deg, #00d4aa 0%, #0066cc 50%, #00a3e0 100%)',
        }}
        initial={{ scaleY: 0 }}
        animate={{ scaleY: 1 }}
        transition={{ duration: 1.2, ease: 'easeOut' }}
      />

      {/* Content */}
      <div className="relative z-10 text-center max-w-3xl px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.8 }}
          className="mb-8"
        >
          <span className="inline-block text-[10px] uppercase tracking-[4px] text-[#00d4aa] border border-[#00d4aa]/30 px-5 py-2 rounded-full">
            Executive Business Case
          </span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="text-5xl md:text-7xl font-black text-white leading-tight mb-4"
        >
          Microsoft 365
          <br />
          <span className="text-gradient">Copilot</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7, duration: 0.8 }}
          className="text-lg md:text-xl text-white/60 font-light mb-4 leading-relaxed"
        >
          Enterprise ROI Analysis & Strategic Investment Framework
          <br />
          for a 10,000-Employee Public Utility
        </motion.p>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9, duration: 0.8 }}
          className="flex items-center justify-center gap-6 text-sm text-white/40 mb-12"
        >
          <span className="flex items-center gap-1.5">
            <Zap size={14} className="text-[#00d4aa]" />
            Electric & Gas Utility
          </span>
          <span className="w-1 h-1 rounded-full bg-white/20" />
          <span className="flex items-center gap-1.5">
            <Shield size={14} className="text-[#00d4aa]" />
            4 States
          </span>
          <span className="w-1 h-1 rounded-full bg-white/20" />
          <span className="flex items-center gap-1.5">
            <TrendingUp size={14} className="text-[#00d4aa]" />
            6,000 Users
          </span>
        </motion.div>

        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.1, duration: 0.8 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onNext}
          className="group inline-flex items-center gap-3 bg-[#00d4aa] hover:bg-[#00d4aa]/90 text-[#060e1a] font-semibold px-8 py-4 rounded-full transition-colors"
        >
          Begin the Journey
          <ArrowRight
            size={18}
            className="group-hover:translate-x-1 transition-transform"
          />
        </motion.button>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.4, duration: 0.8 }}
          className="mt-8 text-[10px] uppercase tracking-[3px] text-white/25"
        >
          Board Confidential &mdash; May 2025
        </motion.p>
      </div>
    </div>
  )
}
