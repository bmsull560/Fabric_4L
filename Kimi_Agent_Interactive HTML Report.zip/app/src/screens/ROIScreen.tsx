import { motion } from 'framer-motion'
import AnimatedCounter from '../components/AnimatedCounter'

const stats = [
  { value: 2614, prefix: '', suffix: '%', label: 'Base Case ROI', color: '#00d4aa' },
  { value: 72, prefix: '$', suffix: 'M', label: 'Annual Benefit', color: '#00a3e0' },
  { value: 5.1, prefix: '', suffix: ' months', label: 'Payback Period', decimals: 1, color: '#00d4aa' },
  { value: 96000, prefix: '', suffix: '', label: 'Hours Saved / Month', color: '#00a3e0' },
]

export default function ROIScreen() {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center px-8 md:px-20 relative">
      <div className="max-w-5xl w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-4"
        >
          <span className="text-[10px] uppercase tracking-[3px] text-[#00d4aa]/70">
            03 / ROI Overview
          </span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-4xl md:text-5xl font-bold text-white mb-3"
        >
          The Numbers Speak for
          <span className="text-gradient"> Themselves</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="text-lg text-white/50 mb-10 max-w-2xl"
        >
          Validated by Forrester TEI studies and Microsoft internal analytics.
          These are not projections — they are documented outcomes.
        </motion.p>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + i * 0.1 }}
              className="glass-panel rounded-xl p-6 text-center"
              style={{ borderTop: `3px solid ${s.color}` }}
            >
              <div
                className="text-3xl md:text-4xl font-black mb-2"
                style={{ color: s.color }}
              >
                <AnimatedCounter
                  value={s.value}
                  prefix={s.prefix}
                  suffix={s.suffix}
                  decimals={s.decimals || 0}
                  duration={2500}
                />
              </div>
              <div className="text-white/40 text-xs uppercase tracking-wider">
                {s.label}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Source validation bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.0 }}
          className="glass-panel rounded-xl p-6"
        >
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div>
              <h4 className="text-white font-semibold text-sm mb-1">
                Validated Sources
              </h4>
              <p className="text-white/40 text-xs">
                Forrester Total Economic Impact (TEI) Study | Microsoft Internal
                Analytics | Industry Benchmark Surveys
              </p>
            </div>
            <div className="flex gap-6 text-center">
              <div>
                <div className="text-xl font-bold text-[#00d4aa]">116%</div>
                <div className="text-[10px] text-white/40 uppercase">
                  Forrester ROI
                </div>
              </div>
              <div>
                <div className="text-xl font-bold text-[#00a3e0]">353%</div>
                <div className="text-[10px] text-white/40 uppercase">
                  SMB Max ROI
                </div>
              </div>
              <div>
                <div className="text-xl font-bold text-[#00d4aa]">2.6%</div>
                <div className="text-[10px] text-white/40 uppercase">
                  Revenue Lift
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
