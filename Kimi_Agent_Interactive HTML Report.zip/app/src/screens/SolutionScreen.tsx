import { motion } from 'framer-motion'
import { Brain, Clock, LineChart, Lock, Sparkles } from 'lucide-react'

const capabilities = [
  {
    icon: Brain,
    title: 'Automated Intelligence',
    desc: 'Drafts emails, summarizes meetings, creates documents, analyzes data, builds presentations — automatically.',
  },
  {
    icon: Clock,
    title: 'Time Reclamation',
    desc: '9 hours saved per user per month. Across 6,000 users, that is 54,000 hours recaptured monthly.',
  },
  {
    icon: LineChart,
    title: 'Revenue Acceleration',
    desc: 'AI-generated proposals, CRM insights, and faster follow-up drive 2.5% improvement in win rates.',
  },
  {
    icon: Lock,
    title: 'Enterprise-Grade Security',
    desc: 'Built on Microsoft Graph with Zero Trust architecture. Your data never leaves your tenant.',
  },
  {
    icon: Sparkles,
    title: 'Decision Quality',
    desc: 'Faster access to organizational knowledge, better cross-team alignment, higher-quality strategic decisions.',
  },
]

export default function SolutionScreen() {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center px-8 md:px-20 relative">
      <div className="max-w-5xl w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-4"
        >
          <span className="text-[10px] uppercase tracking-[3px] text-[#00d4aa]/70">
            02 / The Solution
          </span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-4xl md:text-5xl font-bold text-white mb-4"
        >
          Meet Microsoft 365
          <span className="text-gradient"> Copilot</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="text-lg text-white/50 mb-10 max-w-2xl"
        >
          Not a discretionary upgrade. A strategic operational multiplier that
          addresses every challenge facing the modern utility.
        </motion.p>

        {/* Hero stat */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5 }}
          className="glass-panel rounded-2xl p-8 mb-8 text-center border-[#00d4aa]/20"
        >
          <div className="text-6xl font-black text-gradient mb-2">
            50% Faster
          </div>
          <p className="text-white/50 text-sm">
            Completion of repetitive work — summaries, reports, emails, analysis
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {capabilities.map((cap, i) => (
            <motion.div
              key={cap.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 + i * 0.08 }}
              whileHover={{ y: -3 }}
              className="glass-panel rounded-xl p-5 hover:border-[#00d4aa]/25 transition-all"
            >
              <cap.icon size={22} className="text-[#00d4aa] mb-3" />
              <h3 className="text-white font-semibold text-sm mb-1.5">
                {cap.title}
              </h3>
              <p className="text-white/40 text-xs leading-relaxed">
                {cap.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  )
}
