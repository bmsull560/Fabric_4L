import { motion } from 'framer-motion'
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'
import AnimatedCounter from '../components/AnimatedCounter'

const monteCarloData = Array.from({ length: 40 }, (_, i) => {
  const x = i / 39
  // Simulate a right-skewed log-normal-ish distribution
  const val = 410 + Math.exp(-Math.pow(x - 0.45, 2) / 0.04) * 2500 + (x > 0.4 ? (x - 0.4) * 800 : 0)
  return {
    roi: Math.round(val),
    probability: Math.max(1, Math.round(Math.exp(-Math.pow(x - 0.45, 2) / 0.04) * 100 + Math.random() * 5)),
  }
})

const percentiles = [
  { p: '1st', roi: 410, label: 'Worst Case', desc: 'Still strongly positive' },
  { p: '25th', roi: 1980, label: 'Below Average', desc: 'Exceptional outcome' },
  { p: '50th', roi: 2615, label: 'Median', desc: 'Most likely' },
  { p: '95th', roi: 3980, label: 'Best Case', desc: 'High adoption' },
]

const stressTests = [
  { scenario: '10% productivity only', roi: 492, color: '#85c1e9' },
  { scenario: 'License rises to $40/user', roi: 2095, color: '#5dade2' },
  { scenario: '50% drop + higher cost', roi: 1059, color: '#00a3e0' },
  { scenario: 'Everything goes wrong', roi: 890, color: '#00d4aa' },
]

export default function RiskScreen() {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center px-8 md:px-20 relative">
      <div className="max-w-5xl w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-4"
        >
          <span className="text-[10px] uppercase tracking-[3px] text-[#00d4aa]/70">
            06 / Risk Analysis
          </span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-4xl md:text-5xl font-bold text-white mb-3"
        >
          Stress-Tested to
          <span className="text-gradient"> Withstand Anything</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="text-lg text-white/50 mb-6 max-w-2xl"
        >
          10,000 Monte Carlo iterations. Even catastrophic scenarios yield
          extraordinary returns.
        </motion.p>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Chart */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="lg:col-span-2 glass-panel rounded-xl p-5"
          >
            <h4 className="text-white font-semibold text-sm mb-1">
              Monte Carlo ROI Distribution (10,000 Runs)
            </h4>
            <p className="text-white/30 text-xs mb-4">
              Probability density of ROI outcomes
            </p>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={monteCarloData}>
                <XAxis
                  dataKey="roi"
                  tick={{ fill: 'rgba(255,255,255,0.35)', fontSize: 9 }}
                  tickFormatter={(v) => `${Math.round(v / 100) * 100}%`}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis hide />
                <Tooltip
                  contentStyle={{
                    background: '#0f1d2e',
                    border: '1px solid rgba(255,255,255,0.1)',
                    borderRadius: 8,
                    fontSize: 11,
                    color: '#fff',
                  }}
                  formatter={(_value: number, _n: string, props: { payload?: { roi?: number } }) => [
                    `ROI: ~${props?.payload?.roi?.toLocaleString()}%`,
                    '',
                  ]}
                  labelStyle={{ display: 'none' }}
                />
                <Area
                  type="monotone"
                  dataKey="probability"
                  stroke="#00d4aa"
                  fill="#00d4aa"
                  fillOpacity={0.2}
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Percentiles */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6 }}
            className="glass-panel rounded-xl p-5"
          >
            <h4 className="text-white font-semibold text-sm mb-4">
              Percentile Analysis
            </h4>
            <div className="space-y-3">
              {percentiles.map((p, i) => (
                <motion.div
                  key={p.p}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.7 + i * 0.08 }}
                  className="flex items-center justify-between"
                >
                  <div>
                    <span className="text-white/50 text-xs">{p.p} &mdash; </span>
                    <span className="text-white/70 text-xs">{p.label}</span>
                  </div>
                  <div className="text-right">
                    <div className="text-[#00d4aa] font-bold text-sm">
                      +<AnimatedCounter value={p.roi} suffix="%" />
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
            <div className="mt-4 pt-4 border-t border-white/10">
              <div className="text-[#00d4aa] text-xs font-semibold mb-1">
                P(ROI &gt; 0) = 100%
              </div>
              <div className="text-white/30 text-xs">
                Positive ROI is mathematically certain
              </div>
            </div>
          </motion.div>
        </div>

        {/* Stress tests */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="mt-4"
        >
          <h4 className="text-white font-semibold text-sm mb-3">
            CFO-Level Stress Tests
          </h4>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {stressTests.map((test, i) => (
              <motion.div
                key={test.scenario}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.9 + i * 0.08 }}
                className="glass-panel rounded-lg p-4"
                style={{ borderTop: `3px solid ${test.color}` }}
              >
                <div className="text-lg font-bold mb-1" style={{ color: test.color }}>
                  <AnimatedCounter value={test.roi} suffix="%" />
                </div>
                <div className="text-white/40 text-[10px] leading-tight">
                  {test.scenario}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  )
}
