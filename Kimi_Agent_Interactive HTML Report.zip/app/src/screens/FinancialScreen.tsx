import { useState } from 'react'
import { motion } from 'framer-motion'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts'
import AnimatedCounter from '../components/AnimatedCounter'

type Scenario = 'conservative' | 'base' | 'optimistic'

const scenarios: Record<Scenario, { name: string; benefit: number; cost: number; roi: number; payback: number; color: string }> = {
  conservative: { name: 'Conservative', benefit: 66.56, cost: 2.56, roi: 2500, payback: 5.5, color: '#85c1e9' },
  base: { name: 'Base Case', benefit: 72.01, cost: 2.56, roi: 2614, payback: 5.1, color: '#00a3e0' },
  optimistic: { name: 'Optimistic', benefit: 77.46, cost: 2.56, roi: 2926, payback: 4.8, color: '#00d4aa' },
}

const breakdownData = [
  { name: 'Productivity', value: 57.12, fill: '#00d4aa' },
  { name: 'Truck Rolls', value: 5.5, fill: '#00a3e0' },
  { name: 'Customer Svc', value: 3.5, fill: '#5dade2' },
  { name: 'Trading', value: 4.0, fill: '#85c1e9' },
  { name: 'Outage', value: 2.25, fill: '#aed6f1' },
]

export default function FinancialScreen() {
  const [scenario, setScenario] = useState<Scenario>('base')
  const s = scenarios[scenario]

  return (
    <div className="w-full h-full flex flex-col items-center justify-center px-8 md:px-20 relative">
      <div className="max-w-5xl w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-4"
        >
          <span className="text-[10px] uppercase tracking-[3px] text-[#00d4aa]/70">
            05 / Financial Deep Dive
          </span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-4xl md:text-5xl font-bold text-white mb-3"
        >
          The Financial Case Is
          <span className="text-gradient"> Unmistakable</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="text-lg text-white/50 mb-8 max-w-2xl"
        >
          Three scenarios. Even the conservative case delivers transformative returns.
        </motion.p>

        {/* Scenario selector */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="flex gap-2 mb-6"
        >
          {(Object.keys(scenarios) as Scenario[]).map((key) => (
            <button
              key={key}
              onClick={() => setScenario(key)}
              className={`px-5 py-2.5 rounded-lg text-sm font-medium transition-all ${
                scenario === key
                  ? 'text-[#060e1a]'
                  : 'glass-panel text-white/60 hover:text-white'
              }`}
              style={
                scenario === key
                  ? { backgroundColor: scenarios[key].color }
                  : {}
              }
            >
              {scenarios[key].name}
            </button>
          ))}
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Main metrics */}
          <motion.div
            key={`metrics-${scenario}`}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4 }}
            className="lg:col-span-2 glass-panel rounded-xl p-6"
          >
            <div className="grid grid-cols-2 gap-6 mb-6">
              <div>
                <div className="text-white/40 text-xs uppercase tracking-wider mb-2">
                  Total Annual Benefit
                </div>
                <div className="text-4xl font-black" style={{ color: s.color }}>
                  <AnimatedCounter value={s.benefit} prefix="$" suffix="M" decimals={2} />
                </div>
              </div>
              <div>
                <div className="text-white/40 text-xs uppercase tracking-wider mb-2">
                  ROI
                </div>
                <div className="text-4xl font-black" style={{ color: s.color }}>
                  <AnimatedCounter value={s.roi} suffix="%" />
                </div>
              </div>
              <div>
                <div className="text-white/40 text-xs uppercase tracking-wider mb-2">
                  Annual Cost
                </div>
                <div className="text-2xl font-bold text-white">
                  <AnimatedCounter value={s.cost} prefix="$" suffix="M" decimals={2} />
                </div>
              </div>
              <div>
                <div className="text-white/40 text-xs uppercase tracking-wider mb-2">
                  Payback Period
                </div>
                <div className="text-2xl font-bold text-white">
                  <AnimatedCounter value={s.payback} suffix=" months" decimals={1} />
                </div>
              </div>
            </div>

            {/* Cost detail */}
            <div className="border-t border-white/10 pt-4">
              <h4 className="text-white font-semibold text-sm mb-3">
                Annual Cost Breakdown
              </h4>
              <div className="space-y-2">
                {[
                  { label: 'Copilot Licensing (6,000 users @ $30/user/mo)', value: 2.16 },
                  { label: 'Training & Change Management (amortized)', value: 0.40 },
                ].map((item) => (
                  <div
                    key={item.label}
                    className="flex items-center justify-between text-sm"
                  >
                    <span className="text-white/50">{item.label}</span>
                    <span className="text-white font-medium">
                      ${item.value}M
                    </span>
                  </div>
                ))}
                <div className="flex items-center justify-between text-sm border-t border-white/10 pt-2">
                  <span className="text-white font-semibold">Total Annual Cost</span>
                  <span className="text-[#00d4aa] font-bold">$2.56M</span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Bar chart */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6 }}
            className="glass-panel rounded-xl p-5"
          >
            <h4 className="text-white font-semibold text-sm mb-4">
              Benefit Breakdown ($M)
            </h4>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={breakdownData} layout="vertical" margin={{ left: 0, right: 20 }}>
                <XAxis type="number" hide />
                <YAxis
                  dataKey="name"
                  type="category"
                  width={85}
                  tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 10 }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{
                    background: '#0f1d2e',
                    border: '1px solid rgba(255,255,255,0.1)',
                    borderRadius: 8,
                    fontSize: 12,
                    color: '#fff',
                  }}
                  formatter={(value: number) => [`$${value}M`, 'Annual Value']}
                />
                <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={20}>
                  {breakdownData.map((entry, index) => (
                    <Cell key={index} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </motion.div>
        </div>
      </div>
    </div>
  )
}
