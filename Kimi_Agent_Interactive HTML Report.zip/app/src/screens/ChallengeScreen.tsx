import { motion } from 'framer-motion'
import { AlertTriangle, Users, FileText, ShieldAlert, Zap, TrendingUp } from 'lucide-react'

const challenges = [
  {
    icon: TrendingUp,
    title: 'Rising O&M Costs',
    desc: 'Operational and maintenance expenses continue to climb across the sector.',
  },
  {
    icon: Users,
    title: 'Aging Workforce',
    desc: 'Retirements accelerating, institutional knowledge walking out the door.',
  },
  {
    icon: FileText,
    title: 'Regulatory Scrutiny',
    desc: 'Increasing oversight demands better documentation and compliance.',
  },
  {
    icon: Zap,
    title: 'Electrification Demands',
    desc: 'DER complexity growing faster than workforce capacity.',
  },
  {
    icon: ShieldAlert,
    title: 'Cybersecurity Threats',
    desc: 'IT/OT convergence creating new vulnerabilities daily.',
  },
]

export default function ChallengeScreen() {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center px-8 md:px-20 relative">
      <div className="max-w-5xl w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-4"
        >
          <span className="text-[10px] uppercase tracking-[3px] text-white/40">
            01 / The Challenge
          </span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-4xl md:text-5xl font-bold text-white mb-4"
        >
          The Utility Industry Is at a
          <span className="text-gradient"> Crossroads</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="text-lg text-white/50 mb-12 max-w-2xl"
        >
          Five converging pressures are straining operations, increasing costs,
          and threatening reliability. The status quo is no longer sustainable.
        </motion.p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {challenges.map((c, i) => (
            <motion.div
              key={c.title}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + i * 0.1 }}
              whileHover={{ y: -4, transition: { duration: 0.2 } }}
              className="glass-panel rounded-xl p-6 group cursor-default hover:border-[#00d4aa]/30 transition-colors"
            >
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-[#00d4aa]/10 flex items-center justify-center flex-shrink-0 group-hover:bg-[#00d4aa]/20 transition-colors">
                  <c.icon size={20} className="text-[#00d4aa]" />
                </div>
                <div>
                  <h3 className="text-white font-semibold text-sm mb-1.5">
                    {c.title}
                  </h3>
                  <p className="text-white/40 text-xs leading-relaxed">
                    {c.desc}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}

          {/* CTA card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.0 }}
            className="glass-panel rounded-xl p-6 border-[#00d4aa]/20 bg-[#00d4aa]/5"
          >
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-lg bg-[#00d4aa]/20 flex items-center justify-center flex-shrink-0">
                <AlertTriangle size={20} className="text-[#00d4aa]" />
              </div>
              <div>
                <h3 className="text-[#00d4aa] font-semibold text-sm mb-1.5">
                  The Question
                </h3>
                <p className="text-white/50 text-xs leading-relaxed">
                  How do we maintain safe, reliable, affordable service while
                  managing rising costs and workforce transition?
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  )
}
