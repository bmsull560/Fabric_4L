import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Check, Circle, Target, Users, Zap } from 'lucide-react'

const phases = [
  {
    id: 'foundation',
    num: '01',
    title: 'Foundation',
    months: 'Months 1–3',
    users: '1,200–2,100',
    icon: Target,
    color: '#85c1e9',
    tasks: [
      'Establish governance model',
      'Configure security & compliance',
      'Launch pilot with IT, customer service, and corporate teams',
      'Deploy Copilot Analytics baseline',
      'Begin change management program',
    ],
    deliverables: ['Pilot users trained', 'Governance framework', 'Baseline metrics'],
  },
  {
    id: 'scale',
    num: '02',
    title: 'Scale',
    months: 'Months 4–8',
    users: '3,000–6,000',
    icon: Users,
    color: '#00a3e0',
    tasks: [
      'Expand to 6,000 total users',
      'Integrate with knowledge repositories',
      'Develop utility-specific prompt libraries',
      'Launch champions program',
      'Enable CRM and line-of-business integrations',
    ],
    deliverables: ['6,000 active users', 'Custom prompts', 'Adoption dashboards'],
  },
  {
    id: 'optimize',
    num: '03',
    title: 'Optimize',
    months: 'Months 9–12',
    users: '6,000+',
    icon: Zap,
    color: '#00d4aa',
    tasks: [
      'Integrate field operations workflows',
      'Deploy outage management Copilot agents',
      'Build KPI dashboards for ROI tracking',
      'Begin planning Phase 2 expansion',
      'Conduct first-year ROI assessment',
    ],
    deliverables: ['Full deployment', 'ROI dashboard', 'Expansion plan'],
  },
]

export default function RoadmapScreen() {
  const [activePhase, setActivePhase] = useState('scale')
  const phase = phases.find((p) => p.id === activePhase) || phases[1]

  return (
    <div className="w-full h-full flex flex-col items-center justify-center px-8 md:px-20 relative">
      <div className="max-w-5xl w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-4"
        >
          <span className="text-[10px] uppercase tracking-[3px] text-[#00d4aa]/70">
            07 / Implementation
          </span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-4xl md:text-5xl font-bold text-white mb-3"
        >
          A Phased Roadmap to
          <span className="text-gradient"> Success</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="text-lg text-white/50 mb-8 max-w-2xl"
        >
          12 months from zero to full deployment. Each phase builds on the
          last, validating ROI before the next investment.
        </motion.p>

        {/* Timeline */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="glass-panel rounded-xl p-6 mb-6"
        >
          <div className="flex items-center justify-between relative">
            {/* Progress line */}
            <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-white/10 -translate-y-1/2" />
            <motion.div
              className="absolute top-1/2 left-0 h-0.5 bg-gradient-to-r from-[#85c1e9] via-[#00a3e0] to-[#00d4aa] -translate-y-1/2"
              initial={{ width: '0%' }}
              animate={{ width: '100%' }}
              transition={{ delay: 0.8, duration: 1.5, ease: 'easeOut' }}
            />

            {phases.map((p, i) => {
              const isActive = p.id === activePhase
              const isPast = phases.indexOf(phase) > i
              return (
                <motion.button
                  key={p.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6 + i * 0.15 }}
                  onClick={() => setActivePhase(p.id)}
                  className="relative z-10 flex flex-col items-center gap-2 group"
                >
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all ${
                      isActive
                        ? 'border-[#00d4aa] bg-[#00d4aa]/20'
                        : isPast
                        ? 'border-[#00a3e0] bg-[#00a3e0]/10'
                        : 'border-white/20 bg-[#060e1a]'
                    }`}
                  >
                    {isPast ? (
                      <Check size={16} className="text-[#00a3e0]" />
                    ) : (
                      <p.icon
                        size={16}
                        style={{ color: isActive ? '#00d4aa' : 'rgba(255,255,255,0.4)' }}
                      />
                    )}
                  </div>
                  <div className="text-center">
                    <div
                      className={`text-xs font-semibold ${
                        isActive ? 'text-white' : 'text-white/40'
                      }`}
                    >
                      {p.title}
                    </div>
                    <div className="text-[9px] text-white/30">{p.months}</div>
                  </div>
                </motion.button>
              )
            })}
          </div>
        </motion.div>

        {/* Phase detail */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activePhase}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-4"
          >
            <div
              className="glass-panel rounded-xl p-6"
              style={{ borderLeft: `4px solid ${phase.color}` }}
            >
              <div className="flex items-center gap-3 mb-5">
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center"
                  style={{ backgroundColor: `${phase.color}20` }}
                >
                  <phase.icon size={20} style={{ color: phase.color }} />
                </div>
                <div>
                  <h3 className="text-white font-semibold">
                    Phase {phase.num}: {phase.title}
                  </h3>
                  <p className="text-white/40 text-xs">
                    {phase.months} &middot; {phase.users} users
                  </p>
                </div>
              </div>

              <h4 className="text-white/60 text-xs uppercase tracking-wider mb-3">
                Key Activities
              </h4>
              <div className="space-y-2.5">
                {phase.tasks.map((task, i) => (
                  <motion.div
                    key={task}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.06 }}
                    className="flex items-start gap-3"
                  >
                    <Circle
                      size={6}
                      className="mt-1.5 flex-shrink-0"
                      style={{ color: phase.color }}
                      fill={phase.color}
                    />
                    <span className="text-white/60 text-sm">{task}</span>
                  </motion.div>
                ))}
              </div>
            </div>

            <div className="glass-panel rounded-xl p-6">
              <h4 className="text-white/60 text-xs uppercase tracking-wider mb-4">
                Deliverables & KPIs
              </h4>
              <div className="space-y-3 mb-6">
                {phase.deliverables.map((d, i) => (
                  <motion.div
                    key={d}
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2 + i * 0.08 }}
                    className="flex items-center gap-3 px-4 py-3 rounded-lg bg-white/[0.03]"
                  >
                    <Check size={14} className="text-[#00d4aa] flex-shrink-0" />
                    <span className="text-white/70 text-sm">{d}</span>
                  </motion.div>
                ))}
              </div>

              <div className="border-t border-white/10 pt-4">
                <h4 className="text-white/60 text-xs uppercase tracking-wider mb-3">
                  Ongoing KPIs
                </h4>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {[
                    ['Productivity', 'Hrs saved/employee'],
                    ['Operations', 'Truck rolls avoided'],
                    ['Customer', 'AHT reduction'],
                    ['IT', 'Ticket resolution time'],
                  ].map(([cat, metric]) => (
                    <div key={cat} className="px-3 py-2 rounded-md bg-white/[0.03]">
                      <div className="text-white/40 text-[10px] uppercase">{cat}</div>
                      <div className="text-white/60">{metric}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  )
}
