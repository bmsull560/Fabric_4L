import { motion } from 'framer-motion'
import { CheckCircle2, Download, FileText, TrendingUp } from 'lucide-react'
import AnimatedCounter from '../components/AnimatedCounter'

const highlights = [
  { label: 'Total Annual Benefit', value: 72, prefix: '$', suffix: 'M', color: '#00d4aa' },
  { label: 'Annual Cost', value: 2.56, prefix: '$', suffix: 'M', color: '#00a3e0', decimals: 2 },
  { label: 'Net Annual Benefit', value: 69, prefix: '$', suffix: 'M', color: '#00d4aa' },
  { label: '3-Year NPV', value: 171, prefix: '$', suffix: 'M', color: '#00a3e0' },
  { label: 'ROI', value: 2614, prefix: '', suffix: '%', color: '#00d4aa' },
  { label: 'Payback', value: 5.1, prefix: '', suffix: ' months', color: '#00a3e0', decimals: 1 },
]

const reasons = [
  'High-return across all modeled scenarios',
  'Low-risk with 100% probability of positive ROI',
  'Fast payback in under 6 months',
  'Operationally transformative across all functions',
  'Reduces regulatory and compliance risk',
  'Improves customer satisfaction and outage response',
]

export default function FinalScreen() {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center px-8 md:px-20 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-[#00d4aa]/[0.04] blur-3xl" />

      <div className="max-w-5xl w-full relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-4 text-center"
        >
          <span className="text-[10px] uppercase tracking-[3px] text-[#00d4aa]/70">
            08 / Recommendation
          </span>
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-4xl md:text-6xl font-black text-white mb-4 text-center leading-tight"
        >
          Approve Phased Deployment
          <br />
          <span className="text-gradient">to 6,000 Employees</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="text-lg text-white/50 mb-10 max-w-2xl mx-auto text-center"
        >
          This investment delivers material ratepayer value, strengthens system
          reliability, improves safety outcomes, and reduces operational risk.
        </motion.p>

        {/* Stats grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-8"
        >
          {highlights.map((h, i) => (
            <motion.div
              key={h.label}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.6 + i * 0.06 }}
              className="glass-panel rounded-lg p-4 text-center"
              style={{ borderTop: `2px solid ${h.color}` }}
            >
              <div
                className="text-xl md:text-2xl font-black mb-1"
                style={{ color: h.color }}
              >
                <AnimatedCounter
                  value={h.value}
                  prefix={h.prefix}
                  suffix={h.suffix}
                  decimals={h.decimals || 0}
                  duration={2000}
                />
              </div>
              <div className="text-white/35 text-[9px] uppercase tracking-wider leading-tight">
                {h.label}
              </div>
            </motion.div>
          ))}
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-8">
          {/* Why this investment */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.8 }}
            className="glass-panel rounded-xl p-6"
          >
            <h4 className="text-white font-semibold text-sm mb-4 flex items-center gap-2">
              <TrendingUp size={16} className="text-[#00d4aa]" />
              Why This Investment Wins
            </h4>
            <div className="space-y-3">
              {reasons.map((r, i) => (
                <motion.div
                  key={r}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.9 + i * 0.06 }}
                  className="flex items-start gap-3"
                >
                  <CheckCircle2
                    size={16}
                    className="text-[#00d4aa] flex-shrink-0 mt-0.5"
                  />
                  <span className="text-white/60 text-sm">{r}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Regulatory positioning */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.9 }}
            className="glass-panel rounded-xl p-6 border-[#00d4aa]/20"
          >
            <h4 className="text-[#00d4aa] font-semibold text-sm mb-4 flex items-center gap-2">
              <FileText size={16} />
              Regulator-Ready Positioning
            </h4>
            <p className="text-white/50 text-sm leading-relaxed italic mb-4">
              "This investment is a prudent, cost-effective, and operationally
              necessary modernization initiative that directly improves
              reliability, safety, customer service, and compliance. Copilot
              reduces operational costs, accelerates outage restoration,
              enhances workforce safety, and strengthens our ability to meet
              state-mandated performance metrics."
            </p>
            <div className="border-t border-white/10 pt-4">
              <p className="text-white/40 text-xs">
                The benefits flow directly to ratepayers through improved
                service quality and lower long-term operating costs. The
                worst-case scenario still produces substantial ratepayer
                benefit.
              </p>
            </div>
          </motion.div>
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2 }}
          className="text-center"
        >
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="inline-flex items-center gap-3 bg-[#00d4aa] hover:bg-[#00d4aa]/90 text-[#060e1a] font-bold px-10 py-4 rounded-full text-lg transition-colors"
          >
            <Download size={20} />
            Download Full Business Case
          </motion.button>
          <p className="text-white/25 text-xs mt-4">
            Use arrow keys or click the navigation dots to revisit any section
          </p>
        </motion.div>
      </div>
    </div>
  )
}
