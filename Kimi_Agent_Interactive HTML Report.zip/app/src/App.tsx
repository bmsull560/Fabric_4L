import { useState, useCallback, useEffect } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import CoverScreen from './screens/CoverScreen'
import ChallengeScreen from './screens/ChallengeScreen'
import SolutionScreen from './screens/SolutionScreen'
import ROIScreen from './screens/ROIScreen'
import WorkforceScreen from './screens/WorkforceScreen'
import FinancialScreen from './screens/FinancialScreen'
import RiskScreen from './screens/RiskScreen'
import RoadmapScreen from './screens/RoadmapScreen'
import FinalScreen from './screens/FinalScreen'
import Navigation from './components/Navigation'
import ProgressDots from './components/ProgressDots'

const SCREENS = [
  { id: 'cover', title: 'Cover' },
  { id: 'challenge', title: 'The Challenge' },
  { id: 'solution', title: 'The Solution' },
  { id: 'roi', title: 'ROI Overview' },
  { id: 'workforce', title: 'Workforce Model' },
  { id: 'financial', title: 'Financial Deep Dive' },
  { id: 'risk', title: 'Risk Analysis' },
  { id: 'roadmap', title: 'Implementation' },
  { id: 'final', title: 'Recommendation' },
]

const screenVariants = {
  enter: (direction: number) => ({
    x: direction > 0 ? 300 : -300,
    opacity: 0,
    scale: 0.95,
  }),
  center: {
    x: 0,
    opacity: 1,
    scale: 1,
  },
  exit: (direction: number) => ({
    x: direction > 0 ? -300 : 300,
    opacity: 0,
    scale: 0.95,
  }),
}

export default function App() {
  const [currentScreen, setCurrentScreen] = useState(0)
  const [direction, setDirection] = useState(0)

  const goTo = useCallback(
    (index: number) => {
      if (index < 0 || index >= SCREENS.length) return
      setDirection(index > currentScreen ? 1 : -1)
      setCurrentScreen(index)
    },
    [currentScreen]
  )

  const next = useCallback(() => goTo(currentScreen + 1), [currentScreen, goTo])
  const prev = useCallback(() => goTo(currentScreen - 1), [currentScreen, goTo])

  // Keyboard navigation
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === ' ') {
        e.preventDefault()
        next()
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault()
        prev()
      } else if (e.key >= '1' && e.key <= '9') {
        goTo(parseInt(e.key) - 1)
      }
    }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [next, prev, goTo])

  const renderScreen = () => {
    switch (currentScreen) {
      case 0:
        return <CoverScreen onNext={next} />
      case 1:
        return <ChallengeScreen />
      case 2:
        return <SolutionScreen />
      case 3:
        return <ROIScreen />
      case 4:
        return <WorkforceScreen />
      case 5:
        return <FinancialScreen />
      case 6:
        return <RiskScreen />
      case 7:
        return <RoadmapScreen />
      case 8:
        return <FinalScreen />
      default:
        return <CoverScreen onNext={next} />
    }
  }

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#060e1a] grid-bg">
      <AnimatePresence mode="wait" custom={direction}>
        <motion.div
          key={currentScreen}
          custom={direction}
          variants={screenVariants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{
            x: { type: 'spring', stiffness: 300, damping: 30 },
            opacity: { duration: 0.25 },
            scale: { duration: 0.25 },
          }}
          className="absolute inset-0"
        >
          {renderScreen()}
        </motion.div>
      </AnimatePresence>

      <Navigation current={currentScreen} total={SCREENS.length} onPrev={prev} onNext={next} />
      <ProgressDots screens={SCREENS} current={currentScreen} onSelect={goTo} />
    </div>
  )
}
