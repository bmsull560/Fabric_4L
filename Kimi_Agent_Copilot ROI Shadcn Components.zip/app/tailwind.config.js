/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: [
    "./index.html",
    "./src/**/*.{ts,tsx,js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        'bg-primary': '#0A0E1A',
        'bg-secondary': '#111827',
        'bg-tertiary': '#1A2235',
        'bg-quaternary': '#232D42',
        'accent-primary': '#D4A853',
        'accent-primary-hover': '#E5BC6A',
        'accent-primary-muted': 'rgba(212,168,83,0.15)',
        'accent-secondary': '#4ADE80',
        'accent-secondary-muted': 'rgba(74,222,128,0.15)',
        'accent-tertiary': '#F87171',
        'accent-tertiary-muted': 'rgba(248,113,113,0.15)',
        'accent-info': '#60A5FA',
        'accent-info-muted': 'rgba(96,165,250,0.15)',
        'text-primary': '#F0F2F7',
        'text-secondary': '#94A3B8',
        'text-tertiary': '#64748B',
        'text-inverse': '#0A0E1A',
        'chart-1': '#D4A853',
        'chart-2': '#4ADE80',
        'chart-3': '#60A5FA',
        'chart-4': '#A78BFA',
        'chart-5': '#F472B6',
        'chart-6': '#2DD4BF',
        'chart-grid': 'rgba(148,163,184,0.12)',
        'chart-axis': 'rgba(148,163,184,0.3)',
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
      },
      fontFamily: {
        'inter': ['Inter', 'sans-serif'],
        'mono': ['JetBrains Mono', 'monospace'],
      },
      borderRadius: {
        'card': '12px',
        'button': '8px',
        xl: "calc(var(--radius) + 4px)",
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
        xs: "calc(var(--radius) - 6px)",
      },
      spacing: {
        'sidebar': '260px',
        'topbar': '64px',
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
        "glow-pulse": {
          "0%, 100%": { boxShadow: "0 4px 16px rgba(212,168,83,0.2)" },
          "50%": { boxShadow: "0 4px 24px rgba(212,168,83,0.4)" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "glow-pulse": "glow-pulse 3s ease-in-out infinite",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}
