import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard,
  TrendingUp,
  Calculator,
  Users,
  Wrench,
  Dices,
  ShieldAlert,
  GitBranch,
  ArrowUpRight,
  Star,
  Layers,
  Scale,
  Presentation,
  Map,
  ChevronDown,
  Shield,
} from 'lucide-react';

interface NavItem {
  label: string;
  path: string;
  icon: React.ElementType;
}

interface NavGroup {
  label: string;
  items: NavItem[];
}

const navGroups: NavGroup[] = [
  {
    label: 'Overview',
    items: [
      { label: 'Executive Overview', path: '/', icon: LayoutDashboard },
    ],
  },
  {
    label: 'Financial Models',
    items: [
      { label: 'ROI Model', path: '/roi-model', icon: Calculator },
      { label: 'Workforce', path: '/workforce', icon: Users },
      { label: 'Operational Efficiency', path: '/operational', icon: Wrench },
      { label: 'Sensitivity & Risk', path: '/sensitivity-risk', icon: ShieldAlert },
      { label: 'Monte Carlo', path: '/monte-carlo', icon: Dices },
      { label: 'Real Options', path: '/real-options', icon: GitBranch },
      { label: '3-Year Growth', path: '/growth-trajectory', icon: TrendingUp },
      { label: '5-Year Exponential', path: '/exponential', icon: ArrowUpRight },
    ],
  },
  {
    label: 'Strategic',
    items: [
      { label: 'Maturity Model', path: '/maturity', icon: Star },
      { label: 'Enterprise Architecture', path: '/architecture', icon: Layers },
      { label: 'Regulatory & Ratepayer', path: '/regulatory', icon: Scale },
      { label: 'Board Briefing', path: '/board', icon: Presentation },
    ],
  },
  {
    label: 'Execution',
    items: [
      { label: 'Implementation', path: '/implementation', icon: Map },
    ],
  },
];

export default function Sidebar() {
  const location = useLocation();
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({
    Overview: true,
    'Financial Models': true,
    Strategic: true,
    Execution: true,
  });

  const toggleGroup = (label: string) => {
    setExpandedGroups((prev) => ({ ...prev, [label]: !prev[label] }));
  };

  return (
    <aside className="w-sidebar h-screen bg-bg-secondary border-r border-bg-quaternary flex flex-col fixed left-0 top-0 z-50">
      {/* Logo */}
      <div className="h-topbar border-b border-bg-quaternary flex items-center px-4 gap-3">
        <div className="w-9 h-9 rounded-lg bg-accent-primary-muted flex items-center justify-center">
          <Shield className="w-5 h-5 text-accent-primary" />
        </div>
        <Link to="/" className="text-lg font-bold text-accent-primary tracking-tight">
          CopilotROI
        </Link>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4 px-3">
        {navGroups.map((group) => (
          <div key={group.label} className="mb-2">
            <button
              onClick={() => toggleGroup(group.label)}
              className="w-full flex items-center justify-between px-3 py-2 text-label-sm text-text-tertiary hover:text-text-secondary transition-colors"
            >
              <span>{group.label}</span>
              <ChevronDown
                className={`w-3.5 h-3.5 transition-transform duration-200 ${
                  expandedGroups[group.label] ? 'rotate-0' : '-rotate-90'
                }`}
              />
            </button>
            <AnimatePresence initial={false}>
              {expandedGroups[group.label] && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden"
                >
                  {group.items.map((item) => {
                    const isActive = location.pathname === item.path;
                    const Icon = item.icon;
                    return (
                      <Link
                        key={item.path}
                        to={item.path}
                        className={`flex items-center gap-3 px-3 py-2 rounded-lg text-body-md transition-all duration-200 mb-0.5 ${
                          isActive
                            ? 'text-accent-primary bg-accent-primary-muted border-l-[3px] border-accent-primary'
                            : 'text-text-secondary hover:text-text-primary hover:bg-bg-tertiary border-l-[3px] border-transparent'
                        }`}
                      >
                        <Icon className="w-[18px] h-[18px] flex-shrink-0" />
                        <span className="truncate">{item.label}</span>
                      </Link>
                    );
                  })}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </nav>
    </aside>
  );
}
