import type { ReactNode } from 'react';

interface DataCardProps {
  title: string;
  children: ReactNode;
  subtitle?: string;
  actions?: ReactNode;
}

export default function DataCard({ title, children, subtitle, actions }: DataCardProps) {
  return (
    <div className="bg-bg-secondary border border-bg-quaternary rounded-card p-6 hover:border-bg-quaternary/80 transition-colors duration-300">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="text-heading-lg text-text-primary">{title}</h3>
          {subtitle && (
            <p className="text-body-sm text-text-tertiary mt-1">{subtitle}</p>
          )}
        </div>
        {actions && <div className="flex items-center gap-2">{actions}</div>}
      </div>
      <div className="border-t border-bg-quaternary my-4" />
      <div>{children}</div>
    </div>
  );
}
