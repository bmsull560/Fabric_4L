import { Search, Bell, User } from 'lucide-react';

export default function TopBar() {
  return (
    <header className="h-topbar bg-bg-primary border-b border-bg-quaternary flex items-center justify-between px-8 sticky top-0 z-40">
      <div className="flex items-center gap-4">
        <h1 className="text-heading-lg text-text-primary">Executive Overview</h1>
      </div>
      <div className="flex items-center gap-3">
        <button className="w-9 h-9 rounded-button bg-bg-tertiary flex items-center justify-center text-text-secondary hover:text-text-primary hover:bg-bg-quaternary transition-all duration-200">
          <Search className="w-[18px] h-[18px]" />
        </button>
        <button className="w-9 h-9 rounded-button bg-bg-tertiary flex items-center justify-center text-text-secondary hover:text-text-primary hover:bg-bg-quaternary transition-all duration-200 relative">
          <Bell className="w-[18px] h-[18px]" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-accent-tertiary rounded-full" />
        </button>
        <div className="w-9 h-9 rounded-full bg-accent-primary-muted flex items-center justify-center ml-1">
          <User className="w-[18px] h-[18px] text-accent-primary" />
        </div>
      </div>
    </header>
  );
}
