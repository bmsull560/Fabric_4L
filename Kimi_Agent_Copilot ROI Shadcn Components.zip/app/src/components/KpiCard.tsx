import type { LucideIcon } from 'lucide-react';
import { motion } from 'framer-motion';
import NumberAnimation from './NumberAnimation';

export interface KpiCardProps {
  icon: LucideIcon;
  label: string;
  value: number;
  valuePrefix?: string;
  valueSuffix?: string;
  valueDecimals?: number;
  trend?: {
    direction: 'positive' | 'negative';
    text: string;
  };
  subtitle?: string;
  index?: number;
}

export default function KpiCard({
  icon: Icon,
  label,
  value,
  valuePrefix = '',
  valueSuffix = '',
  valueDecimals = 0,
  trend,
  subtitle,
  index = 0,
}: KpiCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.5,
        delay: index * 0.08,
        ease: [0.22, 1, 0.36, 1] as [number, number, number, number],
      }}
      className="bg-bg-secondary border border-bg-quaternary rounded-card p-6 flex flex-col hover:border-accent-primary/30 hover:shadow-[0_4px_24px_rgba(212,168,83,0.08)] transition-all duration-300"
      style={{ transitionTimingFunction: 'cubic-bezier(0.4, 0, 0.2, 1)' }}
    >
      <div className="w-11 h-11 rounded-full bg-accent-primary-muted flex items-center justify-center">
        <Icon className="w-5 h-5 text-accent-primary" />
      </div>
      <span className="text-label-lg text-text-tertiary mt-4">{label}</span>
      <span className="text-mono-lg text-text-primary mt-1">
        <NumberAnimation
          value={value}
          prefix={valuePrefix}
          suffix={valueSuffix}
          decimals={valueDecimals}
        />
      </span>
      {trend && (
        <div className="flex items-center gap-1 mt-2">
          <span
            className={`text-body-sm font-medium ${
              trend.direction === 'positive' ? 'text-accent-secondary' : 'text-accent-tertiary'
            }`}
          >
            {trend.text}
          </span>
        </div>
      )}
      {subtitle && (
        <span className="text-body-sm text-text-tertiary mt-1">{subtitle}</span>
      )}
    </motion.div>
  );
}
