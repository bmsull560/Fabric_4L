import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  CreditCard,
  Users,
  Server,
  TrendingUp,
  DollarSign,
  Clock,
  Wallet,
  ChevronRight,
  Activity,
} from 'lucide-react';
import {
  PieChart as RePieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import KpiCard from '../components/KpiCard';
import DataCard from '../components/DataCard';
import NumberAnimation from '../components/NumberAnimation';
import { Slider } from '../components/ui/slider';
import { Label } from '../components/ui/label';
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from '../components/ui/accordion';

/* ──────────────────────────── animation helpers ──────────────────────────── */

const cardEntrance = {
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] },
};

/* ──────────────────────────── chart tooltip ──────────────────────────── */

const ChartTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-[#111827] border border-[#232D42] rounded-lg px-3 py-2 shadow-[0_4px_20px_rgba(0,0,0,0.3)]">
      {label && <p className="text-body-sm text-text-primary font-medium mb-1">{label}</p>}
      {payload.map((p: any, i: number) => (
        <p key={i} className="text-body-sm" style={{ color: p.color }}>
          {p.name}: {p.value?.toLocaleString?.() ?? p.value}
        </p>
      ))}
    </div>
  );
};

/* ──────────────────────────── productivity pie data ──────────────────────────── */

const productivityPieData = [
  { name: 'IT Workers', value: 31, color: '#60A5FA' },
  { name: 'Corporate Knowledge', value: 42, color: '#D4A853' },
  { name: 'Field Technicians', value: 19, color: '#4ADE80' },
  { name: 'Customer Service', value: 8, color: '#F472B6' },
];

/* ──────────────────────────── annual impact data ──────────────────────────── */

const annualImpactData = [
  { category: 'Productivity Value', conservative: 57.1, base: 69.9, high: 80.6 },
  { category: 'Revenue Uplift', conservative: 9.0, base: 12.9, high: 16.3 },
  { category: 'Operational Savings', conservative: 17.7, base: 22.1, high: 25.4 },
  { category: 'Total Benefit', conservative: 66.6, base: 81.8, high: 97.0 },
];

/* ──────────────────────────── roi by function data ──────────────────────────── */

const roiByFunctionData = [
  { function: 'IT Workers', headcount: 2000, hrsPerMo: 15, rate: 70, annual: 25.2, pct: '31.3%' },
  { function: 'Corporate Knowledge', headcount: 4000, hrsPerMo: 10, rate: 70, annual: 33.6, pct: '41.7%' },
  { function: 'Field Technicians', headcount: 3000, hrsPerMo: 6, rate: 70, annual: 15.1, pct: '18.7%' },
  { function: 'Customer Service', headcount: 1000, hrsPerMo: 8, rate: 70, annual: 6.7, pct: '8.3%' },
];

/* ──────────────────────────── cfo accordion data ──────────────────────────── */

const cfoAccordionData = [
  {
    title: 'Executive Summary',
    content: [
      'Enterprise-wide Copilot deployment at $30/user/month delivers a 2,742% ROI with a 5.2-month payback period.',
      'Annual productivity value of $68.9M is generated from 395,000 hours saved per month across 10,000 employees.',
      'Conservative case still yields 2,211% ROI with payback under 6 months, providing board-ready investment confidence.',
    ],
  },
  {
    title: 'Strategic Rationale',
    content: [
      'AI-augmented productivity is becoming a competitive necessity in the utility sector.',
      'Early deployment creates a sustainable advantage through institutional knowledge capture and workflow optimization.',
      'Microsoft 365 Copilot integrates seamlessly with existing infrastructure, minimizing deployment risk.',
    ],
  },
  {
    title: 'Workforce Segmentation',
    content: [
      'IT Workers (2,000): 15 hrs/mo saved — Code review, documentation, incident response, security analysis.',
      'Corporate Knowledge (4,000): 10 hrs/mo saved — Report generation, data analysis, presentation creation.',
      'Field Technicians (3,000): 6 hrs/mo saved — Work order prep, documentation, parts lookup.',
      'Customer Service (1,000): 8 hrs/mo saved — Response drafting, knowledge base, call summarization.',
    ],
  },
  {
    title: 'Cost Structure',
    content: [
      'Licensing: $2.16M/year (6,000 users at $30/user/month) with option to expand to 10,000 users.',
      'Training: $180K one-time investment, amortized over 3 years.',
      'Change management: $120K annually for adoption support and program management.',
      'Infrastructure: $420K/year for IT support, integration, and security review.',
    ],
  },
  {
    title: 'Financial Analysis',
    content: [
      'NPV at 8% WACC: $171.4M over 3-year horizon.',
      'Base case ROI: 2,742% with $101M net annual benefit.',
      'Conservative ROI: 2,211% (50% productivity realization, 70% revenue, 80% operational).',
      'High case ROI: 3,050% under optimistic adoption and productivity assumptions.',
    ],
  },
  {
    title: 'Operational Impact',
    content: [
      'Truck roll reduction: $8-12M annually through remote troubleshooting.',
      'Outage restoration: 15-25% faster mean-time-to-restore via AI-assisted diagnostics.',
      'Customer service: 20-30% average handle time reduction with AI-suggested responses.',
      'Regulatory reporting: 40% faster compliance report generation.',
    ],
  },
  {
    title: 'Risk Assessment',
    content: [
      'Adoption risk (Medium): Mitigated through phased rollout and change management program.',
      'Technical integration (Low): Native Microsoft 365 integration with existing SSO and security.',
      'Data privacy (Low): Enterprise-grade compliance with utility regulatory requirements.',
      'Vendor lock-in (Low): Part of existing Microsoft enterprise agreement.',
      'Productivity measurement (Medium): Baseline audit and monthly tracking dashboard.',
    ],
  },
  {
    title: 'Implementation Roadmap',
    content: [
      'Months 1-2: Executive alignment, baseline measurement, use-case prioritization.',
      'Months 3-4: Pilot deployment (1,000 users), initial training, feedback collection.',
      'Months 5-7: Phased rollout (6,000 users), full training program, KPI dashboard launch.',
      'Months 8-12: Optimization, expansion planning, advanced use-case development.',
    ],
  },
  {
    title: 'KPI Framework',
    content: [
      'Productivity: Hours saved per user/month, meeting efficiency score, document creation time.',
      'Operations: Truck rolls per week, MTTR, customer satisfaction (CSAT), AHT.',
      'Financial: Monthly benefit tracking, cost per user, cumulative ROI, NPV progression.',
      'Adoption: Daily active users, feature utilization, satisfaction score (NPS).',
    ],
  },
  {
    title: 'CFO Recommendation',
    content: [
      'Approve 6,000-license Copilot deployment at $30/user/month with first-year budget of $2.88M total cost.',
      'Establish monthly ROI tracking with quarterly board reporting on productivity metrics and financial outcomes.',
      'Authorize expansion to 10,000 licenses upon achieving 80% adoption and $50M+ first-year benefit validation.',
    ],
  },
];

/* ──────────────────────────── default inputs ──────────────────────────── */

const defaultInputs = {
  totalEmployees: 10000,
  itWorkers: 2000,
  corporateWorkers: 4000,
  fieldTechnicians: 3000,
  csReps: 1000,
  itHrsSaved: 15,
  corporateHrsSaved: 10,
  fieldHrsSaved: 6,
  csHrsSaved: 8,
  blendedHourlyRate: 65,
  licenseCostPerUser: 30,
  adoptionRate: 85,
  trainingCost: 180000,
  changeMgmtPerYear: 120000,
};

/* ──────────────────────────── ──────────────────────────── */

export default function ROIModel() {
  const [inputs, setInputs] = useState(defaultInputs);

  /* ── real-time calculations ── */
  const outputs = useMemo(() => {
    const itMonthlyHrs = inputs.itWorkers * inputs.itHrsSaved;
    const corpMonthlyHrs = inputs.corporateWorkers * inputs.corporateHrsSaved;
    const fieldMonthlyHrs = inputs.fieldTechnicians * inputs.fieldHrsSaved;
    const csMonthlyHrs = inputs.csReps * inputs.csHrsSaved;
    const totalMonthlyHrs = itMonthlyHrs + corpMonthlyHrs + fieldMonthlyHrs + csMonthlyHrs;

    const adoptionFactor = inputs.adoptionRate / 100;
    const adjustedMonthlyHrs = totalMonthlyHrs * adoptionFactor;

    const dollarPerMonth = adjustedMonthlyHrs * inputs.blendedHourlyRate;
    const annualProductivity = dollarPerMonth * 12;

    const revenueUplift = annualProductivity * 0.187;
    const opSavings = annualProductivity * 0.321;
    const totalAnnualBenefit = annualProductivity + revenueUplift + opSavings;

    const licenseCount = 6000;
    const annualLicenseCost = licenseCount * inputs.licenseCostPerUser * 12;
    const annualTraining = inputs.trainingCost / 3;
    const annualChangeMgmt = inputs.changeMgmtPerYear;
    const annualInfra = 420000;
    const totalAnnualCost = annualLicenseCost + annualTraining + annualChangeMgmt + annualInfra;

    const netBenefit = totalAnnualBenefit - totalAnnualCost;
    const roi = totalAnnualCost > 0 ? (netBenefit / totalAnnualCost) * 100 : 0;
    const paybackMonths = totalAnnualBenefit > 0 ? (totalAnnualCost / (totalAnnualBenefit / 12)) : 0;

    const wacc = 0.08;
    const npv = netBenefit / (1 + wacc) + netBenefit / Math.pow(1 + wacc, 2) + netBenefit / Math.pow(1 + wacc, 3);

    const conservativeProductivity = annualProductivity * 0.5;
    const conservativeRevenue = revenueUplift * 0.7;
    const conservativeOp = opSavings * 0.8;
    const conservativeBenefit = conservativeProductivity + conservativeRevenue + conservativeOp;
    const conservativeROI = totalAnnualCost > 0 ? ((conservativeBenefit - totalAnnualCost) / totalAnnualCost) * 100 : 0;

    const highProductivity = annualProductivity * 1.15;
    const highRevenue = revenueUplift * 1.25;
    const highOp = opSavings * 1.15;
    const highBenefit = highProductivity + highRevenue + highOp;
    const highROI = totalAnnualCost > 0 ? ((highBenefit - totalAnnualCost) / totalAnnualCost) * 100 : 0;

    return {
      totalMonthlyHrs,
      dollarPerMonth,
      annualProductivity,
      revenueUplift,
      opSavings,
      totalAnnualBenefit,
      totalAnnualCost,
      netBenefit,
      roi,
      paybackMonths,
      npv,
      conservativeROI,
      highROI,
      conservativeBenefit,
      annualLicenseCost,
    };
  }, [inputs]);

  const handleSliderChange = (field: keyof typeof inputs, value: number[]) => {
    setInputs((prev) => ({ ...prev, [field]: value[0] }));
  };

  const inputSlider = (label: string, field: keyof typeof inputs, min: number, max: number, unit: string) => (
    <div className="mb-4">
      <div className="flex justify-between items-center mb-1.5">
        <Label className="text-label-sm text-text-tertiary">{label}</Label>
        <span className="text-mono-sm text-accent-primary">
          {unit === '$' ? `$${inputs[field].toLocaleString()}` : `${inputs[field].toLocaleString()}${unit}`}
        </span>
      </div>
      <Slider
        value={[inputs[field]]}
        onValueChange={(v) => handleSliderChange(field, v)}
        min={min}
        max={max}
        step={field === 'blendedHourlyRate' || field === 'licenseCostPerUser' ? 1 : field === 'adoptionRate' ? 1 : 100}
        className="w-full"
      />
    </div>
  );

  /* ── roi summary kpi data ── */
  const roiKpiData = [
    {
      icon: DollarSign,
      label: 'NPV @ 8% WACC',
      value: Math.round(outputs.npv / 1e6 * 10) / 10,
      valuePrefix: '$',
      valueSuffix: 'M',
      valueDecimals: 1,
      trend: { direction: 'positive' as const, text: '3-year NPV' },
      subtitle: 'DCF-adjusted value',
    },
    {
      icon: TrendingUp,
      label: 'RETURN ON INVESTMENT',
      value: Math.round(outputs.roi),
      valueSuffix: '%',
      valueDecimals: 0,
      trend: { direction: 'positive' as const, text: 'Base case' },
      subtitle: '(Benefit - Cost) / Cost',
    },
    {
      icon: Clock,
      label: 'PAYBACK PERIOD',
      value: Math.round(outputs.paybackMonths * 10) / 10,
      valueSuffix: ' months',
      valueDecimals: 1,
      trend: { direction: 'positive' as const, text: 'Sub-6 month' },
      subtitle: 'Months to break-even',
    },
  ];

  return (
    <div className="px-8 py-6 space-y-5">
      {/* ── Page Header ── */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] }}
      >
        <h1 className="text-display-lg text-text-primary font-bold">ROI Financial Model</h1>
        <p className="text-body-md text-text-secondary mt-2">
          Interactive financial engine — adjust inputs to recalculate outputs in real time
        </p>
      </motion.div>

      {/* ── KPI Strip ── */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {roiKpiData.map((kpi, index) => (
          <KpiCard key={kpi.label} {...kpi} index={index} />
        ))}
      </div>

      {/* ── ROI Model Builder ── */}
      <motion.div {...cardEntrance}>
        <DataCard
          title="Enterprise ROI Model Builder"
          subtitle="Interactive financial model — adjust inputs to recalculate outputs"
          actions={
            <div className="flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent-secondary opacity-75" />
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-accent-secondary" />
              </span>
              <span className="text-label-sm text-accent-secondary">LIVE</span>
            </div>
          }
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* ── Left: Inputs ── */}
            <div className="space-y-4">
              <div className="bg-[#1A2235] rounded-lg p-4">
                <h4 className="text-label-lg text-text-tertiary mb-4 flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  Workforce Parameters
                </h4>
                {inputSlider('IT Workers', 'itWorkers', 0, 10000, '')}
                {inputSlider('Corporate Knowledge Workers', 'corporateWorkers', 0, 15000, '')}
                {inputSlider('Field Technicians', 'fieldTechnicians', 0, 10000, '')}
                {inputSlider('Customer Service Reps', 'csReps', 0, 5000, '')}
                <div className="flex justify-between items-center pt-2 border-t border-[#232D42]">
                  <span className="text-label-sm text-text-secondary">Total Employees</span>
                  <span className="text-mono-sm text-text-primary font-semibold">
                    {(inputs.itWorkers + inputs.corporateWorkers + inputs.fieldTechnicians + inputs.csReps).toLocaleString()}
                  </span>
                </div>
              </div>

              <div className="bg-[#1A2235] rounded-lg p-4">
                <h4 className="text-label-lg text-text-tertiary mb-4 flex items-center gap-2">
                  <Activity className="w-4 h-4" />
                  Productivity Assumptions
                </h4>
                {inputSlider('IT Hours Saved/Month', 'itHrsSaved', 0, 30, ' hrs')}
                {inputSlider('Corporate Hours Saved/Month', 'corporateHrsSaved', 0, 25, ' hrs')}
                {inputSlider('Field Hours Saved/Month', 'fieldHrsSaved', 0, 20, ' hrs')}
                {inputSlider('CS Hours Saved/Month', 'csHrsSaved', 0, 20, ' hrs')}
                {inputSlider('Blended Hourly Rate', 'blendedHourlyRate', 30, 150, '$')}
              </div>

              <div className="bg-[#1A2235] rounded-lg p-4">
                <h4 className="text-label-lg text-text-tertiary mb-4 flex items-center gap-2">
                  <Wallet className="w-4 h-4" />
                  Cost Parameters
                </h4>
                {inputSlider('License Cost/User/Month', 'licenseCostPerUser', 20, 50, '$')}
                {inputSlider('Adoption Rate', 'adoptionRate', 50, 100, '%')}
                {inputSlider('Training Cost (One-Time)', 'trainingCost', 0, 500000, '$')}
                {inputSlider('Change Management/Year', 'changeMgmtPerYear', 0, 300000, '$')}
              </div>
            </div>

            {/* ── Right: Outputs ── */}
            <div className="space-y-4">
              {/* Primary Results */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-[#1A2235] rounded-lg p-4 text-center border border-[#232D42]">
                  <span className="text-body-sm text-text-tertiary block">NPV @ 8% WACC</span>
                  <span className="text-mono-lg text-accent-primary block mt-1">
                    $<NumberAnimation value={Math.round(outputs.npv / 1e6 * 10) / 10} decimals={1} suffix="M" />
                  </span>
                </div>
                <div className="bg-[#1A2235] rounded-lg p-4 text-center border border-[#232D42]">
                  <span className="text-body-sm text-text-tertiary block">ROI</span>
                  <span className="text-mono-lg text-accent-primary block mt-1">
                    <NumberAnimation value={Math.round(outputs.roi)} suffix="%" />
                  </span>
                </div>
                <div className="bg-[#1A2235] rounded-lg p-4 text-center border border-[#232D42]">
                  <span className="text-body-sm text-text-tertiary block">Payback Period</span>
                  <span className="text-mono-lg text-accent-primary block mt-1">
                    <NumberAnimation value={Math.round(outputs.paybackMonths * 10) / 10} decimals={1} suffix=" mo" />
                  </span>
                </div>
              </div>

              {/* Annual Financial Breakdown */}
              <div className="bg-[#1A2235] rounded-lg p-4">
                <h4 className="text-label-lg text-text-tertiary mb-3">Annual Financial Breakdown</h4>
                <div className="space-y-2">
                  <div>
                    <div className="flex justify-between text-body-sm mb-1">
                      <span className="text-text-secondary">Productivity Value</span>
                      <span className="text-mono-sm text-accent-primary">${(outputs.annualProductivity / 1e6).toFixed(1)}M</span>
                    </div>
                    <div className="h-2.5 bg-[#232D42] rounded-full overflow-hidden">
                      <motion.div
                        className="h-full rounded-full"
                        style={{ backgroundColor: '#D4A853' }}
                        initial={{ width: 0 }}
                        animate={{ width: `${Math.min((outputs.annualProductivity / outputs.totalAnnualBenefit) * 100, 100)}%` }}
                        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] }}
                      />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-body-sm mb-1">
                      <span className="text-text-secondary">Revenue Uplift</span>
                      <span className="text-mono-sm text-accent-secondary">${(outputs.revenueUplift / 1e6).toFixed(1)}M</span>
                    </div>
                    <div className="h-2.5 bg-[#232D42] rounded-full overflow-hidden">
                      <motion.div
                        className="h-full rounded-full"
                        style={{ backgroundColor: '#4ADE80' }}
                        initial={{ width: 0 }}
                        animate={{ width: `${Math.min((outputs.revenueUplift / outputs.totalAnnualBenefit) * 100, 100)}%` }}
                        transition={{ duration: 0.8, delay: 0.1, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] }}
                      />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-body-sm mb-1">
                      <span className="text-text-secondary">Operational Savings</span>
                      <span className="text-mono-sm text-accent-info">${(outputs.opSavings / 1e6).toFixed(1)}M</span>
                    </div>
                    <div className="h-2.5 bg-[#232D42] rounded-full overflow-hidden">
                      <motion.div
                        className="h-full rounded-full"
                        style={{ backgroundColor: '#60A5FA' }}
                        initial={{ width: 0 }}
                        animate={{ width: `${Math.min((outputs.opSavings / outputs.totalAnnualBenefit) * 100, 100)}%` }}
                        transition={{ duration: 0.8, delay: 0.2, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] }}
                      />
                    </div>
                  </div>
                </div>
                <div className="mt-3 pt-3 border-t border-[#232D42] flex justify-between items-center">
                  <span className="text-body-sm text-text-primary font-semibold">Net Annual Benefit</span>
                  <span className="text-mono-md text-accent-secondary font-semibold">
                    ${(outputs.netBenefit / 1e6).toFixed(1)}M
                  </span>
                </div>
              </div>

              {/* Detailed Output Table */}
              <div className="bg-[#1A2235] rounded-lg p-4">
                <h4 className="text-label-lg text-text-tertiary mb-3">Detailed Outputs</h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <tbody className="divide-y divide-[#232D42]">
                      {[
                        ['Total Monthly Hours Saved', outputs.totalMonthlyHrs.toLocaleString(), 'Sum across all segments'],
                        ['Dollar Value of Productivity', `$${(outputs.dollarPerMonth / 1e6).toFixed(2)}M/month`, 'Hours x blended rate'],
                        ['Annualized Productivity Value', `$${(outputs.annualProductivity / 1e6).toFixed(1)}M`, 'Monthly x 12'],
                        ['Revenue Uplift Value', `$${(outputs.revenueUplift / 1e6).toFixed(1)}M`, 'Sales + trading acceleration'],
                        ['Operational Cost Savings', `$${(outputs.opSavings / 1e6).toFixed(1)}M`, 'Truck rolls + AHT + outage'],
                        ['Total Annual Benefit', `$${(outputs.totalAnnualBenefit / 1e6).toFixed(1)}M`, 'Sum of all benefit categories'],
                        ['Total Annual Cost', `$${(outputs.totalAnnualCost / 1e6).toFixed(2)}M`, 'Licenses + training + change mgmt'],
                        ['Net Annual Benefit', `$${(outputs.netBenefit / 1e6).toFixed(1)}M`, 'Benefit minus cost'],
                        ['ROI (Conservative)', `${Math.round(outputs.conservativeROI).toLocaleString()}%`, 'Low-end assumptions'],
                        ['ROI (Base)', `${Math.round(outputs.roi).toLocaleString()}%`, 'Current inputs'],
                        ['ROI (High)', `${Math.round(outputs.highROI).toLocaleString()}%`, 'Optimistic assumptions'],
                        ['Payback Period', `${outputs.paybackMonths.toFixed(1)} months`, 'Cost / monthly benefit'],
                      ].map(([label, val, note]) => (
                        <tr key={label} className="hover:bg-[#232D42]/30 transition-colors">
                          <td className="py-2 text-body-sm text-text-secondary">{label}</td>
                          <td className="py-2 text-mono-sm text-text-primary text-right font-medium">{val}</td>
                          <td className="py-2 text-body-sm text-text-tertiary text-right hidden sm:table-cell">{note}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </DataCard>
      </motion.div>

      {/* ── ROI Examples by Function + Pie Chart ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* ROI by Function Table */}
        <motion.div {...cardEntrance} transition={{ ...cardEntrance.transition, delay: 0.1 }}>
          <DataCard title="ROI Examples by Function" subtitle="Productivity gain distribution by workforce segment">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-[#1A2235]">
                    <th className="text-label-sm text-text-tertiary text-left py-3 px-3">Function</th>
                    <th className="text-label-sm text-text-tertiary text-right py-3 px-3">Headcount</th>
                    <th className="text-label-sm text-text-tertiary text-right py-3 px-3">Hrs/Mo</th>
                    <th className="text-label-sm text-text-tertiary text-right py-3 px-3">Rate</th>
                    <th className="text-label-sm text-text-tertiary text-right py-3 px-3">Annual Value</th>
                    <th className="text-label-sm text-text-tertiary text-right py-3 px-3">% Share</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#232D42]">
                  {roiByFunctionData.map((row) => (
                    <motion.tr
                      key={row.function}
                      className="hover:bg-[#1A2235]/50 transition-colors"
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <td className="py-3 px-3 text-body-md text-text-primary">{row.function}</td>
                      <td className="py-3 px-3 text-mono-sm text-text-primary text-right">{row.headcount.toLocaleString()}</td>
                      <td className="py-3 px-3 text-mono-sm text-text-primary text-right">{row.hrsPerMo}</td>
                      <td className="py-3 px-3 text-mono-sm text-text-primary text-right">${row.rate}</td>
                      <td className="py-3 px-3 text-mono-sm text-accent-primary text-right">${row.annual}M</td>
                      <td className="py-3 px-3 text-mono-sm text-text-secondary text-right">{row.pct}</td>
                    </motion.tr>
                  ))}
                  <tr className="bg-[#1A2235] font-semibold border-t-2 border-[#232D42]">
                    <td className="py-3 px-3 text-body-md text-text-primary">TOTAL</td>
                    <td className="py-3 px-3 text-mono-sm text-text-primary text-right">10,000</td>
                    <td className="py-3 px-3 text-mono-sm text-text-primary text-right">—</td>
                    <td className="py-3 px-3 text-mono-sm text-text-primary text-right">—</td>
                    <td className="py-3 px-3 text-mono-sm text-accent-primary text-right">$80.6M</td>
                    <td className="py-3 px-3 text-mono-sm text-text-secondary text-right">100%</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </DataCard>
        </motion.div>

        {/* Productivity Distribution Pie Chart */}
        <motion.div {...cardEntrance} transition={{ ...cardEntrance.transition, delay: 0.2 }}>
          <DataCard title="Productivity Gain Distribution" subtitle="Share of annual productivity value by segment">
            <ResponsiveContainer width="100%" height={280}>
              <RePieChart>
                <Pie
                  data={productivityPieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={3}
                  dataKey="value"
                  stroke="none"
                >
                  {productivityPieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip content={<ChartTooltip />} />
                <Legend
                  verticalAlign="bottom"
                  iconType="circle"
                  iconSize={8}
                  formatter={(value: string) => <span className="text-body-sm text-text-secondary ml-1">{value}</span>}
                />
              </RePieChart>
            </ResponsiveContainer>
            <div className="grid grid-cols-4 gap-2 mt-2">
              {productivityPieData.map((seg) => (
                <div key={seg.name} className="text-center">
                  <div className="text-mono-md" style={{ color: seg.color }}>{seg.value}%</div>
                  <div className="text-body-sm text-text-tertiary">{seg.name}</div>
                </div>
              ))}
            </div>
          </DataCard>
        </motion.div>
      </div>

      {/* ── Cost Model Deep Dive ── */}
      <motion.div {...cardEntrance} transition={{ ...cardEntrance.transition, delay: 0.15 }}>
        <DataCard title="Complete Cost Structure" subtitle="Annual cost breakdown by category">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            {/* Licensing */}
            <div className="bg-[#1A2235] rounded-lg p-4 border border-[#232D42]">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-lg bg-accent-primary-muted flex items-center justify-center">
                  <CreditCard className="w-5 h-5 text-accent-primary" />
                </div>
                <div>
                  <span className="text-label-sm text-text-tertiary block">LICENSING MODEL</span>
                  <span className="text-body-sm text-text-secondary">All-Employee Cost Option</span>
                </div>
              </div>
              <div className="text-mono-md text-accent-primary mb-2">${(outputs.annualLicenseCost / 1e6).toFixed(2)}M/year</div>
              <p className="text-body-sm text-text-secondary mb-2">
                6,000 licenses x ${inputs.licenseCostPerUser}/month x 12 months
              </p>
              <div className="h-2 bg-[#232D42] rounded-full overflow-hidden mb-1">
                <div className="h-full bg-accent-primary rounded-full" style={{ width: '60%' }} />
              </div>
              <p className="text-body-sm text-text-tertiary">
                Optional expansion to 10,000: $3.6M/year
              </p>
            </div>

            {/* Training & Change Management */}
            <div className="bg-[#1A2235] rounded-lg p-4 border border-[#232D42]">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-lg bg-accent-info-muted flex items-center justify-center">
                  <Users className="w-5 h-5 text-accent-info" />
                </div>
                <div>
                  <span className="text-label-sm text-text-tertiary block">TRAINING & CHANGE</span>
                  <span className="text-body-sm text-text-secondary">One-time + Recurring</span>
                </div>
              </div>
              <div className="text-mono-md text-accent-primary mb-2">
                ${((inputs.trainingCost / 3 + inputs.changeMgmtPerYear) / 1e3).toFixed(0)}K/year
              </div>
              <p className="text-body-sm text-text-secondary mb-2">
                ${(inputs.trainingCost / 1e3).toFixed(0)}K one-time training + ${(inputs.changeMgmtPerYear / 1e3).toFixed(0)}K annual change management
              </p>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <div className="h-2 bg-accent-info rounded-full" style={{ width: '60%' }} />
                  <span className="text-body-sm text-text-tertiary">One-time</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-2 bg-accent-primary rounded-full" style={{ width: '40%' }} />
                  <span className="text-body-sm text-text-tertiary">Recurring</span>
                </div>
              </div>
            </div>

            {/* Infrastructure */}
            <div className="bg-[#1A2235] rounded-lg p-4 border border-[#232D42]">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-lg bg-accent-secondary-muted flex items-center justify-center">
                  <Server className="w-5 h-5 text-accent-secondary" />
                </div>
                <div>
                  <span className="text-label-sm text-text-tertiary block">INFRASTRUCTURE</span>
                  <span className="text-body-sm text-text-secondary">IT Support & Integration</span>
                </div>
              </div>
              <div className="text-mono-md text-accent-primary mb-2">$420K/year</div>
              <p className="text-body-sm text-text-secondary mb-2">
                IT support overhead, Microsoft 365 integration, security review
              </p>
              <span className="inline-block px-2 py-1 rounded bg-accent-secondary-muted text-accent-secondary text-label-sm">
                Included in enterprise agreement
              </span>
            </div>
          </div>

          {/* Total Cost Banner */}
          <div className="bg-[#1A2235] rounded-lg p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between border border-[#232D42]">
            <div>
              <span className="text-label-lg text-text-tertiary block">Total Annual Cost</span>
              <span className="text-body-sm text-text-secondary">
                Range: $2.16M (6K users) — $3.6M (10K users)
              </span>
            </div>
            <div className="flex items-center gap-4 mt-3 sm:mt-0">
              <span className="text-mono-lg text-accent-primary">
                ${(outputs.totalAnnualCost / 1e6).toFixed(2)}M
              </span>
              <span className="px-2 py-1 rounded bg-accent-secondary-muted text-accent-secondary text-label-sm">
                {(outputs.totalAnnualCost / outputs.totalAnnualBenefit * 100).toFixed(1)}% of benefit
              </span>
            </div>
          </div>
        </DataCard>
      </motion.div>

      {/* ── Conservative ROI Calculation ── */}
      <motion.div {...cardEntrance} transition={{ ...cardEntrance.transition, delay: 0.2 }}>
        <DataCard
          title="Conservative ROI Calculation"
          subtitle="Deliberately understated assumptions for board confidence"
        >
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
            {/* Left: Conservative Benefit */}
            <div className="bg-[#1A2235] rounded-lg p-4 border border-[#232D42]">
              <h4 className="text-label-lg text-text-tertiary mb-3">Annual Benefit (Conservative)</h4>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-body-sm text-text-secondary">Productivity (50% realization)</span>
                  <span className="text-mono-sm text-text-primary">${(outputs.annualProductivity * 0.5 / 1e6).toFixed(1)}M</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-body-sm text-text-secondary">Revenue uplift (70% realization)</span>
                  <span className="text-mono-sm text-text-primary">${(outputs.revenueUplift * 0.7 / 1e6).toFixed(1)}M</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-body-sm text-text-secondary">Operational savings (80% realization)</span>
                  <span className="text-mono-sm text-text-primary">${(outputs.opSavings * 0.8 / 1e6).toFixed(1)}M</span>
                </div>
                <div className="border-t border-[#232D42] pt-2 flex justify-between font-semibold">
                  <span className="text-body-sm text-text-primary">Conservative Total</span>
                  <span className="text-mono-sm text-accent-primary">${(outputs.conservativeBenefit / 1e6).toFixed(2)}M</span>
                </div>
              </div>
            </div>

            {/* Center: Formula */}
            <div className="flex flex-col items-center justify-center text-center">
              <div className="bg-[#0A0E1A] rounded-lg p-5 border border-[#232D42] w-full">
                <p className="text-label-lg text-text-tertiary mb-4">ROI Formula</p>
                <div className="text-mono-md text-text-primary mb-4">
                  ROI = (Benefit - Cost) / Cost x 100
                </div>
                <div className="border-t border-b border-[#232D42] py-3 my-3">
                  <div className="text-mono-md text-text-primary">
                    = (${(outputs.conservativeBenefit / 1e6).toFixed(2)}M - ${(outputs.totalAnnualCost / 1e6).toFixed(2)}M)
                  </div>
                  <div className="text-mono-md text-text-primary">
                    / ${(outputs.totalAnnualCost / 1e6).toFixed(2)}M x 100
                  </div>
                </div>
                <div className="text-mono-lg text-accent-primary font-bold mt-3">
                  = {Math.round(outputs.conservativeROI).toLocaleString()}%
                </div>
              </div>
            </div>

            {/* Right: Annual Cost */}
            <div className="bg-[#1A2235] rounded-lg p-4 border border-[#232D42]">
              <h4 className="text-label-lg text-text-tertiary mb-3">Annual Cost</h4>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-body-sm text-text-secondary">Licensing (6,000 users)</span>
                  <span className="text-mono-sm text-text-primary">${(outputs.annualLicenseCost / 1e6).toFixed(2)}M</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-body-sm text-text-secondary">Training (amortized)</span>
                  <span className="text-mono-sm text-text-primary">${(inputs.trainingCost / 3 / 1e3).toFixed(0)}K</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-body-sm text-text-secondary">Change management</span>
                  <span className="text-mono-sm text-text-primary">${(inputs.changeMgmtPerYear / 1e3).toFixed(0)}K</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-body-sm text-text-secondary">Infrastructure</span>
                  <span className="text-mono-sm text-text-primary">$420K</span>
                </div>
                <div className="border-t border-[#232D42] pt-2 flex justify-between font-semibold">
                  <span className="text-body-sm text-text-primary">Total Cost</span>
                  <span className="text-mono-sm text-accent-primary">${(outputs.totalAnnualCost / 1e6).toFixed(2)}M</span>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Callout */}
          <div className="mt-4 bg-accent-secondary-muted rounded-lg p-4 flex items-center gap-3">
            <ChevronRight className="w-5 h-5 text-accent-secondary flex-shrink-0" />
            <p className="text-body-md text-text-primary">
              Even under conservative assumptions, Copilot delivers a <span className="text-accent-secondary font-semibold">{Math.round(outputs.conservativeROI).toLocaleString()}% return</span> with payback in under 6 months.
            </p>
            <span className="ml-auto px-2 py-1 rounded bg-accent-secondary text-text-inverse text-label-sm flex-shrink-0">
              BOARD-READY
            </span>
          </div>
        </DataCard>
      </motion.div>

      {/* ── Annual Financial Impact Bar Chart ── */}
      <motion.div {...cardEntrance} transition={{ ...cardEntrance.transition, delay: 0.25 }}>
        <DataCard title="Annual Financial Impact by Category" subtitle="Conservative, Base, and High case comparisons">
          <ResponsiveContainer width="100%" height={320}>
            <BarChart data={annualImpactData} barGap={4} barCategoryGap="20%">
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" vertical={false} />
              <XAxis
                dataKey="category"
                stroke="rgba(148,163,184,0.3)"
                tick={{ fill: '#94A3B8', fontSize: 12 }}
                axisLine={{ stroke: 'rgba(148,163,184,0.3)' }}
              />
              <YAxis
                stroke="rgba(148,163,184,0.3)"
                tick={{ fill: '#64748B', fontSize: 12 }}
                axisLine={{ stroke: 'rgba(148,163,184,0.3)' }}
                tickFormatter={(v) => `$${v}M`}
              />
              <Tooltip content={<ChartTooltip />} />
              <Legend
                iconType="circle"
                iconSize={8}
                formatter={(value: string) => <span className="text-body-sm text-text-secondary ml-1">{value}</span>}
              />
              <Bar dataKey="conservative" name="Conservative" fill="#64748B" radius={[4, 4, 0, 0]} />
              <Bar dataKey="base" name="Base Case" fill="#D4A853" radius={[4, 4, 0, 0]} />
              <Bar dataKey="high" name="High Case" fill="#4ADE80" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </DataCard>
      </motion.div>

      {/* ── CFO-Ready Business Case Accordion ── */}
      <motion.div {...cardEntrance} transition={{ ...cardEntrance.transition, delay: 0.3 }}>
        <DataCard
          title="CFO-Ready Business Case"
          subtitle="Complete analytical package for board presentation"
        >
          <Accordion type="single" collapsible className="space-y-2">
            {cfoAccordionData.map((item, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="border border-[#232D42] rounded-lg overflow-hidden data-[state=open]:border-l-[3px] data-[state=open]:border-l-accent-primary"
              >
                <AccordionTrigger className="px-4 py-3 text-body-md text-text-primary hover:no-underline hover:bg-[#1A2235] transition-colors bg-[#1A2235]">
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 rounded-full bg-accent-primary-muted flex items-center justify-center text-label-sm text-accent-primary">
                      {index + 1}
                    </span>
                    {item.title}
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 py-3 bg-[#111827]">
                  <ul className="space-y-2">
                    {item.content.map((line, i) => (
                      <li key={i} className="flex items-start gap-2 text-body-md text-text-secondary">
                        <ChevronRight className="w-4 h-4 text-accent-primary flex-shrink-0 mt-0.5" />
                        <span>{line}</span>
                      </li>
                    ))}
                  </ul>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </DataCard>
      </motion.div>
    </div>
  );
}
