import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Star,
  Diamond,
  TrendingUp,
  Award,
  Zap,
  Target,
  ArrowRight,
  Lightbulb,
  Rocket,
  Users,
  BarChart3,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  ComposedChart,
  Legend,
} from 'recharts';
import DataCard from '../components/DataCard';

// ── Data ────────────────────────────────────────────────────────────

const domains = [
  'Adoption & Usage',
  'Workflow Integration',
  'Data & Systems',
  'Automation & Agents',
  'Workforce & Culture',
  'Governance & Risk',
  'Operations & Reliability',
  'Strategy & Planning',
  'Optimization & Learning',
  'Cognitive Intelligence',
];

const levels = [
  { num: 1, name: 'Initiation', color: '#64748B', gradient: 'from-gray-500 to-gray-600' },
  { num: 2, name: 'Adoption', color: '#60A5FA', gradient: 'from-blue-400 to-blue-500' },
  { num: 3, name: 'Integration', color: '#2DD4BF', gradient: 'from-teal-400 to-teal-500' },
  { num: 4, name: 'Orchestration', color: '#4ADE80', gradient: 'from-green-400 to-green-500' },
  { num: 5, name: 'Acceleration', color: '#A3E635', gradient: 'from-lime-400 to-lime-500' },
  { num: 6, name: 'Expansion', color: '#D4A853', gradient: 'from-amber-400 to-amber-500' },
  { num: 7, name: 'Autonomy', color: '#F59E0B', gradient: 'from-yellow-500 to-amber-500' },
  { num: 8, name: 'Symbiosis', color: '#F97316', gradient: 'from-orange-500 to-orange-600' },
  { num: 9, name: 'Self-Optimization', color: '#EF4444', gradient: 'from-red-500 to-red-600' },
  { num: 10, name: 'Pre-Singularity', color: '#F0F2F7', gradient: 'from-white to-gray-200' },
];

// Cell data from PDF: each row (domain) has which levels are active
// Level 1: A only, 2: A,B, 3: A,B,C,D, 4: A,B,C,D,E,F, etc.
const heatmapCellActive: boolean[][] = domains.map((_, domainIdx) => {
  const colCount = domainIdx + 1; // Domain N has N capabilities active (triangular pattern)
  // Actually per PDF spec: Level 1 has A only (1 col), L2 has A,B (2 cols), etc.
  // But the spec says Level 1: A only means column 0 active. Level 2: A,B means columns 0,1 active.
  // Level 3: A,B,C,D means columns 0,1,2,3 active. etc.
  // The pattern is: for each level L, columns 0 to min(L's max domain index, 9) are active
  // Re-reading: "Level 1 (Initiation): A only" means domain A (index 0) has level 1 active.
  // "Level 2 (Adoption): A,B" means domains A,B (indices 0,1) have level 2 active.
  // "Level 3 (Integration): A,B,C,D" means domains A,B,C,D (indices 0,1,2,3) have level 3 active.
  // So for each DOMAIN row, we need to determine which LEVELS are active:
  // Domain A (0): levels 1-10 all active
  // Domain B (1): levels 2-10 active
  // Domain C (2): levels 3-10 active
  // Domain D (3): levels 3-10 active (wait, Level 3 has C,D so both start at 3)
  // Domain E (4): levels 4-10 active (Level 4 adds E,F)
  // Domain F (5): levels 4-10 active
  // Domain G (6): levels 5-10 active
  // Domain H (7): levels 5-10 active
  // Domain I (8): levels 6-10 active
  // Domain J (9): levels 7-10 active
  const startLevelByDomain = [0, 1, 2, 2, 3, 3, 4, 4, 5, 6];
  return levels.map((_, levelIdx) => levelIdx >= startLevelByDomain[domainIdx]);
});

const financialData = [
  { level: 1, roi: 0, npv: 0, riskReduction: 0, strategicLeverage: 1 },
  { level: 2, roi: 120, npv: 18, riskReduction: 15, strategicLeverage: 1.2 },
  { level: 3, roi: 340, npv: 52, riskReduction: 30, strategicLeverage: 1.5 },
  { level: 4, roi: 680, npv: 95, riskReduction: 45, strategicLeverage: 2.0 },
  { level: 5, roi: 1100, npv: 148, riskReduction: 55, strategicLeverage: 2.6 },
  { level: 6, roi: 1650, npv: 215, riskReduction: 65, strategicLeverage: 3.4 },
  { level: 7, roi: 2200, npv: 285, riskReduction: 72, strategicLeverage: 4.3 },
  { level: 8, roi: 2800, npv: 345, riskReduction: 78, strategicLeverage: 5.4 },
  { level: 9, roi: 3400, npv: 390, riskReduction: 82, strategicLeverage: 6.7 },
  { level: 10, roi: 4200, npv: 420, riskReduction: 80, strategicLeverage: 8.2 },
];

const portfolioData = [
  { category: 'Training Programs', maturityImpact: '+2 levels', roiAcceleration: '+180%', npvLift: '$28M', riskReduction: 'Medium', strategicLeverage: 'Low' },
  { category: 'Workflow Integration', maturityImpact: '+3 levels', roiAcceleration: '+420%', npvLift: '$52M', riskReduction: 'High', strategicLeverage: 'Medium' },
  { category: 'Agent Deployment', maturityImpact: '+3 levels', roiAcceleration: '+680%', npvLift: '$78M', riskReduction: 'High', strategicLeverage: 'High' },
  { category: 'Data Platform', maturityImpact: '+2 levels', roiAcceleration: '+340%', npvLift: '$45M', riskReduction: 'Medium', strategicLeverage: 'Medium' },
  { category: 'Governance Framework', maturityImpact: '+1 level', roiAcceleration: '+120%', npvLift: '$18M', riskReduction: 'High', strategicLeverage: 'Low' },
  { category: 'Change Management', maturityImpact: '+2 levels', roiAcceleration: '+280%', npvLift: '$38M', riskReduction: 'High', strategicLeverage: 'Medium' },
  { category: 'Infrastructure', maturityImpact: '+1 level', roiAcceleration: '+90%', npvLift: '$12M', riskReduction: 'Low', strategicLeverage: 'Low' },
  { category: 'Executive Sponsorship', maturityImpact: '+2 levels', roiAcceleration: '+220%', npvLift: '$35M', riskReduction: 'Medium', strategicLeverage: 'High' },
];

const maturityLevelDetails = [
  { level: 1, name: 'Initiation', roiProfile: 'Baseline investment', npvImpact: '$0M', riskReduction: '0%', description: 'Pilot deployment, executive mandate, initial training' },
  { level: 2, name: 'Adoption', roiProfile: '+120% ROI', npvImpact: '$18M', riskReduction: '15%', description: 'Widespread daily use, organic discovery, use case library' },
  { level: 3, name: 'Integration', roiProfile: '+340% ROI', npvImpact: '$52M', riskReduction: '30%', description: 'Workflow integration with core systems, unified data access' },
  { level: 4, name: 'Orchestration', roiProfile: '+680% ROI', npvImpact: '$95M', riskReduction: '45%', description: 'Multi-system orchestration, governance framework operational' },
  { level: 5, name: 'Acceleration', roiProfile: '+1,100% ROI', npvImpact: '$148M', riskReduction: '55%', description: 'Agent deployment acceleration, autonomous workflows begin' },
  { level: 6, name: 'Expansion', roiProfile: '+1,650% ROI', npvImpact: '$215M', riskReduction: '65%', description: 'Full enterprise expansion, cognitive augmentation deployed' },
  { level: 7, name: 'Autonomy', roiProfile: '+2,200% ROI', npvImpact: '$285M', riskReduction: '72%', description: 'Autonomous agent networks, self-healing systems active' },
  { level: 8, name: 'Symbiosis', roiProfile: '+2,800% ROI', npvImpact: '$345M', riskReduction: '78%', description: 'Human-AI symbiosis, predictive enterprise intelligence' },
  { level: 9, name: 'Self-Optimization', roiProfile: '+3,400% ROI', npvImpact: '$390M', riskReduction: '82%', description: 'Continuous self-optimization, strategic AI partnership' },
  { level: 10, name: 'Pre-Singularity', roiProfile: '+4,200% ROI', npvImpact: '$420M', riskReduction: '80%', description: 'Full cognitive enterprise, pre-Singularity operations' },
];

const insightCards = [
  {
    icon: TrendingUp,
    title: 'NPV Inflection Point',
    level: 'Levels 4-5',
    description: 'NPV growth accelerates exponentially. Risk-adjusted returns justify full enterprise deployment.',
    highlight: '$148M NPV',
  },
  {
    icon: Award,
    title: 'ROI Peak Zone',
    level: 'Levels 7-9',
    description: 'Optimal risk-adjusted ROI with autonomous operations delivering maximum productivity gains.',
    highlight: '+2,200% ROI',
  },
  {
    icon: Target,
    title: 'Regulator-Safe Minimum',
    level: 'Level 4+',
    description: 'Minimum maturity for board approval with full governance, audit trails, and risk management.',
    highlight: 'Board Ready',
  },
  {
    icon: Zap,
    title: 'Board Flexibility',
    level: 'Level 6+',
    description: 'Full strategic optionality unlocked. Real options portfolio becomes valuable.',
    highlight: 'Full Options',
  },
];

const planningInsights = [
  { label: 'Best Accelerators', value: 'Workflow Integration + Agent Deployment', detail: 'Highest maturity-per-dollar invested' },
  { label: 'Highest Leverage', value: 'Agent Deployment + Executive Sponsorship', detail: 'Unlocks the full real options portfolio' },
  { label: 'Best Early-Stage ROI', value: 'Training Programs (Months 1-6)', detail: 'Immediate productivity gains with fast payback' },
  { label: 'Best Mid-Stage NPV Lift', value: 'Workflow Integration (Months 7-18)', detail: 'Compound productivity effect across all users' },
];

const cellDescriptions: string[][] = domains.map((domain, di) =>
  levels.map((level, li) => {
    if (!heatmapCellActive[di][li]) return `${domain} not yet active at Level ${level.num}`;
    return `${domain} — Level ${level.num} (${level.name}): Capability active`;
  })
);

// ── Animation helpers ───────────────────────────────────────────────

const fadeUp = {
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] },
};

const stagger = (i: number) => ({
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4, delay: i * 0.08, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] },
});

// ── Components ──────────────────────────────────────────────────────

function HeatmapCell({
  active,
  color,
  tooltip,
  delay,
}: {
  active: boolean;
  color: string;
  tooltip: string;
  delay: number;
}) {
  const [hovered, setHovered] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3, delay }}
      className="relative"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div
        className="w-full aspect-square rounded-[4px] transition-transform duration-200 border border-bg-quaternary/50"
        style={{
          backgroundColor: active ? color : 'rgba(100,116,139,0.12)',
          transform: hovered && active ? 'scale(1.15)' : 'scale(1)',
          boxShadow: hovered && active ? `0 0 8px ${color}60` : 'none',
          opacity: active ? 1 : 0.25,
          cursor: active ? 'pointer' : 'default',
        }}
      />
      {hovered && active && (
        <div className="absolute z-50 bottom-full left-1/2 -translate-x-1/2 mb-2 bg-bg-secondary border border-bg-quaternary rounded-lg px-3 py-2 shadow-xl pointer-events-none whitespace-nowrap">
          <span className="text-body-sm text-text-primary">{tooltip}</span>
        </div>
      )}
    </motion.div>
  );
}

function ScorecardBar({ current, target }: { current: number; target: number }) {
  return (
    <div className="w-full h-2 bg-bg-quaternary rounded-full overflow-hidden mt-2">
      <motion.div
        initial={{ width: 0 }}
        animate={{ width: `${(current / target) * 100}%` }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] }}
        className="h-full rounded-full"
        style={{ background: 'linear-gradient(90deg, #D4A853, #4ADE80)' }}
      />
    </div>
  );
}

function getInsightColor(level: string) {
  if (level.includes('6')) return 'from-amber-500/20 to-orange-500/10';
  if (level.includes('7') || level.includes('9')) return 'from-green-500/20 to-emerald-500/10';
  if (level.includes('4') || level.includes('5')) return 'from-blue-500/20 to-cyan-500/10';
  return 'from-purple-500/20 to-violet-500/10';
}

export default function MaturityModel() {
  const [selectedLevel, setSelectedLevel] = useState<number>(4);

  return (
    <div className="px-8 py-6 space-y-6">
      {/* ── Page Header ── */}
      <motion.div {...fadeUp}>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-lg bg-accent-primary-muted flex items-center justify-center">
            <Star className="w-5 h-5 text-accent-primary" />
          </div>
          <div>
            <h1 className="text-display-md text-text-primary font-semibold">Copilot Capability Maturity Model</h1>
            <p className="text-body-md text-text-secondary">10 levels from Initiation to Pre-Singularity Operations</p>
          </div>
        </div>
        <p className="text-body-md text-text-secondary max-w-4xl mt-3">
          The maturity model provides a structured framework for assessing current capabilities, planning progression,
          and quantifying the financial impact of each capability level.
        </p>
      </motion.div>

      {/* ── Maturity Level Selector ── */}
      <motion.div {...fadeUp} className="bg-bg-secondary border border-bg-quaternary rounded-card p-5">
        <h3 className="text-label-lg text-text-tertiary mb-4">Select Maturity Level</h3>
        <div className="flex flex-wrap gap-3">
          {levels.map((level, i) => {
            const isActive = selectedLevel === level.num;
            return (
              <motion.button
                key={level.num}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.35, delay: i * 0.05 }}
                onClick={() => setSelectedLevel(level.num)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-lg border text-body-sm font-medium transition-all duration-200 ${
                  isActive
                    ? 'text-text-inverse shadow-lg scale-105'
                    : 'bg-bg-tertiary border-bg-quaternary text-text-secondary hover:text-text-primary hover:border-accent-primary/40'
                }`}
                style={isActive ? { backgroundColor: level.color, borderColor: level.color } : {}}
              >
                <span
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                    isActive ? 'bg-white/20 text-white' : ''
                  }`}
                  style={!isActive ? { backgroundColor: `${level.color}25`, color: level.color } : {}}
                >
                  {level.num}
                </span>
                <span>{level.name}</span>
              </motion.button>
            );
          })}
        </div>
      </motion.div>

      {/* ── Capability Maturity Heatmap ── */}
      <motion.div {...fadeUp}>
        <DataCard title="Capability Maturity Heatmap" subtitle="10 domains × 10 maturity levels — hover cells for details">
          <div className="overflow-x-auto mt-2">
            <div className="min-w-[900px]">
              {/* Column headers */}
              <div className="grid grid-cols-[180px_repeat(10,1fr)] gap-1 mb-2">
                <div />
                {levels.map((l) => (
                  <div key={l.num} className="text-center">
                    <div
                      className="text-label-sm font-bold"
                      style={{ color: l.color }}
                    >
                      L{l.num}
                    </div>
                    <div className="text-[10px] text-text-tertiary leading-tight">{l.name}</div>
                  </div>
                ))}
              </div>

              {/* Grid rows */}
              {domains.map((domain, di) => (
                <div key={domain} className="grid grid-cols-[180px_repeat(10,1fr)] gap-1 mb-1 items-center">
                  <div className="text-body-sm text-text-primary font-medium pr-2 flex items-center gap-1.5 truncate">
                    <span className="text-text-tertiary text-label-sm shrink-0">{String.fromCharCode(65 + di)}</span>
                    {domain}
                  </div>
                  {levels.map((level, li) => (
                    <HeatmapCell
                      key={`${di}-${li}`}
                      active={heatmapCellActive[di][li]}
                      color={level.color}
                      tooltip={cellDescriptions[di][li]}
                      delay={(di + li) * 0.02}
                    />
                  ))}
                </div>
              ))}

              {/* Legend */}
              <div className="flex items-center gap-6 mt-4 pt-3 border-t border-bg-quaternary">
                <span className="text-label-sm text-text-tertiary">Legend:</span>
                <div className="flex items-center gap-4">
                  {[
                    { label: 'Inactive', color: 'rgba(100,116,139,0.12)' },
                    { label: 'L1-2 Initiation', color: '#64748B' },
                    { label: 'L3-4 Integration', color: '#2DD4BF' },
                    { label: 'L5-6 Acceleration', color: '#A3E635' },
                    { label: 'L7-8 Autonomy', color: '#F59E0B' },
                    { label: 'L9-10 Singularity', color: '#EF4444' },
                  ].map((item) => (
                    <div key={item.label} className="flex items-center gap-1.5">
                      <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: item.color }} />
                      <span className="text-[11px] text-text-secondary">{item.label}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </DataCard>
      </motion.div>

      {/* ── Capability Assessment Scorecard ── */}
      <motion.div {...fadeUp}>
        <DataCard title="Capability Assessment Scorecard" subtitle="Current vs. target maturity for each domain">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
            {domains.map((domain, i) => {
              const currentLevel = [3, 2, 2, 1, 2, 3, 2, 3, 1, 1][i];
              const targetLevel = [7, 6, 6, 7, 6, 5, 6, 7, 6, 5][i];
              const currentColor = levels[currentLevel - 1].color;
              const targetColor = levels[targetLevel - 1].color;
              const kpis = [
                ['Daily active users: 68%', 'Feature utilization: 42%', 'User satisfaction: 4.1/5'],
                ['Workflow coverage: 55%', 'Process automation: 38%', 'Integration depth: 3.2/5'],
                ['Data sources connected: 12', 'Semantic search enabled: 45%', 'Data quality score: 82%'],
                ['Active agents deployed: 8', 'Autonomous workflows: 15%', 'Agent success rate: 78%'],
                ['AI-ready employees: 62%', 'Change adoption: 71%', 'Training completion: 85%'],
                ['Governance policies: 14', 'Risk assessments: 92%', 'Compliance score: 96%'],
                ['System uptime: 99.7%', 'Mean recovery: 4.2 min', 'Incident auto-resolution: 34%'],
                ['Strategic AI initiatives: 6', 'Exec sponsorship: 88%', 'Portfolio alignment: 75%'],
                ['Learning loops active: 4', 'Optimization cycles: 12', 'Knowledge reuse: 58%'],
                ['Cognitive models deployed: 2', 'Decision augmentation: 28%', 'Predictive accuracy: 73%'],
              ][i];
              return (
                <motion.div
                  key={domain}
                  {...stagger(i)}
                  className="bg-bg-tertiary/50 border border-bg-quaternary rounded-lg p-4"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-heading-md text-text-primary">{domain}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-label-sm text-text-tertiary">Current</span>
                      <span
                        className="text-label-sm font-bold px-2 py-0.5 rounded"
                        style={{ backgroundColor: `${currentColor}25`, color: currentColor }}
                      >
                        L{currentLevel}
                      </span>
                      <ArrowRight className="w-3.5 h-3.5 text-text-tertiary" />
                      <span
                        className="text-label-sm font-bold px-2 py-0.5 rounded border"
                        style={{ borderColor: targetColor, color: targetColor }}
                      >
                        L{targetLevel}
                      </span>
                    </div>
                  </div>
                  <ScorecardBar current={currentLevel} target={targetLevel} />
                  <div className="flex items-center justify-between mt-1">
                    <span className="text-body-sm text-text-secondary">
                      Progress: {Math.round((currentLevel / targetLevel) * 100)}%
                    </span>
                    <span className="text-body-sm text-text-tertiary">
                      +{targetLevel - currentLevel} levels to target
                    </span>
                  </div>
                  <div className="mt-3 space-y-1">
                    {kpis.map((kpi, ki) => (
                      <div key={ki} className="flex items-center gap-2">
                        <div className="w-1 h-1 rounded-full bg-accent-primary" />
                        <span className="text-body-sm text-text-secondary">{kpi}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </DataCard>
      </motion.div>

      {/* ── Financial Maturity Curve ── */}
      <motion.div {...fadeUp}>
        <DataCard title="Financial Impact by Maturity Level" subtitle="ROI, NPV, and risk reduction across maturity levels">
          <div className="h-[400px] mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={financialData} margin={{ top: 10, right: 30, left: 10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" />
                <XAxis
                  dataKey="level"
                  tick={{ fill: '#94A3B8', fontSize: 12 }}
                  stroke="rgba(148,163,184,0.3)"
                  label={{ value: 'Maturity Level', position: 'insideBottomRight', offset: -5, fill: '#64748B', fontSize: 12 }}
                />
                <YAxis
                  yAxisId="left"
                  tick={{ fill: '#94A3B8', fontSize: 12 }}
                  stroke="rgba(148,163,184,0.3)"
                  label={{ value: 'ROI %', angle: -90, position: 'insideLeft', fill: '#64748B', fontSize: 12 }}
                />
                <YAxis
                  yAxisId="right"
                  orientation="right"
                  tick={{ fill: '#94A3B8', fontSize: 12 }}
                  stroke="rgba(148,163,184,0.3)"
                  label={{ value: 'NPV ($M)', angle: 90, position: 'insideRight', fill: '#64748B', fontSize: 12 }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#111827',
                    border: '1px solid #232D42',
                    borderRadius: '8px',
                    fontSize: '13px',
                  }}
                  labelStyle={{ color: '#F0F2F7' }}
                />
                <Legend
                  wrapperStyle={{ fontSize: '12px', color: '#94A3B8' }}
                />
                <Area
                  yAxisId="right"
                  type="monotone"
                  dataKey="npv"
                  name="NPV ($M)"
                  fill="rgba(74,222,128,0.15)"
                  stroke="#4ADE80"
                  strokeWidth={2}
                />
                <Line
                  yAxisId="left"
                  type="monotone"
                  dataKey="roi"
                  name="ROI %"
                  stroke="#D4A853"
                  strokeWidth={3}
                  dot={{ fill: '#D4A853', r: 4 }}
                  activeDot={{ r: 6, fill: '#D4A853' }}
                />
                <Line
                  yAxisId="left"
                  type="monotone"
                  dataKey="riskReduction"
                  name="Risk Reduction %"
                  stroke="#60A5FA"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  dot={{ fill: '#60A5FA', r: 3 }}
                />
                <Line
                  yAxisId="left"
                  type="monotone"
                  dataKey={(d) => d.strategicLeverage * 400}
                  name="Strategic Leverage"
                  stroke="#A78BFA"
                  strokeWidth={2}
                  strokeDasharray="3 3"
                  dot={{ fill: '#A78BFA', r: 3 }}
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>

          {/* Inflection point annotations */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
            {[
              { label: 'NPV Inflection', level: 'Level 5', color: '#4ADE80' },
              { label: 'Risk-Adjusted Peak', level: 'Level 7', color: '#D4A853' },
              { label: 'Regulator-Safe', level: 'Level 4', color: '#60A5FA' },
              { label: 'Board Flexibility', level: 'Level 6', color: '#A78BFA' },
            ].map((ann) => (
              <div key={ann.label} className="flex items-center gap-2 bg-bg-tertiary rounded-lg px-3 py-2">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: ann.color }} />
                <div>
                  <div className="text-label-sm text-text-tertiary">{ann.label}</div>
                  <div className="text-body-sm text-text-primary font-medium">{ann.level}</div>
                </div>
              </div>
            ))}
          </div>
        </DataCard>
      </motion.div>

      {/* ── Portfolio-Aligned Maturity Model ── */}
      <motion.div {...fadeUp}>
        <DataCard title="Portfolio-Aligned Maturity Model" subtitle="Financial profile at each maturity level">
          <div className="overflow-x-auto mt-3">
            <table className="w-full min-w-[700px]">
              <thead>
                <tr className="bg-bg-tertiary">
                  {['Level', 'Name', 'ROI Profile', 'NPV Impact', 'Risk Reduction', 'Description'].map((h) => (
                    <th key={h} className="text-left px-4 py-3 text-label-sm text-text-tertiary font-medium">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {maturityLevelDetails.map((row, i) => (
                  <motion.tr
                    key={row.level}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.06 }}
                    className="border-b border-bg-quaternary hover:bg-bg-tertiary/30 transition-colors"
                  >
                    <td className="px-4 py-3">
                      <span
                        className="text-label-sm font-bold px-2 py-0.5 rounded"
                        style={{
                          backgroundColor: `${levels[i].color}25`,
                          color: levels[i].color,
                        }}
                      >
                        L{row.level}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-body-md text-text-primary font-medium">{row.name}</td>
                    <td className="px-4 py-3 text-mono-sm text-accent-secondary">{row.roiProfile}</td>
                    <td className="px-4 py-3 text-mono-sm text-accent-primary">{row.npvImpact}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-1.5 bg-bg-quaternary rounded-full overflow-hidden">
                          <div
                            className="h-full rounded-full bg-accent-info"
                            style={{ width: row.riskReduction }}
                          />
                        </div>
                        <span className="text-body-sm text-text-secondary">{row.riskReduction}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-body-sm text-text-secondary max-w-xs">{row.description}</td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </DataCard>
      </motion.div>

      {/* ── Portfolio Optimization Matrix ── */}
      <motion.div {...fadeUp}>
        <DataCard title="Maturity Investment Portfolio" subtitle="Investment categories and their maturity impact">
          <div className="overflow-x-auto mt-3">
            <table className="w-full min-w-[750px]">
              <thead>
                <tr className="bg-bg-tertiary">
                  {['Investment Category', 'Maturity Impact', 'ROI Acceleration', 'NPV Lift', 'Risk Reduction', 'Strategic Leverage'].map(
                    (h) => (
                      <th key={h} className="text-left px-4 py-3 text-label-sm text-text-tertiary font-medium">
                        {h}
                      </th>
                    )
                  )}
                </tr>
              </thead>
              <tbody>
                {portfolioData.map((row, i) => (
                  <motion.tr
                    key={row.category}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.08 }}
                    className="border-b border-bg-quaternary hover:bg-bg-tertiary/30 transition-colors"
                  >
                    <td className="px-4 py-3 text-body-md text-text-primary font-medium">{row.category}</td>
                    <td className="px-4 py-3">
                      <span className="text-body-sm text-accent-primary font-medium">{row.maturityImpact}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-mono-sm text-accent-secondary">{row.roiAcceleration}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-mono-sm text-accent-primary">{row.npvLift}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`text-body-sm font-medium px-2 py-0.5 rounded ${
                          row.riskReduction === 'High'
                            ? 'bg-accent-secondary-muted text-accent-secondary'
                            : row.riskReduction === 'Medium'
                            ? 'bg-accent-primary-muted text-accent-primary'
                            : 'bg-bg-quaternary text-text-tertiary'
                        }`}
                      >
                        {row.riskReduction}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`text-body-sm font-medium px-2 py-0.5 rounded ${
                          row.strategicLeverage === 'High' || row.strategicLeverage === 'Very High'
                            ? 'bg-accent-secondary-muted text-accent-secondary'
                            : row.strategicLeverage === 'Medium'
                            ? 'bg-accent-info-muted text-accent-info'
                            : 'bg-bg-quaternary text-text-tertiary'
                        }`}
                      >
                        {row.strategicLeverage}
                      </span>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </DataCard>
      </motion.div>

      {/* ── Strategic Insights ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        {insightCards.map((insight, i) => {
          const Icon = insight.icon;
          return (
            <motion.div
              key={insight.title}
              {...stagger(i)}
              className={`bg-bg-secondary border border-bg-quaternary rounded-card p-5 relative overflow-hidden`}
            >
              <div
                className={`absolute inset-0 bg-gradient-to-br ${getInsightColor(insight.level)} opacity-30`}
              />
              <div className="relative z-10">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-9 h-9 rounded-lg bg-accent-primary-muted flex items-center justify-center">
                    <Icon className="w-4.5 h-4.5 text-accent-primary" />
                  </div>
                  <span className="text-label-sm text-accent-primary">{insight.level}</span>
                </div>
                <h3 className="text-heading-md text-text-primary mb-1">{insight.title}</h3>
                <p className="text-body-sm text-text-secondary mb-3">{insight.description}</p>
                <div className="text-mono-md text-accent-primary">{insight.highlight}</div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* ── Planning Insights ── */}
      <motion.div {...fadeUp}>
        <DataCard title="Strategic Planning Insights" subtitle="Key recommendations for maturity investment">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
            {planningInsights.map((insight, i) => {
              const icons = [Rocket, Zap, Target, BarChart3];
              const Icon = icons[i];
              return (
                <motion.div
                  key={insight.label}
                  {...stagger(i)}
                  className="flex items-start gap-4 bg-bg-tertiary/50 border border-bg-quaternary rounded-lg p-4"
                >
                  <div className="w-10 h-10 rounded-lg bg-accent-primary-muted flex items-center justify-center shrink-0">
                    <Icon className="w-5 h-5 text-accent-primary" />
                  </div>
                  <div>
                    <span className="text-label-sm text-text-tertiary">{insight.label}</span>
                    <p className="text-body-md text-text-primary font-medium mt-0.5">{insight.value}</p>
                    <p className="text-body-sm text-text-secondary mt-1">{insight.detail}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </DataCard>
      </motion.div>
    </div>
  );
}
