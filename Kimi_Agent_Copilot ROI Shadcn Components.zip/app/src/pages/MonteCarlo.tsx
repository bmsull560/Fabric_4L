import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Target,
  Activity,
  BarChart3,
  Play,
  ChevronDown,
  Dices,
  Download,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  Area,
  AreaChart,
  ComposedChart,
  Cell,
} from 'recharts';
import { cn } from '@/lib/utils';
import KpiCard from '@/components/KpiCard';
import DataCard from '@/components/DataCard';
import NumberAnimation from '@/components/NumberAnimation';

/* ─── easing / animation tokens ─── */
const EASE_SMOOTH = [0.22, 1, 0.36, 1] as [number, number, number, number];
const cardIn = {
  hidden: { opacity: 0, y: 25 },
  show: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.1, duration: 0.5, ease: EASE_SMOOTH },
  }),
};

/* ─── Histogram data (80 bins, simulated normal-ish around 2700) ─── */
const histogramData: { bin: number; count: number }[] = [];
for (let i = 0; i <= 6000; i += 75) {
  const x = i;
  // Approximate normal distribution centred at 2742, sigma 620
  const count =
    Math.round(
      10000 *
        75 *
        (1 / (620 * Math.sqrt(2 * Math.PI))) *
        Math.exp(-0.5 * Math.pow((x - 2742) / 620, 2))
    ) + (Math.random() > 0.7 ? Math.round(Math.random() * 5) : 0);
  histogramData.push({ bin: x, count: Math.max(count, 0) });
}

/* ─── Cumulative distribution data ─── */
const cumulativeData: { roi: number; probability: number }[] = [];
for (let roi = 0; roi <= 5500; roi += 50) {
  const z = (roi - 2742) / 620;
  // Approximate CDF using error function approximation
  const cdf =
    0.5 *
    (1 +
      Math.sign(z) *
        Math.sqrt(1 - Math.exp((-2 / Math.PI) * z * z)));
  const prob = Math.min(Math.max(cdf, 0), 1) * 100;
  cumulativeData.push({ roi, probability: Math.round(prob * 10) / 10 });
}

/* ─── Percentile data ─── */
const percentileData = [
  { label: '1st', value: 1187 },
  { label: '5th', value: 1523 },
  { label: '25th', value: 2089 },
  { label: '50th', value: 2615 },
  { label: '75th', value: 3298 },
  { label: '95th', value: 4456 },
  { label: '99th', value: 5287 },
];

const probabilityThresholds = [
  { threshold: 'ROI > 0%', probability: 100.0 },
  { threshold: 'ROI > 500%', probability: 99.8 },
  { threshold: 'ROI > 1,000%', probability: 94.2 },
  { threshold: 'ROI > 2,000%', probability: 71.5 },
  { threshold: 'ROI > 3,000%', probability: 28.3 },
];

/* ─── Tornado data ─── */
const tornadoData = [
  { variable: 'Productivity Hours (IT)', low: 1680, high: 3890, impact: 2210 },
  { variable: 'Adoption Rate', low: 2050, high: 3410, impact: 1360 },
  { variable: 'License Cost', low: 2980, high: 2450, impact: 530 },
  { variable: 'Truck Roll Reduction', low: 2510, high: 2980, impact: 470 },
  { variable: 'AHT Reduction', low: 2590, high: 2900, impact: 310 },
  { variable: 'Trading Margin', low: 2610, high: 2890, impact: 280 },
  { variable: 'Productivity Hours (Corp)', low: 2550, high: 2920, impact: 370 },
  { variable: 'CS Hours Saved', low: 2600, high: 2870, impact: 270 },
];

const sortedTornado = [...tornadoData].sort((a, b) => b.impact - a.impact);

/* ─── Stress test data ─── */
const stressTests = [
  {
    title: '50% Productivity Cut',
    condition: 'All productivity hours saved reduced by 50%',
    meanRoi: 1371,
    probPositive: 99.2,
    badge: 'MODERATE IMPACT',
    badgeColor: 'bg-accent-primary-muted text-accent-primary',
  },
  {
    title: '60% Adoption Cap',
    condition: 'Maximum adoption limited to 60%',
    meanRoi: 2089,
    probPositive: 99.6,
    badge: 'LOW IMPACT',
    badgeColor: 'bg-accent-secondary-muted text-accent-secondary',
  },
  {
    title: '$40 License Cost',
    condition: 'License cost increased to $40/user/month',
    meanRoi: 2412,
    probPositive: 99.9,
    badge: 'LOW IMPACT',
    badgeColor: 'bg-accent-secondary-muted text-accent-secondary',
  },
  {
    title: 'All Negative Combined',
    condition: '50% productivity cut + 60% adoption + $40 license',
    meanRoi: 847,
    probPositive: 97.1,
    badge: 'MODERATE IMPACT',
    badgeColor: 'bg-accent-primary-muted text-accent-primary',
  },
];

/* ─── Variable definitions ─── */
const productivityVars = [
  { name: 'IT hours saved', distribution: 'Normal(15, 3)', range: '5 – 25', color: '#D4A853' },
  { name: 'Corporate hours saved', distribution: 'Normal(10, 2.5)', range: '3 – 20', color: '#4ADE80' },
  { name: 'Customer service hours saved', distribution: 'Normal(8, 2)', range: '2 – 16', color: '#60A5FA' },
  { name: 'Field hours saved', distribution: 'Normal(6, 2)', range: '2 – 14', color: '#A78BFA' },
  { name: 'Adoption rate', distribution: 'Triangular(0.65, 0.85, 1.0)', range: '65% – 100%', color: '#2DD4BF' },
];

const operationalVars = [
  { name: 'Truck roll reduction', distribution: 'Triangular(12%, 18%, 24%)', range: '12% – 24%', color: '#D4A853' },
  { name: 'Cost per truck roll', distribution: 'Normal($285, $35)', range: '$180 – $390', color: '#4ADE80' },
  { name: 'Outage restoration benefit', distribution: 'Triangular($1.5M, $2.1M, $2.8M)', range: '$1.5M – $2.8M', color: '#60A5FA' },
  { name: 'AHT reduction', distribution: 'Triangular(22%, 31%, 40%)', range: '22% – 40%', color: '#A78BFA' },
  { name: 'Cost per call', distribution: 'Normal($18, $3)', range: '$9 – $27', color: '#F472B6' },
  { name: 'Call volume', distribution: 'Normal(85K/mo, 8K)', range: '61K – 109K/mo', color: '#2DD4BF' },
  { name: 'Trading margin improvement', distribution: 'Triangular(15%, 23%, 32%)', range: '15% – 32%', color: '#D4A853' },
  { name: 'Trading book size', distribution: 'Normal($420M, $60M)', range: '$240M – $600M', color: '#4ADE80' },
];

const costVars = [
  { name: 'License cost', distribution: 'Triangular($25, $30, $40)', range: '$25 – $40/user/mo', color: '#F87171' },
  { name: 'Training cost', distribution: 'Fixed $180K', range: 'Amortized 3yr', color: '#60A5FA' },
];

/* ─── Custom tooltip ─── */
function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number }>; label?: number }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-bg-secondary border border-bg-quaternary rounded-lg px-3 py-2 shadow-xl">
      <p className="text-body-sm text-text-primary font-medium">
        ROI: {label?.toLocaleString()}%
      </p>
      <p className="text-body-sm text-text-secondary">
        {payload[0].value.toLocaleString()} simulations
      </p>
      <p className="text-body-sm text-text-tertiary">
        {((payload[0].value / 10000) * 100).toFixed(1)}% of total
      </p>
    </div>
  );
}

/* ─── Custom bar tooltip for tornado ─── */
function TornadoTooltip({ active, payload }: { active?: boolean; payload?: Array<{ payload: { variable: string; low: number; high: number } }> }) {
  if (!active || !payload?.length) return null;
  const data = payload[0].payload;
  return (
    <div className="bg-bg-secondary border border-bg-quaternary rounded-lg px-3 py-2 shadow-xl">
      <p className="text-body-sm text-text-primary font-medium">{data.variable}</p>
      <p className="text-body-sm text-accent-tertiary">Low: {data.low.toLocaleString()}%</p>
      <p className="text-body-sm text-accent-secondary">High: {data.high.toLocaleString()}%</p>
      <p className="text-body-sm text-text-tertiary">Swing: {(data.high - data.low).toLocaleString()}%</p>
    </div>
  );
}

/* ─── Main Component ─── */
export default function MonteCarlo() {
  const [iterations, setIterations] = useState('10,000');
  const [showVariables, setShowVariables] = useState(false);
  const [showAlgorithm, setShowAlgorithm] = useState(false);
  const [simStatus, setSimStatus] = useState<'ready' | 'running' | 'complete'>('complete');

  const runSimulation = () => {
    setSimStatus('running');
    setTimeout(() => setSimStatus('complete'), 1500);
  };

  return (
    <div className="px-8 py-6 space-y-6">
      {/* ── Header ── */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: EASE_SMOOTH }}
      >
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-lg bg-accent-primary-muted flex items-center justify-center">
            <Dices className="w-5 h-5 text-accent-primary" />
          </div>
          <div>
            <h1 className="text-display-md text-text-primary">Monte Carlo Simulation</h1>
            <p className="text-body-sm text-text-tertiary">
              Probabilistic ROI model — 10,000 randomized iterations
            </p>
          </div>
          <span className="ml-auto text-label-sm bg-accent-primary-muted text-accent-primary px-3 py-1 rounded-md">
            10,000 ITERATIONS
          </span>
        </div>
        <p className="text-body-md text-text-secondary max-w-4xl mt-3">
          A Monte Carlo simulation randomizes input variables across defined probability distributions
          to generate a distribution of possible ROI outcomes. This approach captures uncertainty far
          more realistically than deterministic single-point estimates.
        </p>
      </motion.div>

      {/* ── 3 Summary KPI Cards ── */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <KpiCard
          icon={Target}
          label="MEAN ROI"
          value={2742}
          valueSuffix="%"
          subtitle="Expected value across all iterations"
          index={0}
        />
        <KpiCard
          icon={Activity}
          label="MEDIAN ROI"
          value={2615}
          valueSuffix="%"
          subtitle="50th percentile — half above, half below"
          index={1}
        />
        <KpiCard
          icon={BarChart3}
          label="STANDARD DEVIATION"
          value={847}
          valueSuffix="%"
          subtitle="Measure of outcome dispersion"
          index={2}
        />
      </div>

      {/* ── Simulation Control Panel ── */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3, ease: EASE_SMOOTH }}
        className="bg-bg-secondary border border-bg-quaternary rounded-card p-5"
      >
        <div className="flex flex-wrap items-center gap-4">
          <span className="text-heading-md text-text-primary">Simulation Parameters</span>
          <div className="flex items-center gap-2 ml-4">
            <label className="text-label-sm text-text-tertiary">Iterations</label>
            <select
              className="bg-bg-tertiary border border-bg-quaternary rounded-button px-3 py-2 text-body-md text-text-primary focus:outline-none focus:border-accent-primary"
              value={iterations}
              onChange={(e) => setIterations(e.target.value)}
            >
              <option>1,000</option>
              <option>5,000</option>
              <option>10,000</option>
              <option>50,000</option>
            </select>
          </div>
          <button
            onClick={runSimulation}
            className="flex items-center gap-2 bg-accent-primary text-text-inverse px-4 py-2 rounded-button text-body-md font-medium hover:bg-accent-primary-hover hover:shadow-[0_4px_16px_rgba(212,168,83,0.3)] transition-all active:scale-[0.98]"
          >
            <Play className="w-4 h-4" />
            Run Simulation
          </button>
          <div className="flex items-center gap-2 ml-auto">
            <span
              className={cn(
                'w-2 h-2 rounded-full',
                simStatus === 'ready' && 'bg-accent-info',
                simStatus === 'running' && 'bg-accent-primary animate-pulse',
                simStatus === 'complete' && 'bg-accent-secondary'
              )}
            />
            <span className="text-body-sm text-text-secondary capitalize">
              {simStatus === 'running' ? 'Running...' : simStatus}
            </span>
          </div>
          <button className="flex items-center gap-1.5 text-body-sm text-text-secondary hover:text-text-primary bg-bg-tertiary border border-bg-quaternary px-3 py-2 rounded-button transition-colors">
            <Download className="w-4 h-4" />
            Export CSV
          </button>
        </div>
      </motion.div>

      {/* ── Variable Definitions Accordion ── */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.35, ease: EASE_SMOOTH }}
        className="bg-bg-secondary border border-bg-quaternary rounded-card"
      >
        <button
          onClick={() => setShowVariables(!showVariables)}
          className="w-full flex items-center justify-between px-5 py-4 text-left hover:bg-bg-tertiary/30 transition-colors rounded-card"
        >
          <span className="text-heading-md text-text-primary">Randomized Variable Definitions</span>
          <ChevronDown
            className={cn(
              'w-5 h-5 text-text-secondary transition-transform duration-300',
              showVariables && 'rotate-180'
            )}
          />
        </button>
        <AnimatePresence initial={false}>
          {showVariables && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.4, ease: EASE_SMOOTH }}
              className="overflow-hidden"
            >
              <div className="px-5 pb-5 space-y-5">
                {/* Productivity */}
                <div>
                  <h4 className="text-label-lg text-accent-primary mb-3">Productivity Distributions</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {productivityVars.map((v) => (
                      <div
                        key={v.name}
                        className="bg-bg-primary border border-bg-quaternary rounded-lg px-4 py-3"
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <div
                            className="w-2.5 h-2.5 rounded-full"
                            style={{ backgroundColor: v.color }}
                          />
                          <span className="text-body-sm text-text-primary font-medium">{v.name}</span>
                        </div>
                        <p className="text-body-sm text-text-secondary font-mono">{v.distribution}</p>
                        <p className="text-body-sm text-text-tertiary">Range: {v.range}</p>
                      </div>
                    ))}
                  </div>
                </div>
                {/* Operational */}
                <div>
                  <h4 className="text-label-lg text-accent-secondary mb-3">Operational Distributions</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {operationalVars.map((v) => (
                      <div
                        key={v.name}
                        className="bg-bg-primary border border-bg-quaternary rounded-lg px-4 py-3"
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <div
                            className="w-2.5 h-2.5 rounded-full"
                            style={{ backgroundColor: v.color }}
                          />
                          <span className="text-body-sm text-text-primary font-medium">{v.name}</span>
                        </div>
                        <p className="text-body-sm text-text-secondary font-mono">{v.distribution}</p>
                        <p className="text-body-sm text-text-tertiary">Range: {v.range}</p>
                      </div>
                    ))}
                  </div>
                </div>
                {/* Cost */}
                <div>
                  <h4 className="text-label-lg text-accent-tertiary mb-3">Cost Variables</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {costVars.map((v) => (
                      <div
                        key={v.name}
                        className="bg-bg-primary border border-bg-quaternary rounded-lg px-4 py-3"
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <div
                            className="w-2.5 h-2.5 rounded-full"
                            style={{ backgroundColor: v.color }}
                          />
                          <span className="text-body-sm text-text-primary font-medium">{v.name}</span>
                        </div>
                        <p className="text-body-sm text-text-secondary font-mono">{v.distribution}</p>
                        <p className="text-body-sm text-text-tertiary">Range: {v.range}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* ── ROI Distribution Histogram ── */}
      <DataCard
        title="ROI Distribution — 10,000 Iterations"
        subtitle="Histogram showing frequency of ROI outcomes across all simulations"
      >
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="h-[400px] mt-4"
        >
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={histogramData} margin={{ top: 10, right: 20, left: 10, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" />
              <XAxis
                dataKey="bin"
                tick={{ fill: '#94A3B8', fontSize: 12 }}
                axisLine={{ stroke: 'rgba(148,163,184,0.3)' }}
                tickFormatter={(v: number) => `${(v / 1000).toFixed(0)}k`}
                label={{ value: 'ROI %', position: 'insideBottom', offset: -5, fill: '#94A3B8', fontSize: 12 }}
              />
              <YAxis
                tick={{ fill: '#94A3B8', fontSize: 12 }}
                axisLine={{ stroke: 'rgba(148,163,184,0.3)' }}
                label={{ value: 'Frequency', angle: -90, position: 'insideLeft', fill: '#94A3B8', fontSize: 12 }}
              />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="count" radius={[2, 2, 0, 0]}>
                {histogramData.map((_, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={
                      histogramData[index].bin >= 2089 && histogramData[index].bin <= 3298
                        ? 'rgba(74,222,128,0.25)'
                        : 'rgba(212,168,83,0.6)'
                    }
                  />
                ))}
              </Bar>
              <ReferenceLine
                x={2742}
                stroke="#D4A853"
                strokeDasharray="6 4"
                strokeWidth={2}
                label={{
                  value: 'Mean 2,742%',
                  position: 'top',
                  fill: '#D4A853',
                  fontSize: 12,
                }}
              />
              <ReferenceLine
                x={2615}
                stroke="#F0F2F7"
                strokeDasharray="4 4"
                strokeWidth={1.5}
                label={{
                  value: 'Median 2,615%',
                  position: 'top',
                  fill: '#F0F2F7',
                  fontSize: 11,
                }}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </motion.div>
        {/* Legend */}
        <div className="flex flex-wrap items-center justify-center gap-5 mt-3">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-sm bg-[rgba(212,168,83,0.6)]" />
            <span className="text-body-sm text-text-secondary">Frequency</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-sm bg-[rgba(74,222,128,0.25)]" />
            <span className="text-body-sm text-text-secondary">IQR (25th–75th %ile)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-0.5 bg-accent-primary" style={{ borderTop: '2px dashed #D4A853' }} />
            <span className="text-body-sm text-text-secondary">Mean</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-0.5 bg-text-primary" style={{ borderTop: '2px dashed #F0F2F7' }} />
            <span className="text-body-sm text-text-secondary">Median</span>
          </div>
        </div>
      </DataCard>

      {/* ── Percentile Analysis ── */}
      <DataCard
        title="Percentile Analysis"
        subtitle="Key percentile thresholds from 10,000 simulation runs"
      >
        {/* Percentile Row */}
        <div className="grid grid-cols-7 gap-0 mt-4 overflow-x-auto">
          {percentileData.map((p, i) => (
            <motion.div
              key={p.label}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + i * 0.08, duration: 0.4, ease: EASE_SMOOTH }}
              className={cn(
                'flex flex-col items-center py-4 px-2 border border-bg-quaternary',
                p.label === '50th' && 'bg-bg-tertiary/50 border-accent-primary/50'
              )}
            >
              <span className="text-label-sm text-text-tertiary">{p.label}</span>
              <span
                className={cn(
                  'text-mono-lg mt-2',
                  p.label === '50th' ? 'text-accent-primary' : 'text-text-primary'
                )}
              >
                <NumberAnimation value={p.value} suffix="%" />
              </span>
            </motion.div>
          ))}
        </div>

        {/* Probability Thresholds */}
        <div className="mt-6">
          <h4 className="text-label-lg text-text-tertiary mb-4">
            Probability of Exceeding Key Thresholds
          </h4>
          <div className="space-y-3">
            {probabilityThresholds.map((pt, i) => (
              <motion.div
                key={pt.threshold}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.7 + i * 0.1, duration: 0.4, ease: EASE_SMOOTH }}
                className="flex items-center gap-4"
              >
                <span className="text-body-md text-text-secondary w-32 shrink-0">{pt.threshold}</span>
                <div className="flex-1 h-3 bg-bg-quaternary rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${pt.probability}%` }}
                    transition={{ delay: 0.9 + i * 0.12, duration: 0.6, ease: EASE_SMOOTH }}
                    className="h-full rounded-full"
                    style={{
                      background:
                        pt.probability > 90
                          ? 'linear-gradient(90deg, #4ADE80, #2DD4BF)'
                          : pt.probability > 50
                          ? 'linear-gradient(90deg, #D4A853, #4ADE80)'
                          : 'linear-gradient(90deg, #F87171, #D4A853)',
                    }}
                  />
                </div>
                <span className="text-mono-md text-text-primary w-16 text-right">
                  {pt.probability}%
                </span>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Cumulative Distribution Chart */}
        <div className="mt-8 h-[280px]">
          <h4 className="text-label-lg text-text-tertiary mb-2">Cumulative Distribution</h4>
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={cumulativeData} margin={{ top: 10, right: 20, left: 10, bottom: 10 }}>
              <defs>
                <linearGradient id="cumulativeGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#D4A853" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#D4A853" stopOpacity={0.05} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" />
              <XAxis
                dataKey="roi"
                tick={{ fill: '#94A3B8', fontSize: 12 }}
                axisLine={{ stroke: 'rgba(148,163,184,0.3)' }}
                tickFormatter={(v: number) => `${(v / 1000).toFixed(0)}k`}
                label={{ value: 'ROI %', position: 'insideBottom', offset: -5, fill: '#94A3B8', fontSize: 12 }}
              />
              <YAxis
                domain={[0, 100]}
                tick={{ fill: '#94A3B8', fontSize: 12 }}
                axisLine={{ stroke: 'rgba(148,163,184,0.3)' }}
                tickFormatter={(v: number) => `${v}%`}
                label={{ value: 'Cumulative %', angle: -90, position: 'insideLeft', fill: '#94A3B8', fontSize: 12 }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#111827',
                  border: '1px solid #232D42',
                  borderRadius: '8px',
                }}
                formatter={(value: number) => [`${value}%`, 'Cumulative Probability']}
                labelFormatter={(label: number) => `ROI: ${label.toLocaleString()}%`}
              />
              <Area
                type="monotone"
                dataKey="probability"
                stroke="#D4A853"
                strokeWidth={2}
                fill="url(#cumulativeGrad)"
              />
              {percentileData.map((p) => (
                <ReferenceLine
                  key={p.label}
                  x={p.value}
                  stroke="rgba(148,163,184,0.3)"
                  strokeDasharray="3 3"
                  strokeWidth={1}
                />
              ))}
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </DataCard>

      {/* ── Tornado Sensitivity Analysis ── */}
      <DataCard
        title="Tornado Sensitivity Analysis"
        subtitle="Impact of ±20% change in each variable on ROI"
      >
        <div className="mt-4 h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={sortedTornado}
              layout="vertical"
              margin={{ top: 10, right: 30, left: 10, bottom: 10 }}
              barCategoryGap={12}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" horizontal={false} />
              <XAxis
                type="number"
                domain={[0, 5000]}
                tick={{ fill: '#94A3B8', fontSize: 12 }}
                axisLine={{ stroke: 'rgba(148,163,184,0.3)' }}
                tickFormatter={(v: number) => `${(v / 1000).toFixed(0)}k`}
              />
              <YAxis
                dataKey="variable"
                type="category"
                tick={{ fill: '#94A3B8', fontSize: 11 }}
                axisLine={{ stroke: 'rgba(148,163,184,0.3)' }}
                width={180}
              />
              <Tooltip content={<TornadoTooltip />} />
              <Bar dataKey="high" fill="#4ADE80" radius={[0, 4, 4, 0]} opacity={0.85} name="High (+20%)" />
              <Bar dataKey="low" fill="#F87171" radius={[0, 4, 4, 0]} opacity={0.85} name="Low (-20%)" />
              <ReferenceLine
                x={2742}
                stroke="#F0F2F7"
                strokeDasharray="4 4"
                strokeWidth={1.5}
                label={{
                  value: 'Base 2,742%',
                  position: 'top',
                  fill: '#F0F2F7',
                  fontSize: 11,
                }}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center justify-center gap-5 mt-3">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-sm bg-accent-secondary/85" />
            <span className="text-body-sm text-text-secondary">+20% variance</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-sm bg-accent-tertiary/85" />
            <span className="text-body-sm text-text-secondary">-20% variance</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-0.5 bg-text-primary" style={{ borderTop: '2px dashed #F0F2F7' }} />
            <span className="text-body-sm text-text-secondary">Base ROI</span>
          </div>
        </div>
      </DataCard>

      {/* ── Scenario Stress Tests ── */}
      <DataCard
        title="Scenario Stress Tests"
        subtitle="Adverse conditions applied to Monte Carlo model"
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mt-4">
          {stressTests.map((test, i) => (
            <motion.div
              key={test.title}
              variants={cardIn}
              initial="hidden"
              animate="show"
              custom={i}
              className="bg-bg-primary border border-bg-quaternary rounded-lg p-5 hover:border-accent-primary/30 transition-all duration-300"
            >
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-heading-md text-text-primary">{test.title}</h4>
                <span className={cn('text-label-sm px-2.5 py-1 rounded-md', test.badgeColor)}>
                  {test.badge}
                </span>
              </div>
              <p className="text-body-md text-text-secondary mb-4">{test.condition}</p>
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-label-sm text-text-tertiary">Mean ROI</span>
                  <p className="text-mono-lg text-text-primary">
                    <NumberAnimation value={test.meanRoi} suffix="%" />
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-label-sm text-text-tertiary">P(Positive)</span>
                  <p className="text-mono-md text-accent-secondary">{test.probPositive}%</p>
                </div>
              </div>
              {/* Mini probability bar */}
              <div className="mt-3 h-2 bg-bg-quaternary rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${test.probPositive}%` }}
                  transition={{ delay: 0.6 + i * 0.15, duration: 0.6, ease: EASE_SMOOTH }}
                  className="h-full rounded-full bg-gradient-to-r from-accent-secondary to-chart-6"
                />
              </div>
            </motion.div>
          ))}
        </div>
        {/* Bottom callout */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.0, duration: 0.5, ease: EASE_SMOOTH }}
          className="mt-5 bg-accent-secondary-muted border border-accent-secondary/20 rounded-lg px-5 py-4 flex items-center gap-3"
        >
          <CheckCircle2 className="w-5 h-5 text-accent-secondary flex-shrink-0" />
          <p className="text-body-md text-text-primary">
            Even under the most severe combined stress test, Copilot delivers a positive ROI with{' '}
            <span className="text-accent-secondary font-medium">97% probability</span>.
          </p>
        </motion.div>
      </DataCard>

      {/* ── Regulator-Safe Interpretation ── */}
      <motion.div
        initial={{ opacity: 0, x: -30 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6, ease: EASE_SMOOTH }}
        className="bg-accent-primary-muted border border-accent-primary/30 rounded-card p-6"
      >
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 rounded-full bg-accent-primary/20 flex items-center justify-center flex-shrink-0">
            <ShieldCheck className="w-5 h-5 text-accent-primary" />
          </div>
          <div>
            <h3 className="text-heading-lg text-accent-primary mb-2">Regulator-Safe Interpretation</h3>
            <p className="text-body-md text-text-primary">
              The Monte Carlo simulation demonstrates that Copilot deployment presents limited downside
              risk with high probability of substantial benefit. Even under adverse scenarios, the
              investment remains strongly positive for ratepayers.
            </p>
          </div>
        </div>
      </motion.div>

      {/* ── Key Takeaways ── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {[
          {
            icon: ShieldCheck,
            title: 'Low-Risk Framing',
            text: '97%+ probability of positive ROI under all stress tests',
          },
          {
            icon: Target,
            title: 'High Probability of Benefits',
            text: '94% chance of exceeding 1,000% ROI',
          },
          {
            icon: AlertCircle,
            title: 'Limited Downside',
            text: 'Worst-case 1st percentile: 1,187% ROI',
          },
          {
            icon: Activity,
            title: 'Ratepayer Benefit',
            text: 'Operational savings flow directly to service reliability',
          },
        ].map((item, i) => (
          <motion.div
            key={item.title}
            variants={cardIn}
            initial="hidden"
            animate="show"
            custom={i}
            className="bg-bg-secondary border border-bg-quaternary rounded-card p-5 hover:border-accent-primary/30 transition-all duration-300"
          >
            <div className="w-9 h-9 rounded-lg bg-accent-primary-muted flex items-center justify-center mb-3">
              <item.icon className="w-4.5 h-4.5 text-accent-primary" />
            </div>
            <h4 className="text-heading-md text-text-primary mb-1">{item.title}</h4>
            <p className="text-body-sm text-text-secondary">{item.text}</p>
          </motion.div>
        ))}
      </div>

      {/* ── Simulation Logic (Expandable) ── */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.6, ease: EASE_SMOOTH }}
        className="bg-bg-secondary border border-bg-quaternary rounded-card"
      >
        <button
          onClick={() => setShowAlgorithm(!showAlgorithm)}
          className="w-full flex items-center justify-between px-5 py-4 text-left hover:bg-bg-tertiary/30 transition-colors rounded-card"
        >
          <span className="text-heading-md text-text-primary">View Simulation Algorithm</span>
          <ChevronDown
            className={cn(
              'w-5 h-5 text-text-secondary transition-transform duration-300',
              showAlgorithm && 'rotate-180'
            )}
          />
        </button>
        <AnimatePresence initial={false}>
          {showAlgorithm && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.4, ease: EASE_SMOOTH }}
              className="overflow-hidden"
            >
              <div className="px-5 pb-5">
                <div className="bg-bg-primary border border-bg-quaternary rounded-lg p-4 font-mono text-body-sm text-text-secondary overflow-x-auto">
                  <div className="space-y-1">
                    <p>
                      <span className="text-accent-info">1.</span>{' '}
                      <span className="text-text-primary">Initialize:</span>{' '}
                      <span className="text-chart-5">results</span> = []
                    </p>
                    <p>
                      <span className="text-accent-info">2.</span>{' '}
                      <span className="text-accent-primary">For</span> i ={' '}
                      <span className="text-chart-5">1</span> to{' '}
                      <span className="text-chart-5">10,000</span>:
                    </p>
                    <p className="pl-4">
                      <span className="text-accent-info">3.</span>{' '}
                      <span className="text-text-tertiary">Draw productivity hours from defined distributions</span>
                    </p>
                    <p className="pl-4">
                      <span className="text-accent-info">4.</span>{' '}
                      <span className="text-text-tertiary">Draw operational efficiencies from defined distributions</span>
                    </p>
                    <p className="pl-4">
                      <span className="text-accent-info">5.</span>{' '}
                      <span className="text-text-tertiary">Draw cost variables from defined distributions</span>
                    </p>
                    <p className="pl-4">
                      <span className="text-accent-info">6.</span>{' '}
                      <span className="text-text-primary">Compute</span>{' '}
                      <span className="text-chart-5">productivity_value</span> = &Sigma;(hours &times; rate &times; headcount)
                    </p>
                    <p className="pl-4">
                      <span className="text-accent-info">7.</span>{' '}
                      <span className="text-text-primary">Compute</span>{' '}
                      <span className="text-chart-5">operational_savings</span> = truck_roll + outage + CS + trading
                    </p>
                    <p className="pl-4">
                      <span className="text-accent-info">8.</span>{' '}
                      <span className="text-text-primary">Compute</span>{' '}
                      <span className="text-chart-5">total_benefit</span> = productivity + operational
                    </p>
                    <p className="pl-4">
                      <span className="text-accent-info">9.</span>{' '}
                      <span className="text-text-primary">Compute</span>{' '}
                      <span className="text-chart-5">total_cost</span> = licenses + training
                    </p>
                    <p className="pl-4">
                      <span className="text-accent-info">10.</span>{' '}
                      <span className="text-text-primary">Compute</span>{' '}
                      <span className="text-chart-5">ROI</span> = (benefit - cost) / cost
                    </p>
                    <p className="pl-4">
                      <span className="text-accent-info">11.</span>{' '}
                      <span className="text-chart-5">Store result</span>
                    </p>
                    <p>
                      <span className="text-accent-info">12.</span>{' '}
                      <span className="text-text-primary">Analyze:</span> mean, median, stddev, percentiles of results
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
