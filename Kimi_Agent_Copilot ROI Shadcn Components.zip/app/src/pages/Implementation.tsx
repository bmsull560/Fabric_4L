import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Map,
  Clock,
  Wrench,
  Headset,
  Monitor,
  Rocket,
  CheckSquare,
  ChevronDown,
  ArrowRight,
  Users,
  Target,
  TrendingUp,
  BookOpen,
  Flag,
  Calendar,
  Shield,
  BarChart3,
  Award,
  Zap,
  AlertTriangle,
  Lightbulb,
  CircleDot,
} from 'lucide-react';
import DataCard from '../components/DataCard';

// ── Data ────────────────────────────────────────────────────────────

interface TimelineMilestone {
  month: number;
  milestone: string;
  deliverable: string;
  owner: string;
}

interface Phase {
  num: number;
  name: string;
  months: string;
  color: string;
  bgColor: string;
  icon: React.ElementType;
  milestones: TimelineMilestone[];
}

const phases: Phase[] = [
  {
    num: 1,
    name: 'Foundation',
    months: 'Months 1-4',
    color: '#60A5FA',
    bgColor: 'rgba(96,165,250,0.12)',
    icon: Shield,
    milestones: [
      { month: 1, milestone: 'Executive kickoff', deliverable: 'Steering committee formed, charter signed', owner: 'CEO/CIO' },
      { month: 1, milestone: 'Pilot selection', deliverable: '400 IT workers identified for pilot', owner: 'IT Director' },
      { month: 2, milestone: 'Training launch', deliverable: 'Pilot group training completed', owner: 'L&D Lead' },
      { month: 2, milestone: 'Baseline measurement', deliverable: 'Pre-deployment productivity audit', owner: 'Finance' },
      { month: 3, milestone: 'Pilot evaluation', deliverable: 'Pilot ROI assessment, go/no-go', owner: 'Steering Committee' },
      { month: 3, milestone: 'Scale planning', deliverable: 'Full rollout plan, change management', owner: 'PMO' },
      { month: 4, milestone: 'Foundation review', deliverable: 'Foundation phase gate review', owner: 'Board' },
    ],
  },
  {
    num: 2,
    name: 'Scale',
    months: 'Months 5-8',
    color: '#4ADE80',
    bgColor: 'rgba(74,222,128,0.12)',
    icon: TrendingUp,
    milestones: [
      { month: 5, milestone: 'Corporate rollout', deliverable: '+2,000 corporate knowledge workers onboarded', owner: 'IT Director' },
      { month: 6, milestone: 'Field deployment', deliverable: '+1,500 field technicians onboarded', owner: 'Operations' },
      { month: 6, milestone: 'Customer service', deliverable: '+1,000 CS reps onboarded', owner: 'Customer Ops' },
      { month: 7, milestone: 'Integration', deliverable: 'Workflow integration with ERP, CRM, SCADA', owner: 'Integration Team' },
      { month: 7, milestone: 'Governance', deliverable: 'Copilot governance framework operational', owner: 'Compliance' },
      { month: 8, milestone: 'Scale review', deliverable: '4,000+ users active, scale gate review', owner: 'Steering Committee' },
    ],
  },
  {
    num: 3,
    name: 'Optimization',
    months: 'Months 9-12',
    color: '#D4A853',
    bgColor: 'rgba(212,168,83,0.12)',
    icon: Award,
    milestones: [
      { month: 9, milestone: 'Full deployment', deliverable: '6,000 users fully operational', owner: 'IT Director' },
      { month: 9, milestone: 'Advanced use', deliverable: 'Custom Copilot agents deployed', owner: 'AI Team' },
      { month: 10, milestone: 'Optimization', deliverable: 'Workflow tuning, prompt library maturity', owner: 'Power Users' },
      { month: 11, milestone: 'Measurement', deliverable: 'Full Year 1 ROI measurement', owner: 'Finance' },
      { month: 11, milestone: 'Planning', deliverable: 'Year 2 expansion planning (7,000-10,000)', owner: 'Strategy' },
      { month: 12, milestone: 'Board review', deliverable: 'Annual board review, Year 2 approval', owner: 'CEO/CFO' },
    ],
  },
];

const kpiCategories = [
  {
    name: 'Productivity KPIs',
    icon: Clock,
    color: '#60A5FA',
    metrics: [
      { kpi: 'Hours saved per user/month', target: '> 8 hrs', measurement: 'Time-motion survey', frequency: 'Monthly' },
      { kpi: 'Feature adoption rate', target: '> 70%', measurement: 'Usage analytics', frequency: 'Weekly' },
      { kpi: 'Active daily users', target: '> 80%', measurement: 'Login tracking', frequency: 'Daily' },
      { kpi: 'Prompt effectiveness score', target: '> 4.0/5', measurement: 'User feedback', frequency: 'Monthly' },
      { kpi: 'Time to proficiency', target: '< 4 weeks', measurement: 'Training assessment', frequency: 'Per cohort' },
    ],
  },
  {
    name: 'Operations KPIs',
    icon: Wrench,
    color: '#4ADE80',
    metrics: [
      { kpi: 'Truck rolls per month', target: '-18%', measurement: 'Dispatch system', frequency: 'Monthly' },
      { kpi: 'Avg outage restoration', target: '-18%', measurement: 'Outage management', frequency: 'Monthly' },
      { kpi: 'AHT customer service', target: '-31%', measurement: 'Call center system', frequency: 'Weekly' },
      { kpi: 'Trading margin improvement', target: '+23%', measurement: 'Trading P&L', frequency: 'Monthly' },
      { kpi: 'Safety incident response', target: '+42%', measurement: 'Safety system', frequency: 'Monthly' },
    ],
  },
  {
    name: 'Customer KPIs',
    icon: Headset,
    color: '#D4A853',
    metrics: [
      { kpi: 'First-call resolution', target: '> 78%', measurement: 'Call center', frequency: 'Weekly' },
      { kpi: 'Customer satisfaction (CSAT)', target: '> 4.2/5', measurement: 'Post-call survey', frequency: 'Weekly' },
      { kpi: 'Net Promoter Score', target: '> 35', measurement: 'NPS survey', frequency: 'Quarterly' },
      { kpi: 'Complaint resolution time', target: '-25%', measurement: 'Case management', frequency: 'Monthly' },
      { kpi: 'Digital adoption rate', target: '> 60%', measurement: 'Portal analytics', frequency: 'Monthly' },
    ],
  },
  {
    name: 'IT KPIs',
    icon: Monitor,
    color: '#A78BFA',
    metrics: [
      { kpi: 'Incident response time', target: '-42%', measurement: 'ITSM system', frequency: 'Weekly' },
      { kpi: 'Code review velocity', target: '+28%', measurement: 'DevOps metrics', frequency: 'Bi-weekly' },
      { kpi: 'Security threat resolution', target: '+35%', measurement: 'SOC metrics', frequency: 'Weekly' },
      { kpi: 'System uptime', target: '> 99.9%', measurement: 'Monitoring', frequency: 'Real-time' },
      { kpi: 'User support tickets', target: '-30%', measurement: 'ITSM system', frequency: 'Monthly' },
    ],
  },
];

interface TransitionGuide {
  from: string;
  fromColor: string;
  to: string;
  toColor: string;
  timeline: string;
  investment: string;
  objective: string;
  actions: string[];
  successCriteria: string[];
  investmentDetail: { item: string; amount: string }[];
  expectedOutcomes: string[];
  risks: { risk: string; mitigation: string }[];
}

const transitions: TransitionGuide[] = [
  {
    from: 'Initiation',
    fromColor: '#64748B',
    to: 'Adoption',
    toColor: '#60A5FA',
    timeline: '2-3 months',
    investment: '$45K',
    objective: 'Move from pilot deployment to widespread daily adoption across the initial user base.',
    actions: [
      'Deploy Copilot to 10% pilot group (600 users)',
      'Establish champion network (12 champions, 2 per department)',
      'Create use case repository (target: 50 documented use cases)',
      'Baseline productivity measurement (pre-deployment survey)',
      'IT support desk training (8 hours per agent)',
      'Executive sponsorship program (monthly executive demos)',
      'Feedback loop establishment (weekly pulse surveys)',
    ],
    successCriteria: [
      '> 60% daily active usage in pilot group',
      '> 30 documented productivity use cases',
      '> 4.0/5 user satisfaction score',
      'Zero critical security incidents',
    ],
    investmentDetail: [
      { item: 'Training', amount: '$25K' },
      { item: 'Change management', amount: '$12K' },
      { item: 'Support', amount: '$8K' },
    ],
    expectedOutcomes: [
      '+120% ROI improvement',
      'Pilot group productivity: +6 hrs/user/month',
      'Foundation for scale phase',
    ],
    risks: [
      { risk: 'Low pilot adoption', mitigation: 'Champion network + executive mandate' },
      { risk: 'Technical issues', mitigation: 'Dedicated IT support + Microsoft support' },
    ],
  },
  {
    from: 'Adoption',
    fromColor: '#60A5FA',
    to: 'Integration',
    toColor: '#2DD4BF',
    timeline: '3-4 months',
    investment: '$85K',
    objective: 'Integrate Copilot with core business systems and establish data connectivity for workflow automation.',
    actions: [
      'Connect Copilot to ERP, CRM, and SCADA systems',
      'Deploy unified data connectors',
      'Enable semantic search across document repositories',
      'Create workflow automation templates',
      'Establish data governance policies',
      'Train power users on custom integrations',
      'Launch internal Copilot app marketplace',
    ],
    successCriteria: [
      '> 5 core systems connected',
      '> 100 automated workflows active',
      'Data quality score > 85%',
      '< 2s average query response time',
    ],
    investmentDetail: [
      { item: 'Integration development', amount: '$45K' },
      { item: 'Data connectors', amount: '$22K' },
      { item: 'Training', amount: '$18K' },
    ],
    expectedOutcomes: [
      '+340% ROI improvement',
      'Workflow automation: 25% of manual tasks',
      'Cross-system data access enabled',
    ],
    risks: [
      { risk: 'Integration complexity', mitigation: 'Phased integration with fallback' },
      { risk: 'Data quality issues', mitigation: 'Data cleansing before integration' },
    ],
  },
  {
    from: 'Integration',
    fromColor: '#2DD4BF',
    to: 'Orchestration',
    toColor: '#4ADE80',
    timeline: '3-4 months',
    investment: '$120K',
    objective: 'Enable multi-system orchestration with governance framework and cross-functional workflows.',
    actions: [
      'Deploy Copilot governance framework',
      'Enable multi-step business process automation',
      'Launch audit trail and compliance reporting',
      'Create cross-department workflow templates',
      'Implement risk management protocols',
      'Establish change advisory board',
      'Deploy monitoring and alerting systems',
    ],
    successCriteria: [
      'Governance framework 100% operational',
      '> 50 cross-system workflows',
      'Compliance score > 95%',
      'All actions auditable',
    ],
    investmentDetail: [
      { item: 'Governance platform', amount: '$55K' },
      { item: 'Compliance tooling', amount: '$35K' },
      { item: 'Process engineering', amount: '$30K' },
    ],
    expectedOutcomes: [
      '+680% ROI improvement',
      'Full regulatory compliance achieved',
      'Board-ready risk reporting',
    ],
    risks: [
      { risk: 'Governance resistance', mitigation: 'Executive sponsorship + change management' },
      { risk: 'Compliance gaps', mitigation: 'Regulatory advisor engagement' },
    ],
  },
  {
    from: 'Orchestration',
    fromColor: '#4ADE80',
    to: 'Acceleration',
    toColor: '#A3E635',
    timeline: '4-6 months',
    investment: '$180K',
    objective: 'Accelerate with autonomous agent deployment and AI-powered decision support systems.',
    actions: [
      'Deploy custom Copilot agents for key workflows',
      'Enable autonomous decision-making for L1/L2 tasks',
      'Launch predictive analytics dashboards',
      'Create agent marketplace for business units',
      'Implement agent performance monitoring',
      'Scale to 4,000+ active users',
      'Establish agent governance protocols',
    ],
    successCriteria: [
      '> 20 active AI agents deployed',
      'Agent accuracy > 85%',
      '> 4,000 daily active users',
      'Autonomous task completion > 40%',
    ],
    investmentDetail: [
      { item: 'Agent development', amount: '$95K' },
      { item: 'Azure AI services', amount: '$55K' },
      { item: 'Scale infrastructure', amount: '$30K' },
    ],
    expectedOutcomes: [
      '+1,100% ROI improvement',
      'Agent workforce handling 40% of tasks',
      'Exponential productivity growth begins',
    ],
    risks: [
      { risk: 'Agent reliability', mitigation: 'Human-in-the-loop + staged rollout' },
      { risk: 'Scale performance', mitigation: 'Load testing + Azure auto-scaling' },
    ],
  },
  {
    from: 'Acceleration',
    fromColor: '#A3E635',
    to: 'Expansion',
    toColor: '#D4A853',
    timeline: '6-8 months',
    investment: '$250K',
    objective: 'Expand cognitive augmentation across all business units and implement self-healing operations.',
    actions: [
      'Deploy cognitive augmentation for all 6,000 users',
      'Launch self-healing system monitoring',
      'Enable predictive maintenance workflows',
      'Create enterprise knowledge graph',
      'Implement continuous learning loops',
      'Establish AI center of excellence',
      'Deploy advanced analytics platform',
    ],
    successCriteria: [
      '6,000 users with Copilot access',
      '> 200 active workflows',
      'Predictive accuracy > 80%',
      'Self-healing coverage > 60%',
    ],
    investmentDetail: [
      { item: 'Enterprise expansion', amount: '$130K' },
      { item: 'Cognitive services', amount: '$75K' },
      { item: 'Advanced analytics', amount: '$45K' },
    ],
    expectedOutcomes: [
      '+1,650% ROI improvement',
      'Enterprise-wide AI augmentation',
      'Operational cost reduction: 25%',
    ],
    risks: [
      { risk: 'Change fatigue', mitigation: 'Gamification + recognition programs' },
      { risk: 'Skill gaps', mitigation: 'Continuous training + mentoring' },
    ],
  },
  {
    from: 'Expansion',
    fromColor: '#D4A853',
    to: 'Autonomy',
    toColor: '#F59E0B',
    timeline: '8-12 months',
    investment: '$320K',
    objective: 'Achieve autonomous operations with self-directing agent networks and predictive intelligence.',
    actions: [
      'Deploy autonomous agent mesh network',
      'Enable self-optimization workflows',
      'Launch real-time predictive operations center',
      'Implement autonomous capital allocation',
      'Create self-service AI model training',
      'Establish autonomous security response',
      'Deploy enterprise AI operating system',
    ],
    successCriteria: [
      '> 50 autonomous agents networked',
      'Self-optimization coverage > 80%',
      'Human intervention < 20% of decisions',
      'System reliability > 99.95%',
    ],
    investmentDetail: [
      { item: 'Autonomous platform', amount: '$170K' },
      { item: 'ML/AI infrastructure', amount: '$95K' },
      { item: 'Operations center', amount: '$55K' },
    ],
    expectedOutcomes: [
      '+2,200% ROI improvement',
      'Autonomous operations majority',
      'Strategic AI partnership with Microsoft',
    ],
    risks: [
      { risk: 'Autonomy trust', mitigation: 'Gradual autonomy increase + oversight' },
      { risk: 'System complexity', mitigation: 'Modular architecture + rollback' },
    ],
  },
  {
    from: 'Autonomy',
    fromColor: '#F59E0B',
    to: 'Symbiosis',
    toColor: '#F97316',
    timeline: '12-18 months',
    investment: '$380K',
    objective: 'Achieve human-AI symbiosis with seamless collaboration and collective intelligence.',
    actions: [
      'Deploy human-AI collaboration platform',
      'Enable collective intelligence workflows',
      'Launch real-time strategy optimization',
      'Create adaptive organizational structures',
      'Implement continuous cultural evolution',
      'Establish AI ethics board',
      'Deploy singularity readiness assessment',
    ],
    successCriteria: [
      'Human-AI collaboration score > 90%',
      'Collective intelligence active',
      'Strategic decision AI-augmented > 75%',
      'Cultural AI integration complete',
    ],
    investmentDetail: [
      { item: 'Symbiosis platform', amount: '$200K' },
      { item: 'Organizational design', amount: '$110K' },
      { item: 'Ethics & governance', amount: '$70K' },
    ],
    expectedOutcomes: [
      '+2,800% ROI improvement',
      'Human-AI symbiotic operations',
      'Market leadership position',
    ],
    risks: [
      { risk: 'Cultural resistance', mitigation: 'Leadership alignment + storytelling' },
      { risk: 'Ethical concerns', mitigation: 'Transparent AI + ethics oversight' },
    ],
  },
  {
    from: 'Symbiosis',
    fromColor: '#F97316',
    to: 'Self-Optimization',
    toColor: '#EF4444',
    timeline: '18-24 months',
    investment: '$450K',
    objective: 'Enable enterprise self-optimization with continuous autonomous improvement and strategic foresight.',
    actions: [
      'Deploy self-optimization engine',
      'Enable autonomous strategic planning',
      'Launch market prediction models',
      'Create self-evolving process architecture',
      'Implement autonomous innovation pipeline',
      'Establish pre-Singularity protocols',
      'Deploy quantum-ready encryption',
    ],
    successCriteria: [
      'Self-optimization coverage > 95%',
      'Strategic foresight accuracy > 85%',
      'Autonomous innovation > 50% of pipeline',
      'Pre-Singularity protocols active',
    ],
    investmentDetail: [
      { item: 'Self-optimization engine', amount: '$240K' },
      { item: 'Strategic AI', amount: '$130K' },
      { item: 'Infrastructure', amount: '$80K' },
    ],
    expectedOutcomes: [
      '+3,400% ROI improvement',
      'Self-optimizing enterprise',
      'Competitive moat established',
    ],
    risks: [
      { risk: 'Over-optimization', mitigation: 'Human oversight + guardrails' },
      { risk: 'External disruption', mitigation: 'Scenario planning + agility' },
    ],
  },
  {
    from: 'Self-Optimization',
    fromColor: '#EF4444',
    to: 'Pre-Singularity',
    toColor: '#F0F2F7',
    timeline: '24-36 months',
    investment: '$520K',
    objective: 'Achieve pre-Singularity operations with full cognitive enterprise capabilities and strategic AI partnership.',
    actions: [
      'Deploy cognitive enterprise operating system',
      'Enable full autonomous strategy execution',
      'Launch universal AI interface',
      'Create self-evolving AI architecture',
      'Establish AI governance at scale',
      'Deploy singularity monitoring systems',
      'Create post-Singularity transition plan',
    ],
    successCriteria: [
      'Full cognitive enterprise active',
      'AI strategy execution > 90%',
      'Human-AI integration > 98%',
      'Singularity readiness > 95%',
    ],
    investmentDetail: [
      { item: 'Cognitive OS', amount: '$280K' },
      { item: 'Strategic AI', amount: '$150K' },
      { item: 'Future-proofing', amount: '$90K' },
    ],
    expectedOutcomes: [
      '+4,200% ROI improvement',
      'Pre-Singularity operations',
      'Industry transformation leadership',
    ],
    risks: [
      { risk: 'Unforeseen AI capabilities', mitigation: 'Adaptive governance + research' },
      { risk: 'Regulatory evolution', mitigation: 'Proactive regulator engagement' },
    ],
  },
];

const playbookSteps = [
  { step: 1, title: 'Assess current level', desc: 'Use the maturity scorecard to determine your current capability level' },
  { step: 2, title: 'Select target level', desc: 'Choose the next level based on strategic priorities' },
  { step: 3, title: 'Follow the guide', desc: 'Execute each action item in the transition guide' },
  { step: 4, title: 'Track progress', desc: 'Use the KPI framework to measure advancement' },
  { step: 5, title: 'Iterate', desc: 'Return to assessment after each transition' },
];

// ── Animation helpers ───────────────────────────────────────────────

const fadeUp = {
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] },
};

const stagger = (i: number) => ({
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4, delay: i * 0.08, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] },
});

// ── Accordion Component ─────────────────────────────────────────────

function AccordionItem({
  transition,
  isOpen,
  onToggle,
  index,
}: {
  transition: TransitionGuide;
  isOpen: boolean;
  onToggle: () => void;
  index: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      className="border border-bg-quaternary rounded-lg overflow-hidden"
    >
      <button
        onClick={onToggle}
        className="w-full flex items-center gap-3 px-4 py-3 bg-bg-tertiary/40 hover:bg-bg-tertiary transition-colors text-left"
      >
        {/* From badge */}
        <span
          className="px-2 py-0.5 rounded text-label-sm font-bold shrink-0"
          style={{ backgroundColor: `${transition.fromColor}25`, color: transition.fromColor }}
        >
          {transition.from}
        </span>
        <ArrowRight className="w-3.5 h-3.5 text-text-tertiary shrink-0" />
        {/* To badge */}
        <span
          className="px-2 py-0.5 rounded text-label-sm font-bold shrink-0"
          style={{ backgroundColor: `${transition.toColor}25`, color: transition.toColor }}
        >
          {transition.to}
        </span>

        <div className="ml-auto flex items-center gap-3 shrink-0">
          <span className="text-body-sm text-text-tertiary">{transition.timeline}</span>
          <span className="text-mono-sm text-accent-primary">{transition.investment}</span>
          <ChevronDown
            className={`w-4 h-4 text-text-tertiary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}
          />
        </div>
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] }}
            className="overflow-hidden"
          >
            <div className="p-4 space-y-4">
              {/* Objective */}
              <div>
                <span className="text-label-sm text-text-tertiary">Objective</span>
                <p className="text-body-md text-text-primary mt-1">{transition.objective}</p>
              </div>

              {/* Key Actions */}
              <div>
                <span className="text-label-sm text-text-tertiary">Key Actions</span>
                <div className="mt-2 space-y-1.5">
                  {transition.actions.map((action, ai) => (
                    <div key={ai} className="flex items-start gap-2">
                      <CheckSquare className="w-4 h-4 text-accent-primary mt-0.5 shrink-0" />
                      <span className="text-body-sm text-text-secondary">{action}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Success Criteria */}
                <div>
                  <span className="text-label-sm text-text-tertiary">Success Criteria</span>
                  <div className="mt-2 space-y-1.5">
                    {transition.successCriteria.map((criterion, ci) => (
                      <div key={ci} className="flex items-start gap-2">
                        <Target className="w-4 h-4 text-accent-secondary mt-0.5 shrink-0" />
                        <span className="text-body-sm text-text-secondary">{criterion}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Investment Detail */}
                <div>
                  <span className="text-label-sm text-text-tertiary">Investment Breakdown</span>
                  <div className="mt-2 space-y-1.5">
                    {transition.investmentDetail.map((item, ii) => (
                      <div key={ii} className="flex items-center justify-between">
                        <span className="text-body-sm text-text-secondary">{item.item}</span>
                        <span className="text-mono-sm text-accent-primary">{item.amount}</span>
                      </div>
                    ))}
                    <div className="border-t border-bg-quaternary pt-1 mt-1 flex items-center justify-between">
                      <span className="text-body-sm text-text-primary font-medium">Total</span>
                      <span className="text-mono-sm text-accent-primary font-bold">{transition.investment}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Expected Outcomes */}
              <div>
                <span className="text-label-sm text-text-tertiary">Expected Outcomes</span>
                <div className="flex flex-wrap gap-2 mt-2">
                  {transition.expectedOutcomes.map((outcome, oi) => (
                    <span
                      key={oi}
                      className="px-3 py-1 rounded-full text-body-sm bg-accent-secondary-muted text-accent-secondary"
                    >
                      {outcome}
                    </span>
                  ))}
                </div>
              </div>

              {/* Risks */}
              <div>
                <span className="text-label-sm text-text-tertiary">Risks & Mitigation</span>
                <div className="mt-2 space-y-2">
                  {transition.risks.map((risk, ri) => (
                    <div key={ri} className="flex items-start gap-3 bg-bg-tertiary rounded-lg p-3">
                      <AlertTriangle className="w-4 h-4 text-accent-tertiary mt-0.5 shrink-0" />
                      <div>
                        <span className="text-body-sm text-accent-tertiary font-medium">{risk.risk}</span>
                        <div className="flex items-center gap-1.5 mt-1">
                          <ArrowRight className="w-3 h-3 text-accent-primary" />
                          <span className="text-body-sm text-accent-primary">{risk.mitigation}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

// ── Main Component ──────────────────────────────────────────────────

export default function Implementation() {
  const [openAccordion, setOpenAccordion] = useState<number | null>(0);

  const toggleAccordion = (index: number) => {
    setOpenAccordion((prev) => (prev === index ? null : index));
  };

  return (
    <div className="px-8 py-6 space-y-6">
      {/* ── Page Header ── */}
      <motion.div {...fadeUp}>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-lg bg-accent-primary-muted flex items-center justify-center">
            <Map className="w-5 h-5 text-accent-primary" />
          </div>
          <div>
            <h1 className="text-display-md text-text-primary font-semibold">Implementation Roadmap & KPIs</h1>
            <p className="text-body-md text-text-secondary">12-month execution plan, ongoing KPIs, and transformation playbook</p>
          </div>
        </div>
      </motion.div>

      {/* ── 12-Month Implementation Roadmap ── */}
      <motion.div {...fadeUp}>
        <DataCard title="12-Month Implementation Roadmap" subtitle="Foundation → Scale → Optimization">
          {/* Timeline track */}
          <div className="relative mt-4 mb-6">
            <div className="flex items-center justify-between px-2">
              {Array.from({ length: 12 }, (_, i) => (
                <div key={i} className="flex flex-col items-center">
                  <div
                    className={`w-3 h-3 rounded-full border-2 ${
                      i < 4 ? 'bg-blue-500 border-blue-500' : i < 8 ? 'bg-green-500 border-green-500' : 'bg-amber-500 border-amber-500'
                    }`}
                  />
                  <span className="text-[10px] text-text-tertiary mt-1">M{i + 1}</span>
                </div>
              ))}
            </div>
            {/* Phase bands */}
            <div className="flex mt-2 h-2 rounded-full overflow-hidden">
              <div className="w-[33.33%] bg-blue-500/50" />
              <div className="w-[33.33%] bg-green-500/50" />
              <div className="w-[33.34%] bg-amber-500/50" />
            </div>
          </div>

          {/* Phase cards */}
          <div className="space-y-4">
            {phases.map((phase, pi) => {
              const Icon = phase.icon;
              return (
                <motion.div
                  key={phase.num}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{
                    duration: 0.4,
                    delay: pi * 0.12,
                    ease: [0.22, 1, 0.36, 1] as [number, number, number, number],
                  }}
                  className="border border-bg-quaternary rounded-xl overflow-hidden"
                >
                  {/* Phase header */}
                  <div
                    className="px-4 py-3 flex items-center gap-3"
                    style={{ backgroundColor: phase.bgColor }}
                  >
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: `${phase.color}20` }}
                    >
                      <Icon className="w-4 h-4" style={{ color: phase.color }} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-heading-md text-text-primary font-semibold">
                          Phase {phase.num}: {phase.name}
                        </span>
                        <span
                          className="text-label-sm px-2 py-0.5 rounded"
                          style={{ backgroundColor: `${phase.color}20`, color: phase.color }}
                        >
                          {phase.months}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Milestones table */}
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-[600px]">
                      <thead>
                        <tr className="bg-bg-tertiary/50">
                          {['Month', 'Milestone', 'Deliverable', 'Owner'].map((h) => (
                            <th key={h} className="text-left px-4 py-2.5 text-label-sm text-text-tertiary font-medium">
                              {h}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {phase.milestones.map((m, mi) => (
                          <tr key={mi} className="border-b border-bg-quaternary/50 hover:bg-bg-tertiary/20 transition-colors">
                            <td className="px-4 py-2.5">
                              <span
                                className="text-label-sm font-bold px-1.5 py-0.5 rounded"
                                style={{ backgroundColor: `${phase.color}15`, color: phase.color }}
                              >
                                M{m.month}
                              </span>
                            </td>
                            <td className="px-4 py-2.5 text-body-sm text-text-primary font-medium">{m.milestone}</td>
                            <td className="px-4 py-2.5 text-body-sm text-text-secondary">{m.deliverable}</td>
                            <td className="px-4 py-2.5 text-body-sm text-text-tertiary">{m.owner}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </DataCard>
      </motion.div>

      {/* ── Ongoing KPI Framework ── */}
      <motion.div {...fadeUp}>
        <DataCard title="Ongoing KPI Framework" subtitle="Monthly tracking, quarterly board reporting">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mt-4">
            {kpiCategories.map((cat, ci) => {
              const Icon = cat.icon;
              return (
                <motion.div
                  key={cat.name}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: ci * 0.12 }}
                  className="bg-bg-tertiary/40 border border-bg-quaternary rounded-xl overflow-hidden hover:border-accent-primary/30 transition-all duration-300"
                >
                  {/* Category header */}
                  <div className="px-4 py-3 flex items-center gap-3" style={{ backgroundColor: `${cat.color}10` }}>
                    <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${cat.color}20` }}>
                      <Icon className="w-5 h-5" style={{ color: cat.color }} />
                    </div>
                    <h3 className="text-heading-md text-text-primary font-semibold">{cat.name}</h3>
                  </div>

                  {/* Metrics table */}
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-[400px]">
                      <thead>
                        <tr className="bg-bg-tertiary/30">
                          {['KPI', 'Target', 'Measurement', 'Freq.'].map((h) => (
                            <th key={h} className="text-left px-3 py-2 text-label-sm text-text-tertiary font-medium">
                              {h}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {cat.metrics.map((m, mi) => (
                          <tr key={mi} className="border-b border-bg-quaternary/30 hover:bg-bg-tertiary/20 transition-colors">
                            <td className="px-3 py-2 text-body-sm text-text-primary">{m.kpi}</td>
                            <td className="px-3 py-2 text-mono-sm" style={{ color: cat.color }}>
                              {m.target}
                            </td>
                            <td className="px-3 py-2 text-body-sm text-text-secondary">{m.measurement}</td>
                            <td className="px-3 py-2">
                              <span className="text-[10px] text-text-tertiary px-1.5 py-0.5 rounded bg-bg-quaternary/50">
                                {m.frequency}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </DataCard>
      </motion.div>

      {/* ── Copilot Transformation Playbook ── */}
      <motion.div {...fadeUp}>
        <DataCard title="Copilot Transformation Playbook" subtitle="Level-by-level transformation guides">
          {/* Playbook introduction */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-bg-tertiary/40 border border-bg-quaternary rounded-xl p-5 mt-3 mb-6"
          >
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-accent-primary-muted flex items-center justify-center shrink-0">
                <BookOpen className="w-6 h-6 text-accent-primary" />
              </div>
              <div>
                <h3 className="text-heading-md text-text-primary font-semibold mb-2">How to Use This Playbook</h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 md:grid-cols-5 gap-3">
                  {playbookSteps.map((step) => (
                    <div key={step.step} className="flex items-start gap-2">
                      <div className="w-6 h-6 rounded-full bg-accent-primary-muted flex items-center justify-center shrink-0 mt-0.5">
                        <span className="text-[11px] font-bold text-accent-primary">{step.step}</span>
                      </div>
                      <div>
                        <p className="text-body-sm text-text-primary font-medium">{step.title}</p>
                        <p className="text-[11px] text-text-tertiary leading-tight">{step.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Level-by-level accordion */}
          <div className="space-y-2">
            <h3 className="text-label-lg text-text-tertiary mb-3">Level-by-Level Transformation Guides</h3>
            {transitions.map((transition, index) => (
              <AccordionItem
                key={index}
                transition={transition}
                isOpen={openAccordion === index}
                onToggle={() => toggleAccordion(index)}
                index={index}
              />
            ))}
          </div>
        </DataCard>
      </motion.div>
    </div>
  );
}
