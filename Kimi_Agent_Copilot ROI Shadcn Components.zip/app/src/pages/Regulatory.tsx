import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Scale,
  AlertTriangle,
  TrendingDown,
  CheckCircle,
  Shield,
  Zap,
  Headset,
  ShieldCheck,
  FileCheck,
  FileText,
  Landmark,
  Copy,
  Check,
  ChevronDown,
  ChevronUp,
  ShieldAlert,
} from 'lucide-react';
import {
  PieChart as RePieChart,
  Pie,
  Cell,
  ResponsiveContainer,
} from 'recharts';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import KpiCard from '@/components/KpiCard';
import DataCard from '@/components/DataCard';
import NumberAnimation from '@/components/NumberAnimation';

const cardEasing = [0.22, 1, 0.36, 1] as [number, number, number, number];

/* ──────────────────────── DATA ──────────────────────── */

const pillars = [
  {
    icon: Scale,
    title: 'Prudence',
    description: 'Investment is reasonable and cost-effective based on rigorous financial analysis',
    evidence: 'Monte Carlo 10,000-iteration simulation confirms positive ROI with 100% probability',
    color: '#D4A853',
  },
  {
    icon: AlertTriangle,
    title: 'Necessity',
    description: 'Competitive and operational necessity for modern utility operations',
    evidence: 'Peer utilities deploying AI; operational efficiency required for rate competitiveness',
    color: '#60A5FA',
  },
  {
    icon: TrendingDown,
    title: 'Ratepayer Benefit',
    description: 'Direct operational savings flow to ratepayer value',
    evidence: '$22.1M in operational savings reduces rate pressure',
    color: '#4ADE80',
  },
  {
    icon: CheckCircle,
    title: 'Cost-Effectiveness',
    description: 'Lowest-cost method to achieve operational improvements',
    evidence: '$2.88M cost vs $103.9M benefit — 36:1 return',
    color: '#A78BFA',
  },
  {
    icon: Shield,
    title: 'Operational Risk Reduction',
    description: 'Reduces operational risk through improved decision quality',
    evidence: 'Faster outage restoration, improved safety compliance',
    color: '#F472B6',
  },
];

const ratepayerCategories = [
  {
    icon: Zap,
    title: 'Outage Response & Reliability',
    annualValue: '$4.1M',
    impacts: [
      '18% faster outage restoration',
      'SAIDI improvement: 2.3 minutes/customer/year',
      'Fewer extended outages through predictive dispatch',
    ],
    metric: '99.97% uptime target support',
    color: '#D4A853',
  },
  {
    icon: Headset,
    title: 'Customer Service Performance',
    annualValue: '$4.8M',
    impacts: [
      '31% reduction in average handle time',
      '79% first-call resolution (up from 68%)',
      '24/7 AI-assisted support availability',
    ],
    metric: 'J.D. Power score improvement: +12 points',
    color: '#4ADE80',
  },
  {
    icon: ShieldCheck,
    title: 'Safety & Workforce Risk',
    annualValue: '$2.1M',
    impacts: [
      '42% faster safety incident documentation',
      'Improved compliance tracking reduces violations',
      'Real-time safety guidance for field workers',
    ],
    metric: 'OSHA recordable rate: -15%',
    color: '#A78BFA',
  },
  {
    icon: FileCheck,
    title: 'Compliance & Auditability',
    annualValue: '$1.4M',
    impacts: [
      'Automated regulatory reporting',
      'Complete audit trail for all AI-assisted decisions',
      'Faster rate case preparation',
    ],
    metric: 'FERC audit preparation: 60% time reduction',
    color: '#60A5FA',
  },
];

const mandateTableRows = [
  { standard: 'Reliability Standards', mandate: 'IEEE 1366 / SAIDI/SAIFI targets', alignment: 'Predictive outage response', score: 95, evidence: 'Outage restoration -18%', color: '#D4A853' },
  { standard: 'Customer Service', mandate: 'PUC service quality benchmarks', alignment: 'AHT reduction, FCR improvement', score: 98, evidence: 'FCR 68%→79%', color: '#4ADE80' },
  { standard: 'Safety Standards', mandate: 'OSHA / state safety requirements', alignment: 'Safety documentation, compliance', score: 92, evidence: 'Incident response +42%', color: '#A78BFA' },
  { standard: 'Affordability', mandate: 'Rate increase limitations', alignment: 'Operational cost reduction', score: 100, evidence: '$22.1M savings', color: '#60A5FA' },
  { standard: 'Cybersecurity', mandate: 'NERC CIP requirements', alignment: 'Security analysis automation', score: 88, evidence: 'Threat response +35%', color: '#F472B6' },
  { standard: 'Environmental', mandate: 'Emissions reporting', alignment: 'Automated data collection', score: 85, evidence: 'Reporting time -40%', color: '#2DD4BF' },
  { standard: 'Data Privacy', mandate: 'State privacy laws', alignment: 'Microsoft 365 compliance', score: 100, evidence: 'Built-in compliance', color: '#D4A853' },
];

const riskData = [
  {
    risk: 'Adoption Variability',
    likelihood: 'Medium',
    impact: 'High',
    mitigation: 'Phased deployment with change management; champion network; adoption tracking dashboards',
    status: 'Mitigated' as const,
  },
  {
    risk: 'Data Governance',
    likelihood: 'Low',
    impact: 'Medium',
    mitigation: 'Microsoft 365 built-in compliance; retention policies; access controls; audit logging',
    status: 'Controlled' as const,
  },
  {
    risk: 'Workforce Resistance',
    likelihood: 'Medium',
    impact: 'Medium',
    mitigation: 'AI literacy training; executive sponsorship; show-me-don\'t-tell-me rollout; feedback loops',
    status: 'Mitigated' as const,
  },
  {
    risk: 'Over-Reliance on AI',
    likelihood: 'Low',
    impact: 'High',
    mitigation: 'Decision authority preserved; human-in-the-loop requirements; periodic review of AI-assisted decisions',
    status: 'Controlled' as const,
  },
  {
    risk: 'Regulatory Scrutiny',
    likelihood: 'Medium',
    impact: 'Medium',
    mitigation: 'Complete documentation; ratepayer-benefit-first narrative; PUC pre-filing consultation',
    status: 'Mitigated' as const,
  },
];

const positioningStatement = `The [Utility Name] proposes the prudent deployment of Microsoft 365 Copilot to 6,000 employees as a cost-effective operational improvement initiative. This investment, totaling $2.88 million annually, is justified by:

1. Documented operational savings of $22.1 million annually through reduced truck rolls, accelerated outage restoration, improved customer service efficiency, and enhanced energy trading optimization — savings that directly benefit ratepayers through reduced cost pressure;

2. Independent financial validation including a 10,000-iteration Monte Carlo simulation demonstrating positive return on investment with 100% probability under all stress-tested scenarios;

3. Ratepayer value creation of $12.4 million annually in direct service improvements including 18% faster outage response, 31% shorter customer service handle times, and 15% improvement in workforce safety metrics;

4. Regulatory compliance enhancement through automated reporting, complete audit trails, and improved data governance — reducing compliance costs by $1.4 million annually;

5. Limited downside risk with the ability to contract the deployment if expected benefits fail to materialize, protecting ratepayers from stranded costs.

The net benefit to ratepayers, after all costs, is estimated at $26.82 per customer per year, with a payback period of under six months. This investment is prudent, necessary, and in the public interest.`;

function StatusBadge({ status }: { status: 'Mitigated' | 'Controlled' | 'Open' }) {
  const cls =
    status === 'Mitigated'
      ? 'text-accent-secondary bg-accent-secondary-muted'
      : status === 'Controlled'
        ? 'text-accent-primary bg-accent-primary-muted'
        : 'text-accent-tertiary bg-accent-tertiary-muted';
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-md text-label-sm ${cls}`}>
      {status}
    </span>
  );
}

function ConfidenceBadge({ level }: { level: 'High' | 'Medium' | 'Low' }) {
  const cls =
    level === 'High'
      ? 'text-accent-tertiary bg-accent-tertiary-muted'
      : level === 'Medium'
        ? 'text-accent-primary bg-accent-primary-muted'
        : 'text-accent-secondary bg-accent-secondary-muted';
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-md text-label-sm ${cls}`}>
      {level}
    </span>
  );
}

/* ═══════════════════════════ PAGE ═══════════════════════════ */

export default function Regulatory() {
  const [copied, setCopied] = useState(false);
  const [expandedPillars, setExpandedPillars] = useState<Record<number, boolean>>({});
  const [expandedRisks, setExpandedRisks] = useState<Record<number, boolean>>({});

  const handleCopy = () => {
    navigator.clipboard.writeText(positioningStatement).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const togglePillar = (i: number) => {
    setExpandedPillars((prev) => ({ ...prev, [i]: !prev[i] }));
  };

  const toggleRisk = (i: number) => {
    setExpandedRisks((prev) => ({ ...prev, [i]: !prev[i] }));
  };

  const overallCompliance = Math.round(
    mandateTableRows.reduce((s, r) => s + r.score, 0) / mandateTableRows.length
  );

  return (
    <div>
      {/* ── Page Header ── */}
      <div className="px-8 py-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: cardEasing }}
        >
          <div className="flex items-center gap-3 mb-2">
            <Landmark className="w-5 h-5 text-accent-primary" />
            <span className="text-label-lg text-text-tertiary">REGULATORY</span>
          </div>
          <h1 className="text-display-xl text-text-primary font-bold tracking-tight">
            Regulatory &amp; Ratepayer Justification
          </h1>
          <p className="text-body-lg text-text-secondary mt-2 max-w-3xl">
            Ratepayer benefit analysis for Public Utilities Commission oversight.
            Demonstrates prudence, necessity, and ratepayer value creation.
          </p>
        </motion.div>
      </div>

      {/* ── KPI Strip ── */}
      <div className="px-8 pb-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <KpiCard
          icon={Scale}
          label="Total Ratepayer Value"
          value={12.4}
          valuePrefix="$"
          valueSuffix="M"
          valueDecimals={1}
          trend={{ direction: 'positive', text: '$26.82 per ratepayer/year' }}
          subtitle="Direct operational savings to ratepayers"
          index={0}
        />
        <KpiCard
          icon={CheckCircle}
          label="Overall Compliance Score"
          value={94}
          valueSuffix="%"
          subtitle="Weighted average across 7 mandates"
          trend={{ direction: 'positive', text: 'Meets all requirements' }}
          index={1}
        />
        <KpiCard
          icon={Shield}
          label="Justification Pillars"
          value={5}
          subtitle="PUC-ready justification framework"
          trend={{ direction: 'positive', text: 'All 5 validated' }}
          index={2}
        />
        <KpiCard
          icon={TrendingDown}
          label="Cost per Ratepayer"
          value={4.8}
          valuePrefix="$"
          valueSuffix="/yr"
          valueDecimals={2}
          subtitle="For 2.6M ratepayers"
          trend={{ direction: 'positive', text: 'Net benefit $26.82/yr' }}
          index={3}
        />
      </div>

      <div className="px-8 pb-8 space-y-5">
        {/* ── 5 Justification Pillars ── */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1, ease: cardEasing }}
          className="bg-bg-secondary border border-bg-quaternary rounded-card p-6"
        >
          <div className="flex items-center gap-3 mb-1">
            <FileText className="w-5 h-5 text-accent-primary" />
            <h2 className="text-heading-lg text-text-primary">Regulator-Facing Justification</h2>
          </div>
          <p className="text-body-sm text-text-tertiary mb-6">
            Five-pillar framework for PUC/state oversight filings
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {pillars.map((p, i) => {
              const Icon = p.icon;
              const isExpanded = expandedPillars[i];
              return (
                <motion.div
                  key={p.title}
                  initial={{ opacity: 0, y: 20, scale: 0.97 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  transition={{ duration: 0.5, delay: 0.1 * i, ease: cardEasing }}
                  className="bg-bg-primary border border-bg-quaternary rounded-card p-4 flex flex-col hover:border-bg-quaternary/80 transition-all duration-300 cursor-pointer"
                  onClick={() => togglePillar(i)}
                >
                  <div className="flex items-center gap-3 mb-2">
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center"
                      style={{ backgroundColor: `${p.color}20` }}
                    >
                      <Icon className="w-5 h-5" style={{ color: p.color }} />
                    </div>
                    <h3 className="text-heading-md text-text-primary">{p.title}</h3>
                  </div>
                  <p className="text-body-sm text-text-secondary flex-1">{p.description}</p>
                  <button
                    className="flex items-center gap-1 mt-3 text-body-sm text-text-tertiary hover:text-text-primary transition-colors"
                    onClick={(e) => {
                      e.stopPropagation();
                      togglePillar(i);
                    }}
                  >
                    {isExpanded ? (
                      <>
                        Less <ChevronUp className="w-3.5 h-3.5" />
                      </>
                    ) : (
                      <>
                        Evidence <ChevronDown className="w-3.5 h-3.5" />
                      </>
                    )}
                  </button>
                  {isExpanded && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      transition={{ duration: 0.25 }}
                      className="mt-2 p-2 bg-bg-tertiary/50 rounded text-body-sm"
                      style={{ color: p.color }}
                    >
                      {p.evidence}
                    </motion.div>
                  )}
                </motion.div>
              );
            })}
          </div>

          <div className="mt-4 flex items-center gap-2">
            <span className="px-3 py-1 bg-accent-primary-muted text-accent-primary rounded-md text-label-sm">
              PUC-READY
            </span>
            <span className="text-body-sm text-text-tertiary">
              All five pillars validated for regulatory filing
            </span>
          </div>
        </motion.div>

        {/* ── Ratepayer Value Model ── */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2, ease: cardEasing }}
        >
          <DataCard
            title="Direct Ratepayer Value Model"
            subtitle="Operational improvements that directly benefit ratepayers"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
              {ratepayerCategories.map((cat, i) => {
                const Icon = cat.icon;
                return (
                  <motion.div
                    key={cat.title}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.12 * i, ease: cardEasing }}
                    className="bg-bg-primary border border-bg-quaternary rounded-card p-4 hover:border-bg-quaternary/80 transition-all duration-300 group"
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <div
                        className="w-10 h-10 rounded-full flex items-center justify-center"
                        style={{ backgroundColor: `${cat.color}20` }}
                      >
                        <Icon className="w-5 h-5" style={{ color: cat.color }} />
                      </div>
                      <div>
                        <h3 className="text-heading-md text-text-primary">{cat.title}</h3>
                        <span className="text-mono-sm font-medium" style={{ color: cat.color }}>
                          {cat.annualValue}/yr
                        </span>
                      </div>
                    </div>
                    <ul className="space-y-1.5 mb-3">
                      {cat.impacts.map((imp, j) => (
                        <li key={j} className="flex items-start gap-2 text-body-sm text-text-secondary">
                          <span className="w-1 h-1 rounded-full bg-accent-primary mt-2 flex-shrink-0" />
                          {imp}
                        </li>
                      ))}
                    </ul>
                    <div className="border-t border-bg-quaternary pt-2 mt-auto">
                      <span className="text-label-sm text-text-tertiary">Key metric: </span>
                      <span className="text-body-sm font-medium" style={{ color: cat.color }}>
                        {cat.metric}
                      </span>
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {/* Summary Bar */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5, ease: cardEasing }}
              className="mt-5 bg-bg-tertiary rounded-lg p-4 grid grid-cols-2 lg:grid-cols-4 gap-4"
            >
              <div>
                <span className="text-label-sm text-text-tertiary block">Total Direct Ratepayer Value</span>
                <span className="text-mono-lg text-accent-primary">
                  <NumberAnimation value={12.4} prefix="$" suffix="M/yr" decimals={1} />
                </span>
              </div>
              <div>
                <span className="text-label-sm text-text-tertiary block">Cost per Ratepayer</span>
                <span className="text-mono-md text-text-primary">$4.80/yr</span>
                <span className="text-body-sm text-text-tertiary ml-2">(2.6M ratepayers)</span>
              </div>
              <div>
                <span className="text-label-sm text-text-tertiary block">Benefit per Ratepayer</span>
                <span className="text-mono-md text-accent-secondary">$31.62/yr</span>
              </div>
              <div>
                <span className="text-label-sm text-text-tertiary block">Net Ratepayer Benefit</span>
                <span className="text-mono-md text-accent-primary">$26.82/yr per customer</span>
              </div>
            </motion.div>
          </DataCard>
        </motion.div>

        {/* ── Regulatory Mandate Alignment ── */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3, ease: cardEasing }}
          className="grid grid-cols-1 lg:grid-cols-3 gap-5"
        >
          <div className="lg:col-span-2">
            <DataCard
              title="Alignment with Regulatory Mandates"
              subtitle="Compliance scoring across regulatory standards"
            >
              <div className="overflow-x-auto mt-4">
                <table className="w-full">
                  <thead>
                    <tr className="bg-bg-tertiary">
                      <th className="text-label-sm text-text-tertiary text-left px-3 py-3">Standard</th>
                      <th className="text-label-sm text-text-tertiary text-left px-3 py-3">Mandate</th>
                      <th className="text-label-sm text-text-tertiary text-left px-3 py-3">Copilot Alignment</th>
                      <th className="text-label-sm text-text-tertiary text-center px-3 py-3">Score</th>
                      <th className="text-label-sm text-text-tertiary text-left px-3 py-3">Evidence</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mandateTableRows.map((row, i) => (
                      <motion.tr
                        key={row.standard}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.35 + i * 0.05 }}
                        className="border-b border-bg-quaternary hover:bg-bg-tertiary/30 transition-colors"
                      >
                        <td className="px-3 py-3 text-body-md text-text-primary font-medium">
                          {row.standard}
                        </td>
                        <td className="px-3 py-3 text-body-sm text-text-secondary">
                          {row.mandate}
                        </td>
                        <td className="px-3 py-3 text-body-sm text-text-secondary">
                          {row.alignment}
                        </td>
                        <td className="px-3 py-3 text-center">
                          <span
                            className="text-mono-sm font-semibold"
                            style={{ color: row.color }}
                          >
                            {row.score}%
                          </span>
                        </td>
                        <td className="px-3 py-3 text-body-sm text-text-tertiary">
                          {row.evidence}
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </DataCard>
          </div>

          {/* Compliance Gauge */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4, ease: cardEasing }}
          >
            <DataCard
              title="Overall Compliance"
              subtitle="Weighted average score"
            >
              <div className="flex flex-col items-center justify-center py-6">
                <div className="relative w-40 h-40">
                  <ResponsiveContainer width="100%" height="100%">
                    <RePieChart>
                      <Pie
                        data={[
                          { name: 'Compliant', value: overallCompliance },
                          { name: 'Gap', value: 100 - overallCompliance },
                        ]}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={70}
                        startAngle={90}
                        endAngle={-270}
                        dataKey="value"
                        stroke="none"
                        animationBegin={300}
                        animationDuration={1000}
                      >
                        <Cell fill="#D4A853" />
                        <Cell fill="#232D42" />
                      </Pie>
                    </RePieChart>
                  </ResponsiveContainer>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <motion.span
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.8 }}
                      className="text-mono-lg text-accent-primary"
                    >
                      {overallCompliance}%
                    </motion.span>
                  </div>
                </div>
                <p className="text-body-md text-text-secondary mt-4 text-center">
                  Meets or exceeds all regulatory requirements
                </p>
              </div>
            </DataCard>
          </motion.div>
        </motion.div>

        {/* ── Regulatory Positioning Statement (shadcn Alert) ── */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.45, ease: cardEasing }}
        >
          <Alert className="border-accent-primary bg-accent-primary-muted">
            <FileText className="h-5 w-5 text-accent-primary" />
            <AlertTitle className="text-heading-lg text-accent-primary">
              Regulator-Safe Positioning Statement
            </AlertTitle>
            <AlertDescription className="mt-2">
              <p className="text-body-sm text-text-tertiary mb-4">
                Verbatim language for PUC/state oversight filings
              </p>
              <div className="bg-bg-primary border border-bg-quaternary rounded-lg p-5 font-mono text-body-md text-text-secondary whitespace-pre-line leading-relaxed">
                {positioningStatement}
              </div>
              <div className="mt-4 flex justify-end">
                <button
                  onClick={handleCopy}
                  className="flex items-center gap-2 px-4 py-2 rounded-button bg-bg-tertiary border border-bg-quaternary text-body-md text-text-secondary hover:text-text-primary hover:border-accent-primary/40 transition-all"
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4 text-accent-secondary" />
                      <span className="text-accent-secondary">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      Copy to Clipboard
                    </>
                  )}
                </button>
              </div>
            </AlertDescription>
          </Alert>
        </motion.div>

        {/* ── Risk Assessment Table ── */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5, ease: cardEasing }}
        >
          <DataCard
            title="Risk Assessment &amp; Mitigation"
            subtitle="Regulatory and operational risks with mitigations"
          >
            <div className="overflow-x-auto mt-4">
              <table className="w-full">
                <thead>
                  <tr className="bg-bg-tertiary">
                    <th className="text-label-sm text-text-tertiary text-left px-4 py-3">Risk</th>
                    <th className="text-label-sm text-text-tertiary text-center px-4 py-3">Likelihood</th>
                    <th className="text-label-sm text-text-tertiary text-center px-4 py-3">Impact</th>
                    <th className="text-label-sm text-text-tertiary text-center px-4 py-3">Status</th>
                    <th className="text-label-sm text-text-tertiary text-left px-4 py-3">Mitigation</th>
                  </tr>
                </thead>
                <tbody>
                  {riskData.map((risk, i) => {
                    const isExpanded = expandedRisks[i];
                    return (
                      <motion.tr
                        key={risk.risk}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.55 + i * 0.05 }}
                        className="border-b border-bg-quaternary hover:bg-bg-tertiary/30 transition-colors"
                      >
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <ShieldAlert className="w-4 h-4 text-accent-tertiary flex-shrink-0" />
                            <span className="text-body-md text-text-primary font-medium">
                              {risk.risk}
                            </span>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-center">
                          <ConfidenceBadge level={risk.likelihood as 'High' | 'Medium' | 'Low'} />
                        </td>
                        <td className="px-4 py-3 text-center">
                          <ConfidenceBadge level={risk.impact as 'High' | 'Medium' | 'Low'} />
                        </td>
                        <td className="px-4 py-3 text-center">
                          <StatusBadge status={risk.status} />
                        </td>
                        <td className="px-4 py-3 text-body-sm text-text-secondary max-w-xs">
                          <button
                            onClick={() => toggleRisk(i)}
                            className="text-left hover:text-text-primary transition-colors"
                          >
                            {isExpanded ? risk.mitigation : `${risk.mitigation.slice(0, 50)}...`}
                            <span className="text-accent-primary ml-1">
                              {isExpanded ? 'less' : 'more'}
                            </span>
                          </button>
                        </td>
                      </motion.tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </DataCard>
        </motion.div>

        {/* ── Regulator-Safe Monte Carlo Interpretation ── */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.55, ease: cardEasing }}
          className="grid grid-cols-1 md:grid-cols-3 gap-4"
        >
          <div className="bg-accent-primary-muted border border-accent-primary/30 rounded-card p-5 flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-accent-primary flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-body-md text-text-primary">
                Monte Carlo simulation provides the probabilistic rigor that regulators expect.
              </p>
              <p className="text-body-sm text-text-secondary mt-1">
                100% probability of positive ROI with 94% probability of exceeding 1,000% ROI.
              </p>
            </div>
          </div>
          <div className="bg-accent-secondary-muted border border-accent-secondary/30 rounded-card p-5 flex items-start gap-3">
            <TrendingDown className="w-5 h-5 text-accent-secondary flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-body-md text-text-primary">Limited downside protection.</p>
              <p className="text-body-sm text-text-secondary mt-1">
                Even in the 1st percentile, ROI exceeds 1,100%.
              </p>
            </div>
          </div>
          <div className="bg-accent-info-muted border border-accent-info/30 rounded-card p-5 flex items-start gap-3">
            <Shield className="w-5 h-5 text-accent-info flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-body-md text-text-primary">Ratepayer protection built in.</p>
              <p className="text-body-sm text-text-secondary mt-1">
                The contraction option ensures no stranded costs.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
