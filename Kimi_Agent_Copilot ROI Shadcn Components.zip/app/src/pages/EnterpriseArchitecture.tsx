import { motion } from 'framer-motion';
import {
  Layers,
  Rocket,
  GitBranch,
  Cpu,
  Zap,
  Users,
  FileText,
  Search,
  Shield,
  TrendingUp,
  Award,
  Target,
  ChevronRight,
  Monitor,
  Smartphone,
  MessageSquare,
  Eye,
  Workflow,
  Database,
  Server,
  Brain,
  BarChart3,
  Cog,
  Sparkles,
  Network,
  Bot,
  Settings,
  Share2,
  Box,
  Lock,
  CheckCircle2,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';
import DataCard from '../components/DataCard';

// ── Data ────────────────────────────────────────────────────────────

const architectureLayers = [
  {
    num: 1,
    name: 'Human Interface Layer',
    color: '#60A5FA',
    gradientFrom: 'from-blue-500',
    gradientTo: 'to-blue-600',
    borderColor: 'border-blue-500/40',
    bgGlow: 'bg-blue-500/5',
    description: 'Natural language interaction, multimodal input, accessibility, personalization',
    strategicFunction: 'Universal access to AI capabilities across all employee touchpoints',
    capabilities: ['Copilot Chat', 'Voice Interface', 'Mobile Apps', 'Accessibility'],
    systems: ['Teams', 'Outlook', 'Word', 'Excel', 'PowerPoint', 'SharePoint'],
    icon: Monitor,
  },
  {
    num: 2,
    name: 'Workflow Engine Layer',
    color: '#2DD4BF',
    gradientFrom: 'from-teal-500',
    gradientTo: 'to-teal-600',
    borderColor: 'border-teal-500/40',
    bgGlow: 'bg-teal-500/5',
    description: 'Process orchestration, task automation, approval flows, exception handling',
    strategicFunction: 'Embed AI into every business process for end-to-end automation',
    capabilities: ['Power Automate', 'Logic Apps', 'BPM Integration'],
    systems: ['Power Automate', 'Logic Apps', 'Azure Functions', 'Service Bus'],
    icon: Workflow,
  },
  {
    num: 3,
    name: 'Data Integration Layer',
    color: '#4ADE80',
    gradientFrom: 'from-green-500',
    gradientTo: 'to-green-600',
    borderColor: 'border-green-500/40',
    bgGlow: 'bg-green-500/5',
    description: 'Unified data fabric, real-time sync, governance, quality',
    strategicFunction: 'Unified data access enabling AI to reason across all enterprise data',
    capabilities: ['Dataverse', 'Azure Data Lake', 'ETL Pipelines', 'Quality Rules'],
    systems: ['Dataverse', 'Synapse', 'Data Lake', 'Purview', 'Fabric'],
    icon: Database,
  },
  {
    num: 4,
    name: 'Autonomous Agent Layer',
    color: '#A3E635',
    gradientFrom: 'from-lime-500',
    gradientTo: 'to-lime-600',
    borderColor: 'border-lime-500/40',
    bgGlow: 'bg-lime-500/5',
    description: 'Self-directing agents, multi-agent collaboration, goal decomposition',
    strategicFunction: 'Autonomous digital workforce handling complex multi-step operations',
    capabilities: ['Copilot Studio', 'Custom Agents', 'Agent Mesh'],
    systems: ['Copilot Studio', 'Bot Framework', 'AutoGen', 'Semantic Kernel'],
    icon: Bot,
  },
  {
    num: 5,
    name: 'Cognitive Augmentation Layer',
    color: '#D4A853',
    gradientFrom: 'from-amber-500',
    gradientTo: 'to-amber-600',
    borderColor: 'border-amber-500/40',
    bgGlow: 'bg-amber-500/5',
    description: 'Reasoning assistance, pattern recognition, predictive analytics',
    strategicFunction: 'Augment human intelligence with predictive models and pattern detection',
    capabilities: ['Azure OpenAI', 'Cognitive Services', 'Custom Models'],
    systems: ['Azure OpenAI', 'Cognitive Services', 'Speech', 'Vision'],
    icon: Brain,
  },
  {
    num: 6,
    name: 'Optimization Layer',
    color: '#F59E0B',
    gradientFrom: 'from-yellow-500',
    gradientTo: 'to-orange-500',
    borderColor: 'border-orange-500/40',
    bgGlow: 'bg-orange-500/5',
    description: 'Continuous improvement, resource optimization, constraint solving',
    strategicFunction: 'Self-healing systems that continuously improve without human intervention',
    capabilities: ['ML Models', 'Optimization Engines', 'Simulation'],
    systems: ['Azure ML', 'ONNX', 'Ray', 'Custom Models'],
    icon: Cog,
  },
  {
    num: 7,
    name: 'Strategic Intelligence Layer',
    color: '#F97316',
    gradientFrom: 'from-orange-600',
    gradientTo: 'to-red-500',
    borderColor: 'border-red-500/40',
    bgGlow: 'bg-red-500/5',
    description: 'Executive decision support, scenario planning, market intelligence',
    strategicFunction: 'Autonomous strategic planning and capital allocation optimization',
    capabilities: ['Power BI', 'Scenario Modeling', 'Competitive Intelligence'],
    systems: ['Power BI', 'Azure Analysis Services', 'Scenario Engine'],
    icon: Sparkles,
  },
];

const capabilityPhases = [
  {
    num: 1,
    title: 'Deploy',
    icon: Rocket,
    color: '#60A5FA',
    gradientFrom: 'from-blue-500',
    gradientTo: 'to-blue-600',
    focus: 'AI literacy, workflow mapping, enterprise integration',
    timeline: 'Months 1-12',
    maturity: 'Levels 1-3',
    layers: ['Human Interface', 'Workflow Engine'],
  },
  {
    num: 2,
    title: 'Orchestrate',
    icon: GitBranch,
    color: '#4ADE80',
    gradientFrom: 'from-green-500',
    gradientTo: 'to-green-600',
    focus: 'Multi-system workflows, agent deployment, governance',
    timeline: 'Months 13-24',
    maturity: 'Levels 4-5',
    layers: ['Data Integration', 'Autonomous Agent'],
  },
  {
    num: 3,
    title: 'Autonomize',
    icon: Cpu,
    color: '#D4A853',
    gradientFrom: 'from-amber-500',
    gradientTo: 'to-amber-600',
    focus: 'Autonomous agents, self-healing systems, predictive ops',
    timeline: 'Months 25-36',
    maturity: 'Levels 6-7',
    layers: ['Cognitive Augmentation', 'Optimization'],
  },
  {
    num: 4,
    title: 'Transcend',
    icon: Zap,
    color: '#A78BFA',
    gradientFrom: 'from-purple-500',
    gradientTo: 'to-purple-600',
    focus: 'Cognitive enterprise, strategic AI partnership, pre-Singularity ops',
    timeline: 'Months 37-60',
    maturity: 'Levels 8-10',
    layers: ['Strategic Intelligence'],
  },
];

const financialAlignment = [
  { layer: 'Human Interface', roi: 340, npv: 42, riskReduction: 'Medium', strategicLeverage: 'Low', color: '#60A5FA' },
  { layer: 'Workflow Engine', roi: 680, npv: 78, riskReduction: 'High', strategicLeverage: 'Medium', color: '#2DD4BF' },
  { layer: 'Data Integration', roi: 420, npv: 52, riskReduction: 'High', strategicLeverage: 'Medium', color: '#4ADE80' },
  { layer: 'Autonomous Agent', roi: 1200, npv: 120, riskReduction: 'High', strategicLeverage: 'Very High', color: '#A3E635' },
  { layer: 'Cognitive Augment', roi: 890, npv: 95, riskReduction: 'Medium', strategicLeverage: 'High', color: '#D4A853' },
  { layer: 'Optimization', roi: 560, npv: 68, riskReduction: 'Medium', strategicLeverage: 'Medium', color: '#F59E0B' },
  { layer: 'Strategic Intel', roi: 420, npv: 52, riskReduction: 'Low', strategicLeverage: 'Very High', color: '#F97316' },
];

const governanceCards = [
  {
    icon: Users,
    title: 'Human-in-the-Loop',
    items: [
      'Critical decisions require human validation',
      'Escalation protocols for high-stakes actions',
      'Override authority at every automation layer',
    ],
    color: '#60A5FA',
  },
  {
    icon: FileText,
    title: 'Audit Trails',
    items: [
      'Complete activity logging for all AI interactions',
      'Immutable records for regulatory compliance',
      '7-year retention for utility regulatory requirements',
    ],
    color: '#2DD4BF',
  },
  {
    icon: Search,
    title: 'Explainability',
    items: [
      'Every AI recommendation includes reasoning',
      'Source attribution for all generated content',
      'Confidence scoring for predictions',
    ],
    color: '#D4A853',
  },
  {
    icon: Shield,
    title: 'Ethical Guardrails',
    items: [
      'Bias detection and mitigation',
      'Fairness auditing across demographic groups',
      'Responsible AI principles enforcement',
    ],
    color: '#F97316',
  },
];

const deploymentPhases = [
  { phase: '1. Deploy', timeline: 'Months 1-12', focus: 'Human Interface + Workflow', systems: 'Teams, Outlook, Power Automate', investment: '$180K' },
  { phase: '2. Orchestrate', timeline: 'Months 13-24', focus: 'Data + Agents', systems: 'Dataverse, Copilot Studio', investment: '$320K' },
  { phase: '3. Autonomize', timeline: 'Months 25-36', focus: 'Cognitive + Optimization', systems: 'Azure OpenAI, ML', investment: '$280K' },
  { phase: '4. Transcend', timeline: 'Months 37-60', focus: 'Strategic Intelligence', systems: 'Full stack', investment: '$420K' },
];

// ── Animation helpers ───────────────────────────────────────────────

const fadeUp = {
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] },
};

const stagger = (i: number) => ({
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] },
});

// ── Main Component ──────────────────────────────────────────────────

export default function EnterpriseArchitecture() {
  return (
    <div className="px-8 py-6 space-y-6">
      {/* ── Page Header ── */}
      <motion.div {...fadeUp}>
        <div className="flex items-center gap-4 mb-2">
          <div className="w-10 h-10 rounded-lg bg-accent-primary-muted flex items-center justify-center">
            <Layers className="w-5 h-5 text-accent-primary" />
          </div>
          <div>
            <h1 className="text-display-md text-text-primary font-semibold">Singularity-Aligned Enterprise Architecture</h1>
            <p className="text-body-md text-text-secondary">Vertical architecture stack and horizontal capability progression</p>
          </div>
          <div className="ml-auto px-3 py-1.5 rounded-lg bg-accent-primary-muted border border-accent-primary/30">
            <span className="text-label-lg text-accent-primary font-bold">7 LAYERS × 4 PHASES</span>
          </div>
        </div>
      </motion.div>

      {/* ── 7-Layer Architecture Stack ── */}
      <motion.div {...fadeUp}>
        <DataCard title="Enterprise Architecture Stack" subtitle="7-layer vertical architecture from interface to strategic intelligence">
          <div className="relative mt-4 space-y-3">
            {/* Vertical connecting line */}
            <div className="absolute left-5 top-4 bottom-4 w-0.5 bg-gradient-to-b from-blue-500/30 via-teal-500/30 via-green-500/30 via-amber-500/30 to-orange-500/30 z-0" />

            {architectureLayers.map((layer, i) => {
              const Icon = layer.icon;
              return (
                <motion.div
                  key={layer.num}
                  initial={{ opacity: 0, x: -30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{
                    duration: 0.5,
                    delay: i * 0.1,
                    ease: [0.22, 1, 0.36, 1] as [number, number, number, number],
                  }}
                  className={`relative z-10 flex items-start gap-4 bg-bg-tertiary/60 ${layer.borderColor} border rounded-xl p-4 hover:bg-bg-tertiary transition-all duration-300 group`}
                >
                  {/* Layer number circle */}
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0 font-bold text-sm transition-transform group-hover:scale-110"
                    style={{ backgroundColor: `${layer.color}20`, color: layer.color }}
                  >
                    {layer.num}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Icon className="w-4 h-4" style={{ color: layer.color }} />
                      <h3 className="text-heading-md text-text-primary font-semibold">{layer.name}</h3>
                      <span
                        className="text-label-sm px-2 py-0.5 rounded border"
                        style={{ borderColor: `${layer.color}40`, color: layer.color }}
                      >
                        Layer {layer.num}
                      </span>
                    </div>
                    <p className="text-body-sm text-text-secondary mt-1">{layer.description}</p>
                    <p className="text-body-sm mt-1.5" style={{ color: layer.color }}>
                      <span className="font-medium">Strategic function:</span> {layer.strategicFunction}
                    </p>

                    {/* Capabilities */}
                    <div className="flex flex-wrap gap-2 mt-2">
                      {layer.capabilities.map((cap) => (
                        <span
                          key={cap}
                          className="text-[11px] font-medium px-2 py-0.5 rounded-md"
                          style={{ backgroundColor: `${layer.color}15`, color: layer.color }}
                        >
                          {cap}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Connecting arrow (except last) */}
                  {i < architectureLayers.length - 1 && (
                    <div className="absolute left-4 bottom-[-14px] z-20 flex items-center justify-center w-3 h-3">
                      <ChevronRight className="w-3 h-3 text-text-tertiary rotate-90" />
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </DataCard>
      </motion.div>

      {/* ── Capability Progression Flow ── */}
      <motion.div {...fadeUp}>
        <DataCard title="Horizontal Capability Progression" subtitle="4 phases of enterprise AI maturity">
          <div className="relative mt-6">
            {/* Connecting line */}
            <div className="hidden md:block absolute top-12 left-[12%] right-[12%] h-0.5 bg-bg-quaternary z-0" />

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 relative z-10">
              {capabilityPhases.map((phase, i) => {
                const Icon = phase.icon;
                return (
                  <motion.div
                    key={phase.num}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{
                      duration: 0.4,
                      delay: i * 0.15,
                      ease: [0.22, 1, 0.36, 1] as [number, number, number, number],
                    }}
                    className="flex flex-col items-center text-center"
                  >
                    {/* Icon circle */}
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center mb-3 relative"
                      style={{ backgroundColor: `${phase.color}20`, border: `2px solid ${phase.color}40` }}
                    >
                      <Icon className="w-6 h-6" style={{ color: phase.color }} />
                      {/* Phase connector dot */}
                      {i < capabilityPhases.length - 1 && (
                        <div className="hidden md:block absolute -right-6 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-bg-quaternary" />
                      )}
                    </div>

                    <span
                      className="text-label-lg font-bold px-3 py-1 rounded-md mb-2"
                      style={{ backgroundColor: `${phase.color}15`, color: phase.color }}
                    >
                      Phase {phase.num}
                    </span>
                    <h3 className="text-heading-md text-text-primary font-semibold mb-1">{phase.title}</h3>
                    <p className="text-body-sm text-text-secondary mb-2 max-w-[250px]">{phase.focus}</p>

                    <div className="flex items-center gap-3 text-[11px] text-text-tertiary">
                      <span className="px-2 py-0.5 rounded bg-bg-quaternary">{phase.timeline}</span>
                      <span
                        className="px-2 py-0.5 rounded"
                        style={{ backgroundColor: `${phase.color}15`, color: phase.color }}
                      >
                        {phase.maturity}
                      </span>
                    </div>

                    <div className="flex flex-wrap justify-center gap-1 mt-2">
                      {phase.layers.map((l) => (
                        <span key={l} className="text-[10px] text-text-tertiary px-1.5 py-0.5 rounded bg-bg-quaternary/50">
                          {l}
                        </span>
                      ))}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Phase flow arrows */}
          <div className="hidden md:flex items-center justify-center gap-2 mt-4">
            {capabilityPhases.slice(0, -1).map((_, i) => (
              <div key={i} className="flex items-center gap-1">
                <ChevronRight className="w-4 h-4 text-accent-primary animate-pulse" />
              </div>
            ))}
          </div>
        </DataCard>
      </motion.div>

      {/* ── Financial Alignment + Bar Chart ── */}
      <motion.div {...fadeUp}>
        <DataCard title="Architecture-Financial Alignment" subtitle="ROI contribution and NPV impact by architecture layer">
          <div className="overflow-x-auto mt-3">
            <table className="w-full min-w-[600px]">
              <thead>
                <tr className="bg-bg-tertiary">
                  {['Architecture Layer', 'ROI Contribution', 'NPV Impact', 'Risk Reduction', 'Strategic Leverage'].map((h) => (
                    <th key={h} className="text-left px-4 py-3 text-label-sm text-text-tertiary font-medium">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {financialAlignment.map((row, i) => (
                  <motion.tr
                    key={row.layer}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.06 }}
                    className="border-b border-bg-quaternary hover:bg-bg-tertiary/30 transition-colors"
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: row.color }} />
                        <span className="text-body-md text-text-primary font-medium">{row.layer}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-mono-sm" style={{ color: row.color }}>
                      +{row.roi.toLocaleString()}%
                    </td>
                    <td className="px-4 py-3 text-mono-sm text-accent-primary">${row.npv}M</td>
                    <td className="px-4 py-3">
                      <span
                        className={`text-body-sm font-medium px-2 py-0.5 rounded ${
                          row.riskReduction === 'High'
                            ? 'bg-accent-secondary-muted text-accent-secondary'
                            : row.riskReduction === 'Medium'
                            ? 'bg-accent-primary-muted text-accent-primary'
                            : 'bg-bg-quaternary text-text-tertiary'
                        }`}
                      >
                        {row.riskReduction}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`text-body-sm font-medium px-2 py-0.5 rounded ${
                          row.strategicLeverage === 'Very High'
                            ? 'bg-accent-secondary-muted text-accent-secondary'
                            : row.strategicLeverage === 'High'
                            ? 'bg-accent-info-muted text-accent-info'
                            : row.strategicLeverage === 'Medium'
                            ? 'bg-accent-primary-muted text-accent-primary'
                            : 'bg-bg-quaternary text-text-tertiary'
                        }`}
                      >
                        {row.strategicLeverage}
                      </span>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Bar chart */}
          <div className="h-[260px] mt-6">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={financialAlignment} layout="vertical" margin={{ top: 0, right: 30, left: 10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" horizontal={false} />
                <XAxis
                  type="number"
                  tick={{ fill: '#94A3B8', fontSize: 12 }}
                  stroke="rgba(148,163,184,0.3)"
                  label={{ value: 'ROI Contribution (%)', position: 'insideBottomRight', offset: -5, fill: '#64748B', fontSize: 12 }}
                />
                <YAxis
                  type="category"
                  dataKey="layer"
                  tick={{ fill: '#94A3B8', fontSize: 11 }}
                  stroke="rgba(148,163,184,0.3)"
                  width={120}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#111827',
                    border: '1px solid #232D42',
                    borderRadius: '8px',
                    fontSize: '13px',
                  }}
                  labelStyle={{ color: '#F0F2F7' }}
                  formatter={(value: number) => [`+${value.toLocaleString()}%`, 'ROI Contribution']}
                />
                <Bar dataKey="roi" radius={[0, 4, 4, 0]} barSize={20}>
                  {financialAlignment.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} fillOpacity={0.85} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </DataCard>
      </motion.div>

      {/* ── Governance & Safety ── */}
      <div>
        <motion.h2
          {...fadeUp}
          className="text-heading-lg text-text-primary mb-4"
        >
          Governance & Safety Architecture
        </motion.h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {governanceCards.map((card, i) => {
            const Icon = card.icon;
            return (
              <motion.div
                key={card.title}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{
                  duration: 0.4,
                  delay: i * 0.1,
                  ease: [0.22, 1, 0.36, 1] as [number, number, number, number],
                }}
                className="bg-bg-secondary border border-bg-quaternary rounded-card p-5 hover:border-accent-primary/30 transition-all duration-300"
              >
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center mb-3"
                  style={{ backgroundColor: `${card.color}15` }}
                >
                  <Icon className="w-5 h-5" style={{ color: card.color }} />
                </div>
                <h3 className="text-heading-md text-text-primary font-semibold mb-3">{card.title}</h3>
                <ul className="space-y-2">
                  {card.items.map((item, ii) => (
                    <li key={ii} className="flex items-start gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 mt-0.5 shrink-0" style={{ color: card.color }} />
                      <span className="text-body-sm text-text-secondary">{item}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* ── Deployment Strategy ── */}
      <motion.div {...fadeUp}>
        <DataCard title="Phased Architecture Deployment" subtitle="Deployment phases with timeline, focus, systems, and investment">
          <div className="overflow-x-auto mt-3">
            <table className="w-full min-w-[700px]">
              <thead>
                <tr className="bg-bg-tertiary">
                  {['Phase', 'Timeline', 'Focus Area', 'Systems Deployed', 'Investment'].map((h) => (
                    <th key={h} className="text-left px-4 py-3 text-label-sm text-text-tertiary font-medium">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {deploymentPhases.map((row, i) => (
                  <motion.tr
                    key={row.phase}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.06 }}
                    className="border-b border-bg-quaternary hover:bg-bg-tertiary/30 transition-colors"
                  >
                    <td className="px-4 py-3">
                      <span className="text-body-md text-text-primary font-medium">{row.phase}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-body-sm text-accent-primary">{row.timeline}</span>
                    </td>
                    <td className="px-4 py-3 text-body-sm text-text-secondary">{row.focus}</td>
                    <td className="px-4 py-3 text-body-sm text-text-secondary">{row.systems}</td>
                    <td className="px-4 py-3 text-mono-sm text-accent-primary">{row.investment}</td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </DataCard>
      </motion.div>

      {/* ── Systems-of-Systems Diagram ── */}
      <motion.div {...fadeUp}>
        <DataCard title="Systems-of-Systems Enterprise Architecture" subtitle="Component view of each architecture layer">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 mt-3">
            {architectureLayers.map((layer, i) => (
              <motion.div
                key={layer.num}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                className="bg-bg-tertiary/50 border border-bg-quaternary rounded-lg p-4"
              >
                <div className="flex items-center gap-2 mb-2">
                  <div
                    className="w-7 h-7 rounded-md flex items-center justify-center text-xs font-bold"
                    style={{ backgroundColor: `${layer.color}20`, color: layer.color }}
                  >
                    {layer.num}
                  </div>
                  <h4 className="text-body-md text-text-primary font-semibold truncate">{layer.name}</h4>
                </div>
                <div className="flex flex-wrap gap-1">
                  {layer.systems.map((sys) => (
                    <span
                      key={sys}
                      className="text-[11px] px-2 py-0.5 rounded border"
                      style={{
                        borderColor: `${layer.color}30`,
                        color: layer.color,
                        backgroundColor: `${layer.color}10`,
                      }}
                    >
                      {sys}
                    </span>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>

          {/* Layer connections visual */}
          <div className="mt-6 p-4 bg-bg-tertiary/30 border border-bg-quaternary rounded-lg">
            <div className="flex items-center gap-2 mb-4">
              <Network className="w-4 h-4 text-accent-primary" />
              <span className="text-label-lg text-text-tertiary">Layer Integration Map</span>
            </div>
            <div className="flex flex-col gap-1">
              {architectureLayers.map((layer, i) => {
                if (i === architectureLayers.length - 1) return null;
                const nextLayer = architectureLayers[i + 1];
                return (
                  <div key={layer.num} className="flex items-center gap-3">
                    <div
                      className="px-3 py-1.5 rounded border text-[11px] font-medium shrink-0"
                      style={{ borderColor: `${layer.color}40`, color: layer.color }}
                    >
                      {layer.name}
                    </div>
                    <div className="flex-1 h-px bg-bg-quaternary relative">
                      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-accent-primary/60" />
                    </div>
                    <div
                      className="px-3 py-1.5 rounded border text-[11px] font-medium shrink-0"
                      style={{ borderColor: `${nextLayer.color}40`, color: nextLayer.color }}
                    >
                      {nextLayer.name}
                    </div>
                    <span className="text-[10px] text-text-tertiary shrink-0">
                      {[
                        'Natural language triggers workflows',
                        'Workflows read/write unified data',
                        'Data feeds agent reasoning',
                        'Agents call cognitive APIs',
                        'Cognitive models power optimization',
                        'Optimization drives strategy',
                      ][i]}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </DataCard>
      </motion.div>
    </div>
  );
}
