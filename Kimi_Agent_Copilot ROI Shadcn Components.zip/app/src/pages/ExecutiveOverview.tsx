import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  TrendingUp,
  DollarSign,
  Wallet,
  Clock,
  BarChart3,
  GitBranch,
  Wrench,
  Calculator,
  Users,
  Target,
  ArrowDownRight,
  Zap,
  Clock3,
  ChevronRight,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';
import KpiCard from '../components/KpiCard';
import DataCard from '../components/DataCard';
import NumberAnimation from '../components/NumberAnimation';

const tabs = ['Business Case', 'Value Creation', 'Adoption Framework', 'Executive Summary'];

const kpiData = [
  {
    icon: TrendingUp,
    label: 'ANNUAL PRODUCTIVITY VALUE',
    value: 68.9,
    valuePrefix: '$',
    valueSuffix: 'M',
    valueDecimals: 1,
    trend: { direction: 'positive' as const, text: '+2,742% ROI' },
    subtitle: 'Mean from Monte Carlo',
  },
  {
    icon: DollarSign,
    label: 'TOTAL ANNUAL BENEFIT',
    value: 81.8,
    valuePrefix: '$',
    valueSuffix: 'M',
    valueDecimals: 1,
    trend: { direction: 'positive' as const, text: 'Conservative case' },
    subtitle: 'Range: $66.6M \u2013 $97M',
  },
  {
    icon: Wallet,
    label: 'ANNUAL COST',
    value: 2.88,
    valuePrefix: '$',
    valueSuffix: 'M',
    valueDecimals: 2,
    trend: { direction: 'negative' as const, text: 'All-employee licensing' },
    subtitle: '$30/user/month \u00d7 6,000 licenses',
  },
  {
    icon: Clock,
    label: 'PAYBACK PERIOD',
    value: 5.2,
    valueSuffix: ' months',
    valueDecimals: 1,
    trend: { direction: 'positive' as const, text: 'Sub-6 month' },
    subtitle: 'Conservative: 7 months',
  },
  {
    icon: BarChart3,
    label: '3-YEAR NPV',
    value: 171,
    valuePrefix: '$',
    valueSuffix: 'M',
    valueDecimals: 0,
    trend: { direction: 'positive' as const, text: '8% discount rate' },
    subtitle: 'DCF-adjusted',
  },
  {
    icon: GitBranch,
    label: 'REAL OPTIONS VALUE',
    value: 189,
    valuePrefix: '$',
    valueSuffix: 'M',
    valueDecimals: 0,
    trend: { direction: 'positive' as const, text: 'Black-Scholes derived' },
    subtitle: 'Strategic flexibility premium',
  },
];

const roiComparisonData = [
  { name: 'SMB ROI', value: 2180 },
  { name: 'Enterprise ROI', value: 3050 },
];

const functionData = [
  { function: 'Sales', savings: 8.2, driver: 'Faster deal cycles', icon: TrendingUp },
  { function: 'Finance', savings: 6.1, driver: 'Reporting automation', icon: Calculator },
  { function: 'Operations', savings: 15.4, driver: 'Truck roll reduction', icon: Wrench },
  { function: 'HR/Training', savings: 3.8, driver: 'Onboarding efficiency', icon: Users },
  { function: 'Executives', savings: 4.5, driver: 'Decision acceleration', icon: Target },
];

const valueCreationData = [
  {
    icon: Clock3,
    value: 395000,
    valuePrefix: '',
    valueSuffix: '',
    valueDecimals: 0,
    label: 'Total hours saved enterprise-wide',
    detail: 'IT workers save 15 hrs/mo, corporate knowledge workers 10 hrs/mo, field technicians 6 hrs/mo, customer service 8 hrs/mo',
  },
  {
    icon: TrendingUp,
    value: 12.9,
    valuePrefix: '$',
    valueSuffix: 'M',
    valueDecimals: 1,
    label: 'Annual revenue uplift',
    detail: 'Faster proposals, improved win rates, trading optimization, customer retention',
  },
  {
    icon: ArrowDownRight,
    value: 22.1,
    valuePrefix: '$',
    valueSuffix: 'M',
    valueDecimals: 1,
    label: 'Annual cost reduction',
    detail: 'Truck rolls, call handling, outage duration, training hours',
  },
  {
    icon: Zap,
    value: 47,
    valuePrefix: '',
    valueSuffix: '%',
    valueDecimals: 0,
    label: 'Faster executive decisions',
    detail: 'Real-time data synthesis, automated reporting, scenario modeling',
  },
];

const adoptionSteps = [
  {
    step: 1,
    title: 'Strategic Alignment',
    description: 'Executive sponsorship, use-case prioritization, success metrics definition',
    duration: 'Month 1',
  },
  {
    step: 2,
    title: 'Baseline Measurement',
    description: 'Pre-deployment productivity audit, workflow mapping, KPI establishment',
    duration: 'Months 1-2',
  },
  {
    step: 3,
    title: 'Financial Modeling',
    description: 'ROI projection, sensitivity analysis, scenario planning, board approval',
    duration: 'Months 2-3',
  },
  {
    step: 4,
    title: 'Risk & Sensitivity Analysis',
    description: 'Monte Carlo simulation, stress testing, mitigation planning',
    duration: 'Months 3-4',
  },
  {
    step: 5,
    title: 'Measurement & Reporting',
    description: 'Monthly KPI tracking, quarterly board reporting, continuous optimization',
    duration: 'Ongoing',
  },
];

const segmentData = [
  { segment: 'IT Workers', headcount: 2000, hrsSaved: 15, annualValue: 25.7 },
  { segment: 'Corporate Knowledge', headcount: 4000, hrsSaved: 10, annualValue: 34.3 },
  { segment: 'Field Technicians', headcount: 3000, hrsSaved: 6, annualValue: 15.4 },
  { segment: 'Customer Service', headcount: 1000, hrsSaved: 8, annualValue: 8.2 },
];

const totalHeadcount = segmentData.reduce((sum, s) => sum + s.headcount, 0);
const totalHrsSaved = segmentData.reduce((sum, s) => sum + s.headcount * s.hrsSaved, 0);
const totalAnnualValue = segmentData.reduce((sum, s) => sum + s.annualValue, 0);

export default function ExecutiveOverview() {
  const [activeTab, setActiveTab] = useState(0);

  return (
    <div className="px-8 py-6">
      {/* KPI Summary Strip */}
      <div className="grid grid-cols-6 gap-4 mb-8">
        {kpiData.map((kpi, index) => (
          <div key={kpi.label} className="col-span-6 sm:col-span-3 lg:col-span-2 xl:col-span-1">
            <KpiCard {...kpi} index={index} />
          </div>
        ))}
      </div>

      {/* Tab Navigation */}
      <div className="flex border-b border-bg-quaternary mb-6">
        {tabs.map((tab, i) => (
          <button
            key={tab}
            onClick={() => setActiveTab(i)}
            className={`px-5 py-3 text-body-md transition-all duration-200 relative ${
              activeTab === i ? 'text-text-primary' : 'text-text-secondary hover:text-text-primary'
            }`}
          >
            {tab}
            {activeTab === i && (
              <motion.div
                layoutId="activeTab"
                className="absolute bottom-0 left-0 right-0 h-0.5 bg-accent-primary"
                transition={{ duration: 0.2 }}
              />
            )}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
        >
          {/* Tab 1: Business Case */}
          {activeTab === 0 && (
            <div className="space-y-5">
              <div className="grid grid-cols-1 lg:grid-cols-5 gap-5">
                {/* Business Case Narrative */}
                <div className="lg:col-span-3">
                  <DataCard title="The Business Case for Enterprise-Wide Copilot Adoption">
                    <div className="space-y-4 text-body-md text-text-secondary">
                      <p>
                        A 10,000-employee public utility operating across four states faces a defining technology decision. Microsoft 365 Copilot represents not merely a productivity tool but a structural financial opportunity — one validated by rigorous modeling across multiple analytical frameworks.
                      </p>
                      <div className="space-y-3">
                        <div className="flex gap-3">
                          <div className="w-1 bg-accent-primary rounded-full flex-shrink-0" />
                          <div>
                            <span className="text-text-primary font-semibold">Enterprise ROI: </span>
                            <span>Enterprise-wide deployment of 6,000 Copilot licenses at $30/user/month generates an annual productivity value of $57.12M to $80.64M against an annual cost of $2.16M to $3.6M.</span>
                          </div>
                        </div>
                        <div className="flex gap-3">
                          <div className="w-1 bg-accent-secondary rounded-full flex-shrink-0" />
                          <div>
                            <span className="text-text-primary font-semibold">SMB ROI comparison: </span>
                            <span>Enterprise deployment achieves 40% higher per-license ROI than SMB deployments due to integration depth, workflow standardization, and cross-functional knowledge sharing.</span>
                          </div>
                        </div>
                        <div className="flex gap-3">
                          <div className="w-1 bg-chart-3 rounded-full flex-shrink-0" />
                          <div>
                            <span className="text-text-primary font-semibold">Revenue impact: </span>
                            <span>Revenue acceleration through faster proposal development, improved customer response times, and enhanced trading desk decision quality contributes $9.4M to $16.3M annually.</span>
                          </div>
                        </div>
                        <div className="flex gap-3">
                          <div className="w-1 bg-chart-4 rounded-full flex-shrink-0" />
                          <div>
                            <span className="text-text-primary font-semibold">Operational efficiency: </span>
                            <span>Operational efficiency gains — truck roll reduction, outage restoration acceleration, and customer service optimization — add $15M to $22M in annual value.</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </DataCard>
                </div>

                {/* ROI Comparison Chart */}
                <div className="lg:col-span-2">
                  <DataCard title="Enterprise vs SMB ROI">
                    <ResponsiveContainer width="100%" height={240}>
                      <BarChart data={roiComparisonData} layout="vertical" barSize={40}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" horizontal={false} />
                        <XAxis type="number" stroke="rgba(148,163,184,0.3)" tick={{ fill: '#64748B', fontSize: 12 }} />
                        <YAxis dataKey="name" type="category" stroke="rgba(148,163,184,0.3)" tick={{ fill: '#94A3B8', fontSize: 13 }} width={100} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#111827',
                            border: '1px solid #232D42',
                            borderRadius: '8px',
                            color: '#F0F2F7',
                            fontSize: '13px',
                          }}
                          formatter={(value: number) => [`${value.toLocaleString()}%`, 'ROI']}
                        />
                        <Bar dataKey="value" radius={[0, 6, 6, 0]}>
                          {roiComparisonData.map((_, index) => (
                            <Cell key={`cell-${index}`} fill={index === 0 ? '#64748B' : '#D4A853'} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </DataCard>
                </div>
              </div>

              {/* ROI by Function */}
              <DataCard title="ROI by Function">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
                  {functionData.map((item, index) => {
                    const Icon = item.icon;
                    return (
                      <motion.div
                        key={item.function}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{
                          duration: 0.4,
                          delay: index * 0.06,
                          ease: [0.22, 1, 0.36, 1] as [number, number, number, number],
                        }}
                        className="bg-bg-tertiary border border-bg-quaternary rounded-lg p-4 flex flex-col items-center text-center"
                      >
                        <Icon className="w-8 h-8 text-accent-primary mb-3" />
                        <span className="text-heading-md text-text-primary">{item.function}</span>
                        <span className="text-mono-md text-accent-primary mt-1">
                          <NumberAnimation value={item.savings} prefix="$" suffix="M" decimals={1} />
                        </span>
                        <span className="text-body-sm text-text-secondary mt-1">{item.driver}</span>
                      </motion.div>
                    );
                  })}
                </div>
              </DataCard>
            </div>
          )}

          {/* Tab 2: Value Creation */}
          {activeTab === 1 && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {valueCreationData.map((item, index) => {
                const Icon = item.icon;
                return (
                  <motion.div
                    key={item.label}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{
                      duration: 0.5,
                      delay: index * 0.1,
                      ease: [0.22, 1, 0.36, 1] as [number, number, number, number],
                    }}
                    className="bg-bg-secondary border border-bg-quaternary rounded-card p-6"
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-full bg-accent-primary-muted flex items-center justify-center flex-shrink-0">
                        <Icon className="w-6 h-6 text-accent-primary" />
                      </div>
                      <div className="flex-1">
                        <span className="text-mono-lg text-text-primary">
                          {item.valuePrefix === '$' ? '$' : ''}
                          <NumberAnimation
                            value={item.value}
                            decimals={item.valueDecimals}
                          />
                          {item.valueSuffix}
                        </span>
                        <p className="text-body-md text-text-primary font-medium mt-1">{item.label}</p>
                        <p className="text-body-sm text-text-secondary mt-2">{item.detail}</p>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}

          {/* Tab 3: Adoption Framework */}
          {activeTab === 2 && (
            <DataCard title="Enterprise Copilot Adoption Framework" subtitle="A phased approach to enterprise-wide deployment">
              <div className="flex flex-col md:flex-row gap-0 md:gap-4 mt-4">
                {adoptionSteps.map((step, index) => (
                  <motion.div
                    key={step.step}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{
                      duration: 0.5,
                      delay: index * 0.08,
                      ease: [0.22, 1, 0.36, 1] as [number, number, number, number],
                    }}
                    className="flex-1 flex flex-col items-center text-center relative"
                  >
                    {index < adoptionSteps.length - 1 && (
                      <div className="hidden md:block absolute top-6 left-[60%] right-[-40%] h-0.5 bg-bg-quaternary" />
                    )}
                    <div className="w-12 h-12 rounded-full bg-accent-primary border-2 border-accent-primary flex items-center justify-center text-text-inverse font-bold text-body-md z-10">
                      {step.step}
                    </div>
                    <h4 className="text-heading-md text-text-primary mt-4">{step.title}</h4>
                    <p className="text-body-sm text-text-secondary mt-2 px-2">{step.description}</p>
                    <span className="text-label-sm text-accent-primary mt-3 bg-accent-primary-muted px-3 py-1 rounded-md">
                      {step.duration}
                    </span>
                  </motion.div>
                ))}
              </div>
            </DataCard>
          )}

          {/* Tab 4: Executive Summary */}
          {activeTab === 3 && (
            <div className="space-y-5">
              <DataCard title="Executive Summary: Hard Numbers" subtitle="10,000-Employee Utility Profile \u2014 Consolidated Financial Impact">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Left Column */}
                  <div className="space-y-6">
                    <div>
                      <span className="text-label-lg text-text-tertiary">ROI RANGE</span>
                      <div className="text-mono-lg text-accent-primary mt-1">
                        <NumberAnimation value={2500} suffix="% \u2013 " decimals={0} />
                        <NumberAnimation value={3050} suffix="%" decimals={0} />
                      </div>
                      <span className="text-body-sm text-text-secondary">Conservative case</span>
                    </div>
                    <div>
                      <span className="text-label-lg text-text-tertiary">ANNUAL PRODUCTIVITY VALUE</span>
                      <div className="text-mono-lg text-text-primary mt-1">
                        <NumberAnimation value={68.9} prefix="$" suffix="M" decimals={1} />
                      </div>
                    </div>
                    <div>
                      <span className="text-label-lg text-text-tertiary">PAYBACK PERIOD</span>
                      <div className="text-mono-lg text-text-primary mt-1">
                        <NumberAnimation value={5.2} suffix=" months" decimals={1} />
                      </div>
                      <span className="text-body-sm text-text-secondary">Conservative: 7 months</span>
                    </div>
                    <div>
                      <span className="text-label-lg text-text-tertiary">HOURS SAVED MONTHLY</span>
                      <div className="text-mono-lg text-text-primary mt-1">
                        <NumberAnimation value={395000} suffix="" decimals={0} />
                      </div>
                    </div>
                  </div>

                  {/* Right Column - Segment Table */}
                  <div>
                    <span className="text-label-lg text-text-tertiary mb-3 block">SEGMENTED IMPACT BREAKDOWN</span>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="bg-bg-tertiary">
                            <th className="text-label-sm text-text-tertiary text-left px-4 py-3">Segment</th>
                            <th className="text-label-sm text-text-tertiary text-right px-4 py-3">Headcount</th>
                            <th className="text-label-sm text-text-tertiary text-right px-4 py-3">Hrs/Mo Saved</th>
                            <th className="text-label-sm text-text-tertiary text-right px-4 py-3">Annual Value</th>
                          </tr>
                        </thead>
                        <tbody>
                          {segmentData.map((row, i) => (
                            <tr
                              key={row.segment}
                              className={`border-b border-bg-quaternary hover:bg-bg-tertiary/50 transition-colors ${
                                i % 2 === 0 ? 'bg-bg-primary/50' : 'bg-bg-secondary'
                              }`}
                            >
                              <td className="text-body-md text-text-primary px-4 py-3">{row.segment}</td>
                              <td className="text-mono-sm text-text-secondary text-right px-4 py-3">
                                {row.headcount.toLocaleString()}
                              </td>
                              <td className="text-mono-sm text-text-secondary text-right px-4 py-3">{row.hrsSaved}</td>
                              <td className="text-mono-sm text-accent-primary text-right px-4 py-3">
                                ${row.annualValue.toFixed(1)}M
                              </td>
                            </tr>
                          ))}
                          <tr className="bg-bg-tertiary font-semibold">
                            <td className="text-body-md text-text-primary px-4 py-3">Total</td>
                            <td className="text-mono-sm text-text-primary text-right px-4 py-3">
                              {totalHeadcount.toLocaleString()}
                            </td>
                            <td className="text-mono-sm text-text-primary text-right px-4 py-3">
                              {totalHrsSaved.toLocaleString()}
                            </td>
                            <td className="text-mono-sm text-accent-primary text-right px-4 py-3">
                              ${totalAnnualValue.toFixed(1)}M
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>

                {/* CTA Row */}
                <div className="flex flex-wrap gap-4 mt-8 pt-6 border-t border-bg-quaternary">
                  <button className="animate-glow-pulse flex items-center gap-2 bg-accent-primary text-text-inverse px-5 py-2.5 rounded-button text-body-md font-medium hover:bg-accent-primary-hover transition-all duration-200 active:scale-[0.98]">
                    View Full ROI Model
                    <ChevronRight className="w-4 h-4" />
                  </button>
                  <button className="flex items-center gap-2 bg-bg-tertiary text-text-primary px-5 py-2.5 rounded-button text-body-md border border-bg-quaternary hover:border-accent-primary/40 hover:bg-bg-quaternary transition-all duration-200">
                    Download CFO Briefing
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </DataCard>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
