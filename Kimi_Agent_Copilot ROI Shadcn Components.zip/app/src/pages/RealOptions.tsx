import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  GitBranch,
  Maximize2,
  Minimize2,
  Timer,
  Layers,
  XCircle,
  TrendingUp,
  Shield,
  AlertTriangle,
  ChevronRight,
  Calculator,
  Info,
  BarChart3,
  FileText,
  Scale,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  ReferenceLine,
} from 'recharts';
import KpiCard from '../components/KpiCard';
import DataCard from '../components/DataCard';
import NumberAnimation from '../components/NumberAnimation';

/* ------------------------------------------------------------------ */
/*  DATA                                                               */
/* ------------------------------------------------------------------ */

/** NPV vs ROA comparison bar-chart data */
const npvRoaComparisonData = [
  { name: 'NPV (Traditional)', value: 171, fill: '#60A5FA' },
  { name: 'ROV (Real Options)', value: 189, fill: '#D4A853' },
];

/** Model inputs per design.md */
const modelInputs = [
  {
    param: 'Underlying Asset Value',
    symbol: 'S',
    value: '$171M',
    numeric: 171,
    description: 'NPV of expected cash flows',
    color: '#60A5FA',
  },
  {
    param: 'Exercise Cost',
    symbol: 'K',
    value: '$2.88M',
    numeric: 2.88,
    description: 'Annual cost (strike price)',
    color: '#F87171',
  },
  {
    param: 'Volatility',
    symbol: '\u03C3',
    value: '45%',
    numeric: 0.45,
    description: 'Uncertainty in cash flows',
    color: '#A78BFA',
  },
  {
    param: 'Time Horizon',
    symbol: 'T',
    value: '3 years',
    numeric: 3,
    description: 'Option expiration',
    color: '#2DD4BF',
  },
  {
    param: 'Risk-Free Rate',
    symbol: 'r',
    value: '4.5%',
    numeric: 0.045,
    description: '3-year Treasury yield',
    color: '#4ADE80',
  },
];

/** Black-Scholes calculation steps */
const calculationSteps = [
  {
    step: 1,
    title: 'd\u2081 calculation',
    lines: [
      'd\u2081 = [ln(S/K) + (r + \u03C3\u00B2/2) \u00D7 T] / (\u03C3\u00D7\u221AT)',
      'd\u2081 = [ln(171/2.88) + (0.045 + 0.45\u00B2/2) \u00D7 3] / (0.45 \u00D7 \u221A3)',
      'd\u2081 = [4.08 + 0.438] / 0.779',
      'd\u2081 = 5.80',
    ],
    result: 'd\u2081 = 5.80',
    highlight: 5.80,
  },
  {
    step: 2,
    title: 'd\u2082 calculation',
    lines: [
      'd\u2082 = d\u2081 - \u03C3\u00D7\u221AT',
      'd\u2082 = 5.80 - 0.779',
      'd\u2082 = 5.02',
    ],
    result: 'd\u2082 = 5.02',
    highlight: 5.02,
  },
  {
    step: 3,
    title: 'N(d\u2081) / N(d\u2082)',
    lines: [
      'N(d\u2081) = N(5.80) \u2248 0.999999',
      'N(d\u2082) = N(5.02) \u2248 0.999999',
    ],
    result: 'N(d\u2081) \u2248 N(d\u2082) \u2248 1.00',
    highlight: 1.0,
  },
  {
    step: 4,
    title: 'Discount factor',
    lines: [
      'e\u207B\u02B3\u1D40 = e\u207B\u2070\u00B7\u2070\u2074\u2075 \u00D7 \u00B3 = e\u207B\u2070\u00B7\u00B9\u00B3\u2075',
      'e\u207B\u02B3\u1D40 = 0.873',
    ],
    result: 'e\u207B\u02B3\u1D40 = 0.873',
    highlight: 0.873,
  },
  {
    step: 5,
    title: 'ROV computation',
    lines: [
      'C = S \u00D7 N(d\u2081) - K \u00D7 e\u207B\u02B3\u1D40 \u00D7 N(d\u2082)',
      'C = $171M \u00D7 1.0 - $2.88M \u00D7 0.873 \u00D7 1.0',
      'C = $171M - $2.51M',
      'C = $168.5M',
    ],
    result: 'ROV = $168.5M',
    highlight: 168.5,
  },
];

/** Portfolio of 5 real options */
const portfolioOptions = [
  {
    icon: Maximize2,
    title: 'Option to Expand',
    type: 'Growth Option',
    typeColor: '#4ADE80',
    description: 'Scale from 6,000 to 10,000 users',
    value: '$47M',
    numericValue: 47,
    trigger: 'Adoption exceeds 80% in Year 1',
    expiry: 'End of Year 2',
  },
  {
    icon: Minimize2,
    title: 'Option to Contract',
    type: 'Downside Protection',
    typeColor: '#D4A853',
    description: 'Reduce to 3,000 users if adoption lags',
    value: '$12M',
    numericValue: 12,
    trigger: 'Adoption below 50% at 12 months',
    expiry: 'Month 18',
  },
  {
    icon: Timer,
    title: 'Option to Defer',
    type: 'Timing Option',
    typeColor: '#60A5FA',
    description: 'Delay full rollout by 6 months',
    value: '$8M',
    numericValue: 8,
    trigger: 'Budget cycle timing or M&A activity',
    expiry: 'Month 6',
  },
  {
    icon: Layers,
    title: 'Option to Stage',
    type: 'Phased Rollout',
    typeColor: '#A78BFA',
    description: 'Phased deployment: 2,000 \u2192 4,000 \u2192 6,000',
    value: '$15M',
    numericValue: 15,
    trigger: 'Default deployment strategy',
    expiry: 'Month 24',
  },
  {
    icon: XCircle,
    title: 'Option to Abandon',
    type: 'Exit Option',
    typeColor: '#F87171',
    description: 'Terminate program with minimal sunk cost',
    value: '$2.88M',
    numericValue: 2.88,
    trigger: 'Catastrophic adoption failure (<10%)',
    expiry: 'Anytime',
  },
];

/** Expansion option scenarios */
const expansionScenarios = [
  {
    users: 7000,
    expansion: '+1,000 users',
    incrementalCost: '$360K/year',
    incrementalBenefit: '$11.5M/year',
    npvExpansion: '$28M',
    s: '$28M',
    k: '$360K',
    sigma: '35%',
    t: '2 years',
    r: '4.5%',
    d1: 8.42,
    d2: 7.93,
    nd1: 1.0,
    nd2: 1.0,
    optionValue: 27.7,
  },
  {
    users: 10000,
    expansion: '+4,000 users',
    incrementalCost: '$1.44M/year',
    incrementalBenefit: '$46M/year',
    npvExpansion: '$112M',
    s: '$112M',
    k: '$1.44M',
    sigma: '40%',
    t: '3 years',
    r: '4.5%',
    d1: 6.18,
    d2: 5.49,
    nd1: 1.0,
    nd2: 1.0,
    optionValue: 110.6,
  },
];

/** Expansion bar chart data */
const expansionChartData = [
  { name: '6,000\n(Base)', value: 171, fill: '#60A5FA' },
  { name: '7,000', value: 171 + 27.7, fill: '#D4A853' },
  { name: '10,000', value: 171 + 110.6, fill: '#4ADE80' },
];

/** Contraction scenarios */
const contractionScenarios = [
  {
    scenario: 'Mild Contraction',
    scale: '6,000 \u2192 4,500',
    costAvoided: '$540K/year',
    valueRetained: '75% of benefits',
    netImpact: -27.3,
  },
  {
    scenario: 'Moderate Contraction',
    scale: '6,000 \u2192 3,000',
    costAvoided: '$1.08M/year',
    valueRetained: '50% of benefits',
    netImpact: -54.4,
  },
  {
    scenario: 'Severe Contraction',
    scale: '6,000 \u2192 1,500',
    costAvoided: '$1.62M/year',
    valueRetained: '25% of benefits',
    netImpact: -81.6,
  },
];

/** Full portfolio summary data */
const portfolioSummary = [
  { option: 'Expand to 10,000', type: 'Growth', value: 110.6, probability: '65%', strategicValue: 'High', typeColor: '#4ADE80' },
  { option: 'Expand to 7,000', type: 'Growth', value: 27.7, probability: '80%', strategicValue: 'High', typeColor: '#4ADE80' },
  { option: 'Contract', type: 'Protection', value: 12, probability: '15%', strategicValue: 'Medium', typeColor: '#D4A853' },
  { option: 'Defer', type: 'Timing', value: 8, probability: '25%', strategicValue: 'Low', typeColor: '#60A5FA' },
  { option: 'Stage (Default)', type: 'Phased', value: 15, probability: '100%', strategicValue: 'High', typeColor: '#A78BFA' },
  { option: 'Abandon', type: 'Exit', value: 2.88, probability: '2%', strategicValue: 'Insurance', typeColor: '#F87171' },
];

/** Horizontal bar chart data for full portfolio */
const portfolioBarData = [
  { name: 'Expand to 10K', value: 110.6, fill: '#4ADE80' },
  { name: 'Expand to 7K', value: 27.7, fill: '#2DD4BF' },
  { name: 'Contract', value: 12, fill: '#D4A853' },
  { name: 'Stage', value: 15, fill: '#A78BFA' },
  { name: 'Defer', value: 8, fill: '#60A5FA' },
  { name: 'Abandon', value: 2.88, fill: '#F87171' },
];

/* ------------------------------------------------------------------ */
/*  CUSTOM RECHARTS TOOLTIP                                            */
/* ------------------------------------------------------------------ */

interface TooltipPayloadItem {
  name: string;
  value: number;
  color: string;
  payload?: Record<string, unknown>;
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: TooltipPayloadItem[];
  label?: string;
}

function CustomTooltip({ active, payload, label }: CustomTooltipProps) {
  if (!active || !payload || payload.length === 0) return null;
  return (
    <div className="bg-bg-secondary border border-bg-quaternary rounded-lg px-4 py-3 shadow-[0_4px_20px_rgba(0,0,0,0.3)]">
      <p className="text-body-sm text-text-primary font-medium mb-1">{label}</p>
      {payload.map((item, i) => (
        <p key={i} className="text-mono-sm" style={{ color: item.color }}>
          ${typeof item.value === 'number' ? item.value.toFixed(1) : item.value}M
        </p>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  EASING                                                             */
/* ------------------------------------------------------------------ */

const easeSmooth = [0.22, 1, 0.36, 1] as [number, number, number, number];

/* ------------------------------------------------------------------ */
/*  MAIN COMPONENT                                                     */
/* ------------------------------------------------------------------ */

export default function RealOptions() {
  const [expandedStep, setExpandedStep] = useState<number | null>(null);
  const [activeSection, setActiveSection] = useState('overview');

  const toggleStep = (step: number) => {
    setExpandedStep(expandedStep === step ? null : step);
  };

  return (
    <div className="px-8 py-6">
      {/* ====== PAGE HEADER ====== */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: easeSmooth }}
        className="mb-8"
      >
        <div className="flex items-center gap-3 mb-2">
          <GitBranch className="w-6 h-6 text-accent-primary" />
          <h1 className="text-display-lg text-text-primary font-bold">Real Options Analysis</h1>
          <span className="text-label-sm bg-accent-primary-muted text-accent-primary px-3 py-1 rounded-md">
            BLACK-SCHOLES MODEL
          </span>
        </div>
        <p className="text-body-lg text-text-secondary mt-2 max-w-4xl">
          Black-Scholes valuation of strategic flexibility in Copilot deployment — treating the investment as a portfolio of real options rather than a static NPV calculation.
        </p>
        <div className="mt-4 flex items-center gap-2 bg-accent-secondary-muted border border-accent-secondary/20 rounded-lg px-4 py-3">
          <TrendingUp className="w-5 h-5 text-accent-secondary flex-shrink-0" />
          <span className="text-body-md text-text-primary font-medium">
            ROV = $189M vs NPV = $171M — strategic flexibility adds $18M in value
          </span>
        </div>
      </motion.div>

      {/* ====== TAB NAVIGATION ====== */}
      <div className="flex border-b border-bg-quaternary mb-6 overflow-x-auto">
        {[
          { id: 'overview', label: 'Overview' },
          { id: 'inputs', label: 'Model Inputs' },
          { id: 'calculation', label: 'Black-Scholes' },
          { id: 'expansion', label: 'Expansion' },
          { id: 'contraction', label: 'Contraction' },
          { id: 'portfolio', label: 'Full Portfolio' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSection(tab.id)}
            className={`px-5 py-3 text-body-md transition-all duration-200 relative whitespace-nowrap ${
              activeSection === tab.id ? 'text-text-primary' : 'text-text-secondary hover:text-text-primary'
            }`}
          >
            {tab.label}
            {activeSection === tab.id && (
              <motion.div
                layoutId="roActiveTab"
                className="absolute bottom-0 left-0 right-0 h-0.5 bg-accent-primary"
                transition={{ duration: 0.2 }}
              />
            )}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={activeSection}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
        >
          {/* ============================================================ */}
          {/* SECTION: OVERVIEW  (Components 48-52)                         */}
          {/* ============================================================ */}
          {activeSection === 'overview' && (
            <div className="space-y-5">
              {/* KPI Summary Strip */}
              <div className="grid grid-cols-6 gap-4">
                {[
                  {
                    icon: Calculator,
                    label: 'NET PRESENT VALUE',
                    value: 171,
                    valuePrefix: '$',
                    valueSuffix: 'M',
                    valueDecimals: 0,
                    trend: { direction: 'positive' as const, text: 'Traditional DCF' },
                    subtitle: 'Fixed deployment path',
                  },
                  {
                    icon: GitBranch,
                    label: 'REAL OPTIONS VALUE',
                    value: 189,
                    valuePrefix: '$',
                    valueSuffix: 'M',
                    valueDecimals: 0,
                    trend: { direction: 'positive' as const, text: 'Black-Scholes' },
                    subtitle: 'Strategic flexibility premium',
                  },
                  {
                    icon: TrendingUp,
                    label: 'FLEXIBILITY PREMIUM',
                    value: 18,
                    valuePrefix: '$',
                    valueSuffix: 'M',
                    valueDecimals: 0,
                    trend: { direction: 'positive' as const, text: '+10.5% above NPV' },
                    subtitle: 'Value of adaptability',
                  },
                  {
                    icon: Maximize2,
                    label: 'EXPANSION OPTION',
                    value: 47,
                    valuePrefix: '$',
                    valueSuffix: 'M',
                    valueDecimals: 0,
                    trend: { direction: 'positive' as const, text: 'Most valuable option' },
                    subtitle: '6,000 \u2192 10,000 users',
                  },
                  {
                    icon: Shield,
                    label: 'CONTRACTION VALUE',
                    value: 12,
                    valuePrefix: '$',
                    valueSuffix: 'M',
                    valueDecimals: 0,
                    trend: { direction: 'positive' as const, text: 'Downside protection' },
                    subtitle: '15% exercise probability',
                  },
                  {
                    icon: BarChart3,
                    label: 'VOLATILITY',
                    value: 45,
                    valueSuffix: '%',
                    valueDecimals: 0,
                    trend: { direction: 'positive' as const, text: 'Derived from sensitivity' },
                    subtitle: '(High NPV \u2212 Low NPV) / Base',
                  },
                ].map((kpi, index) => (
                  <div key={kpi.label} className="col-span-6 sm:col-span-3 lg:col-span-2 xl:col-span-1">
                    <KpiCard {...kpi} index={index} />
                  </div>
                ))}
              </div>

              {/* NPV vs ROA Comparison Card */}
              <DataCard
                title="NPV vs Real Options Value"
                subtitle="Traditional DCF undervalues the investment by ignoring management flexibility"
              >
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Left: NPV */}
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: 0.1, ease: easeSmooth }}
                    className="bg-bg-tertiary border border-bg-quaternary rounded-lg p-6"
                  >
                    <span className="text-label-lg text-text-tertiary">Net Present Value</span>
                    <div className="text-mono-lg text-text-primary mt-2">
                      <NumberAnimation value={171} prefix="$" suffix="M" decimals={0} />
                    </div>
                    <p className="text-body-sm text-text-secondary mt-2">
                      Traditional DCF valuation — assumes fixed deployment path
                    </p>
                    <div className="mt-4 space-y-2">
                      {['Assumes predetermined scale', 'Ignores management flexibility', 'Static cost/benefit assumptions'].map((item, i) => (
                        <div key={i} className="flex items-start gap-2">
                          <XCircle className="w-4 h-4 text-accent-tertiary flex-shrink-0 mt-0.5" />
                          <span className="text-body-sm text-text-secondary">{item}</span>
                        </div>
                      ))}
                    </div>
                  </motion.div>

                  {/* Right: ROV */}
                  <motion.div
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: 0.2, ease: easeSmooth }}
                    className="bg-accent-primary-muted border border-accent-primary/30 rounded-lg p-6"
                  >
                    <span className="text-label-lg text-accent-primary">Real Options Value</span>
                    <div className="text-mono-lg text-accent-primary mt-2">
                      <NumberAnimation value={189} prefix="$" suffix="M" decimals={0} />
                    </div>
                    <p className="text-body-sm text-text-secondary mt-2">
                      Values management&apos;s ability to adapt the investment path
                    </p>
                    <div className="mt-4 space-y-2">
                      {[
                        'Values expansion option',
                        'Includes downside protection',
                        'Captures timing flexibility',
                      ].map((item, i) => (
                        <div key={i} className="flex items-start gap-2">
                          <TrendingUp className="w-4 h-4 text-accent-secondary flex-shrink-0 mt-0.5" />
                          <span className="text-body-sm text-text-primary">{item}</span>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                </div>

                {/* Flexibility Premium Badge */}
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.6, delay: 0.4, ease: [0.34, 1.56, 0.64, 1] as [number, number, number, number] }}
                  className="flex justify-center my-6"
                >
                  <div className="bg-bg-tertiary border-2 border-accent-primary rounded-full px-8 py-3 flex items-center gap-3">
                    <span className="text-body-md text-text-secondary">Flexibility Premium</span>
                    <span className="text-mono-lg text-accent-primary font-bold">+ $18M</span>
                    <span className="text-body-sm text-text-secondary">(+10.5%)</span>
                  </div>
                </motion.div>

                {/* Bar Chart: NPV vs ROA */}
                <div className="h-[280px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={npvRoaComparisonData} barSize={80}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" vertical={false} />
                      <XAxis
                        dataKey="name"
                        stroke="rgba(148,163,184,0.3)"
                        tick={{ fill: '#94A3B8', fontSize: 13 }}
                        tickLine={false}
                      />
                      <YAxis
                        stroke="rgba(148,163,184,0.3)"
                        tick={{ fill: '#64748B', fontSize: 12 }}
                        tickLine={false}
                        domain={[0, 220]}
                      />
                      <Tooltip content={<CustomTooltip />} />
                      <ReferenceLine y={171} stroke="#60A5FA" strokeDasharray="6 3" strokeOpacity={0.5} />
                      <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                        {npvRoaComparisonData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.fill} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </DataCard>
            </div>
          )}

          {/* ============================================================ */}
          {/* SECTION: MODEL INPUTS  (Component 49)                          */}
          {/* ============================================================ */}
          {activeSection === 'inputs' && (
            <div className="space-y-5">
              <DataCard
                title="Real Options Model Inputs"
                subtitle="Black-Scholes parameters for Copilot deployment option valuation"
              >
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
                  {modelInputs.map((input, index) => {
                    return (
                      <motion.div
                        key={input.symbol}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4, delay: index * 0.08, ease: easeSmooth }}
                        className="bg-bg-tertiary border border-bg-quaternary rounded-lg p-4 hover:border-bg-quaternary/80 transition-all duration-200"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span
                            className="text-mono-lg font-bold"
                            style={{ color: input.color }}
                          >
                            {input.symbol}
                          </span>
                          <span
                            className="text-label-sm px-2 py-0.5 rounded"
                            style={{ backgroundColor: `${input.color}20`, color: input.color }}
                          >
                            {input.param}
                          </span>
                        </div>
                        <div className="text-mono-md text-text-primary mt-2">{input.value}</div>
                        <p className="text-body-sm text-text-secondary mt-1">{input.description}</p>
                      </motion.div>
                    );
                  })}
                </div>

                {/* Volatility note */}
                <div className="flex items-start gap-3 bg-accent-info-muted border border-accent-info/20 rounded-lg px-4 py-3">
                  <Info className="w-5 h-5 text-accent-info flex-shrink-0 mt-0.5" />
                  <p className="text-body-sm text-text-secondary">
                    <span className="text-text-primary font-medium">Volatility note: </span>
                    45% derived from sensitivity range — (High NPV \u2212 Low NPV) / Base NPV. This reflects the uncertainty inherent in enterprise technology adoption and productivity benefit realization.
                  </p>
                </div>
              </DataCard>
            </div>
          )}

          {/* ============================================================ */}
          {/* SECTION: BLACK-SCHOLES CALCULATION  (Component 50)             */}
          {/* ============================================================ */}
          {activeSection === 'calculation' && (
            <div className="space-y-5">
              <DataCard
                title="Black-Scholes Calculation"
                subtitle="Step-by-step real options valuation"
              >
                {/* Formula Display */}
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, ease: easeSmooth }}
                  className="bg-bg-primary border border-bg-quaternary rounded-lg p-6 mb-6 text-center"
                >
                  <p className="text-label-sm text-text-tertiary mb-4">BLACK-SCHOLES FORMULA FOR REAL OPTIONS</p>
                  <div className="font-mono text-mono-lg text-text-primary mb-4">
                    <span className="text-accent-primary">C</span>
                    <span className="text-text-secondary">{' = '}</span>
                    <span className="text-accent-info">S</span>
                    <span className="text-text-secondary">{' \u00D7 '}</span>
                    <span className="text-accent-secondary">N(d</span>
                    <span className="text-accent-secondary">{'\u2081'})</span>
                    <span className="text-text-secondary">{' \u2212 '}</span>
                    <span className="text-accent-tertiary">K</span>
                    <span className="text-text-secondary">{' \u00D7 e'}</span>
                    <span className="text-text-secondary">{'\u207B\u02B3\u1D40'}</span>
                    <span className="text-text-secondary">{' \u00D7 '}</span>
                    <span className="text-accent-secondary">N(d</span>
                    <span className="text-accent-secondary">{'\u2082'})</span>
                  </div>
                  <div className="border-t border-bg-quaternary pt-4 space-y-2 font-mono text-mono-sm text-text-secondary">
                    <p>
                      <span className="text-text-tertiary">{'Where: '}</span>
                      <span className="text-accent-info">{'d\u2081'}</span>
                      <span>{' = [ln('}</span>
                      <span className="text-accent-info">S</span>
                      <span>{'/'}</span>
                      <span className="text-accent-tertiary">K</span>
                      <span>{') + ('}</span>
                      <span className="text-accent-primary">r</span>
                      <span>{' + '}</span>
                      <span className="text-chart-4">{'\u03C3'}</span>
                      <span>{'\u00B2/2) \u00D7 '}</span>
                      <span className="text-chart-6">T</span>
                      <span>{'] / ('}</span>
                      <span className="text-chart-4">{'\u03C3'}</span>
                      <span>{'\u00D7\u221A'}</span>
                      <span className="text-chart-6">T</span>
                      <span>{')'}</span>
                    </p>
                    <p>
                      <span className="text-accent-info">{'d\u2082'}</span>
                      <span>{' = '}</span>
                      <span className="text-accent-info">{'d\u2081'}</span>
                      <span>{' \u2212 '}</span>
                      <span className="text-chart-4">{'\u03C3'}</span>
                      <span>{'\u00D7\u221A'}</span>
                      <span className="text-chart-6">T</span>
                    </p>
                  </div>
                </motion.div>

                {/* Calculation Steps */}
                <div className="space-y-3">
                  {calculationSteps.map((step, index) => (
                    <motion.div
                      key={step.step}
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.4, delay: index * 0.08, ease: easeSmooth }}
                      className="border border-bg-quaternary rounded-lg overflow-hidden"
                    >
                      <button
                        onClick={() => toggleStep(step.step)}
                        className="w-full flex items-center justify-between px-5 py-4 bg-bg-tertiary hover:bg-bg-quaternary/50 transition-colors"
                      >
                        <div className="flex items-center gap-4">
                          <span className="w-8 h-8 rounded-full bg-accent-primary-muted text-accent-primary flex items-center justify-center text-sm font-bold">
                            {step.step}
                          </span>
                          <span className="text-heading-md text-text-primary">{step.title}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-mono-md text-accent-primary">{step.result}</span>
                          <ChevronRight
                            className={`w-5 h-5 text-text-secondary transition-transform duration-200 ${
                              expandedStep === step.step ? 'rotate-90' : ''
                            }`}
                          />
                        </div>
                      </button>
                      <AnimatePresence>
                        {expandedStep === step.step && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.3, ease: easeSmooth }}
                            className="overflow-hidden"
                          >
                            <div className="px-5 py-4 bg-bg-primary border-t border-bg-quaternary">
                              <div className="font-mono text-mono-sm text-text-secondary space-y-1">
                                {step.lines.map((line, i) => (
                                  <p key={i} className={i === step.lines.length - 1 ? 'text-accent-primary font-medium' : ''}>
                                    {line}
                                  </p>
                                ))}
                              </div>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  ))}
                </div>

                {/* Intrinsic value note */}
                <div className="mt-4 flex items-start gap-3 bg-accent-info-muted border border-accent-info/20 rounded-lg px-4 py-3">
                  <Info className="w-5 h-5 text-accent-info flex-shrink-0 mt-0.5" />
                  <p className="text-body-sm text-text-secondary">
                    <span className="text-text-primary font-medium">Note: </span>
                    Due to extremely high moneyness (S {'>>'} K), the option value approximates intrinsic value. The strategic flexibility premium comes from the portfolio of options, not this single call.
                  </p>
                </div>
              </DataCard>
            </div>
          )}

          {/* ============================================================ */}
          {/* SECTION: EXPANSION OPTION  (Components 53-55)                  */}
          {/* ============================================================ */}
          {activeSection === 'expansion' && (
            <div className="space-y-5">
              {/* Expansion KPIs */}
              <div className="grid grid-cols-6 gap-4">
                {[
                  {
                    icon: Maximize2,
                    label: 'EXPAND TO 10,000',
                    value: 110.6,
                    valuePrefix: '$',
                    valueSuffix: 'M',
                    valueDecimals: 1,
                    trend: { direction: 'positive' as const, text: 'Highest value option' },
                    subtitle: '+4,000 incremental users',
                  },
                  {
                    icon: TrendingUp,
                    label: 'EXPAND TO 7,000',
                    value: 27.7,
                    valuePrefix: '$',
                    valueSuffix: 'M',
                    valueDecimals: 1,
                    trend: { direction: 'positive' as const, text: 'Probable first step' },
                    subtitle: '+1,000 incremental users',
                  },
                  {
                    icon: BarChart3,
                    label: 'COMBINED EXPANSION',
                    value: 138.3,
                    valuePrefix: '$',
                    valueSuffix: 'M',
                    valueDecimals: 1,
                    trend: { direction: 'positive' as const, text: '73% of portfolio value' },
                    subtitle: 'Total expansion options',
                  },
                  {
                    icon: Calculator,
                    label: 'INCREMENTAL BENEFIT',
                    value: 46,
                    valuePrefix: '$',
                    valueSuffix: 'M',
                    valueDecimals: 0,
                    trend: { direction: 'positive' as const, text: '10K scenario annual' },
                    subtitle: 'Per-year productivity gain',
                  },
                  {
                    icon: Shield,
                    label: 'EXERCISE PROBABILITY',
                    value: 65,
                    valueSuffix: '%',
                    valueDecimals: 0,
                    trend: { direction: 'positive' as const, text: '10K scenario' },
                    subtitle: 'Likely if adoption > 80%',
                  },
                  {
                    icon: Timer,
                    label: 'OPTION EXPIRY',
                    value: 3,
                    valueSuffix: ' years',
                    valueDecimals: 0,
                    trend: { direction: 'positive' as const, text: 'Maximum time value' },
                    subtitle: 'Decision window',
                  },
                ].map((kpi, index) => (
                  <div key={kpi.label} className="col-span-6 sm:col-span-3 lg:col-span-2 xl:col-span-1">
                    <KpiCard {...kpi} index={index} />
                  </div>
                ))}
              </div>

              {/* Scenario Comparison Cards */}
              <DataCard
                title="Expansion Option \u2014 6,000 to 10,000 Users"
                subtitle="Scenario comparison with Black-Scholes calculation"
              >
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mb-6">
                  {expansionScenarios.map((scenario, index) => (
                    <motion.div
                      key={scenario.users}
                      initial={{ opacity: 0, x: index === 0 ? -20 : 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.5, delay: 0.1 + index * 0.1, ease: easeSmooth }}
                      className={`border rounded-lg p-5 ${
                        scenario.users === 10000
                          ? 'bg-accent-secondary-muted border-accent-secondary/30'
                          : 'bg-bg-tertiary border-bg-quaternary'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-heading-md text-text-primary">
                          {scenario.users.toLocaleString()}-User Expansion
                        </span>
                        <span className="text-label-sm bg-accent-primary-muted text-accent-primary px-2 py-1 rounded">
                          {scenario.expansion}
                        </span>
                      </div>
                      <div className="space-y-2 text-body-sm text-text-secondary">
                        <div className="flex justify-between">
                          <span>Incremental cost:</span>
                          <span className="text-mono-sm text-text-primary">{scenario.incrementalCost}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Incremental benefit:</span>
                          <span className="text-mono-sm text-accent-secondary">{scenario.incrementalBenefit}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>NPV of expansion:</span>
                          <span className="text-mono-sm text-accent-primary">{scenario.npvExpansion}</span>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                {/* Calculation Table */}
                <div className="overflow-x-auto mb-6">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-bg-tertiary">
                        <th className="text-label-sm text-text-tertiary text-left px-4 py-3">Parameter</th>
                        <th className="text-label-sm text-text-tertiary text-right px-4 py-3">Symbol</th>
                        <th className="text-label-sm text-text-tertiary text-right px-4 py-3">7,000-User</th>
                        <th className="text-label-sm text-text-tertiary text-right px-4 py-3">10,000-User</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        ['Underlying', 'S', '$28M', '$112M'],
                        ['Exercise Cost', 'K', '$360K', '$1.44M'],
                        ['Volatility', '\u03C3', '35%', '40%'],
                        ['Time Horizon', 'T', '2 years', '3 years'],
                        ['Risk-Free Rate', 'r', '4.5%', '4.5%'],
                      ].map((row, i) => (
                        <tr key={i} className={`border-b border-bg-quaternary ${i % 2 === 0 ? 'bg-bg-primary/50' : 'bg-bg-secondary'}`}>
                          <td className="text-body-md text-text-primary px-4 py-3">{row[0]}</td>
                          <td className="text-mono-sm text-accent-info text-right px-4 py-3">{row[1]}</td>
                          <td className="text-mono-sm text-text-secondary text-right px-4 py-3">{row[2]}</td>
                          <td className="text-mono-sm text-text-secondary text-right px-4 py-3">{row[3]}</td>
                        </tr>
                      ))}
                      {/* d1, d2 rows */}
                      <tr className="border-b border-bg-quaternary bg-bg-primary/50">
                        <td className="text-body-md text-text-primary px-4 py-3">d\u2081</td>
                        <td className="text-mono-sm text-accent-info text-right px-4 py-3">d\u2081</td>
                        <td className="text-mono-sm text-accent-primary text-right px-4 py-3 font-medium">8.42</td>
                        <td className="text-mono-sm text-accent-primary text-right px-4 py-3 font-medium">6.18</td>
                      </tr>
                      <tr className="border-b border-bg-quaternary bg-bg-secondary">
                        <td className="text-body-md text-text-primary px-4 py-3">d\u2082</td>
                        <td className="text-mono-sm text-accent-info text-right px-4 py-3">d\u2082</td>
                        <td className="text-mono-sm text-accent-primary text-right px-4 py-3 font-medium">7.93</td>
                        <td className="text-mono-sm text-accent-primary text-right px-4 py-3 font-medium">5.49</td>
                      </tr>
                      {/* N(d) rows */}
                      <tr className="border-b border-bg-quaternary bg-bg-primary/50">
                        <td className="text-body-md text-text-primary px-4 py-3">N(d\u2081)</td>
                        <td className="text-mono-sm text-accent-info text-right px-4 py-3">N(d\u2081)</td>
                        <td className="text-mono-sm text-accent-secondary text-right px-4 py-3 font-medium">1.0</td>
                        <td className="text-mono-sm text-accent-secondary text-right px-4 py-3 font-medium">1.0</td>
                      </tr>
                      <tr className="border-b border-bg-quaternary bg-bg-secondary">
                        <td className="text-body-md text-text-primary px-4 py-3">N(d\u2082)</td>
                        <td className="text-mono-sm text-accent-info text-right px-4 py-3">N(d\u2082)</td>
                        <td className="text-mono-sm text-accent-secondary text-right px-4 py-3 font-medium">1.0</td>
                        <td className="text-mono-sm text-accent-secondary text-right px-4 py-3 font-medium">1.0</td>
                      </tr>
                      {/* Option value row */}
                      <tr className="bg-accent-primary-muted">
                        <td className="text-body-md text-text-primary font-bold px-4 py-3">Option Value</td>
                        <td className="text-mono-sm text-accent-info text-right px-4 py-3 font-bold">C</td>
                        <td className="text-mono-sm text-accent-primary text-right px-4 py-3 font-bold">$27.7M</td>
                        <td className="text-mono-sm text-accent-primary text-right px-4 py-3 font-bold">$110.6M</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* Expansion Bar Chart */}
                <div className="h-[280px]">
                  <p className="text-label-sm text-text-tertiary mb-3 text-center">Total Portfolio Value by Deployment Scale</p>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={expansionChartData} barSize={70}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" vertical={false} />
                      <XAxis
                        dataKey="name"
                        stroke="rgba(148,163,184,0.3)"
                        tick={{ fill: '#94A3B8', fontSize: 12 }}
                        tickLine={false}
                      />
                      <YAxis
                        stroke="rgba(148,163,184,0.3)"
                        tick={{ fill: '#64748B', fontSize: 12 }}
                        tickLine={false}
                        domain={[0, 320]}
                      />
                      <Tooltip content={<CustomTooltip />} />
                      <ReferenceLine y={171} stroke="#60A5FA" strokeDasharray="6 3" strokeOpacity={0.5} label={{ value: 'NPV Base', fill: '#60A5FA', fontSize: 11 }} />
                      <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                        {expansionChartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.fill} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </DataCard>
            </div>
          )}

          {/* ============================================================ */}
          {/* SECTION: CONTRACTION OPTION  (Component 56)                    */}
          {/* ============================================================ */}
          {activeSection === 'contraction' && (
            <div className="space-y-5">
              <DataCard
                title="Contraction Option \u2014 Downside Protection"
                subtitle="The option to contract provides protection against adoption underperformance"
              >
                {/* Key insight callout */}
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, ease: easeSmooth }}
                  className="flex items-start gap-3 bg-accent-secondary-muted border border-accent-secondary/20 rounded-lg px-4 py-3 mb-6"
                >
                  <Shield className="w-5 h-5 text-accent-secondary flex-shrink-0 mt-0.5" />
                  <p className="text-body-sm text-text-primary">
                    The ability to contract preserves <span className="text-mono-sm text-accent-secondary font-bold">$12M</span> in option value — protecting against downside while maintaining upside exposure.
                  </p>
                </motion.div>

                {/* Contraction Scenarios Table */}
                <div className="overflow-x-auto mb-6">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-bg-tertiary">
                        <th className="text-label-sm text-text-tertiary text-left px-4 py-3">Scenario</th>
                        <th className="text-label-sm text-text-tertiary text-left px-4 py-3">Scale</th>
                        <th className="text-label-sm text-text-tertiary text-right px-4 py-3">Cost Avoided</th>
                        <th className="text-label-sm text-text-tertiary text-left px-4 py-3">Value Retained</th>
                        <th className="text-label-sm text-text-tertiary text-right px-4 py-3">Net Impact</th>
                      </tr>
                    </thead>
                    <tbody>
                      {contractionScenarios.map((row, i) => (
                        <tr
                          key={row.scenario}
                          className={`border-b border-bg-quaternary hover:bg-bg-tertiary/50 transition-colors ${
                            i % 2 === 0 ? 'bg-bg-primary/50' : 'bg-bg-secondary'
                          }`}
                        >
                          <td className="text-body-md text-text-primary px-4 py-3">{row.scenario}</td>
                          <td className="text-mono-sm text-text-secondary px-4 py-3">{row.scale}</td>
                          <td className="text-mono-sm text-accent-secondary text-right px-4 py-3">{row.costAvoided}</td>
                          <td className="text-body-sm text-text-secondary px-4 py-3">{row.valueRetained}</td>
                          <td className="text-mono-sm text-accent-tertiary text-right px-4 py-3 font-medium">
                            ${row.netImpact}M
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Interpretation */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                  <motion.div
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: 0.1, ease: easeSmooth }}
                    className="bg-bg-tertiary border border-bg-quaternary rounded-lg p-5"
                  >
                    <div className="flex items-center gap-2 mb-3">
                      <FileText className="w-5 h-5 text-accent-primary" />
                      <span className="text-heading-md text-text-primary">Executive Interpretation</span>
                    </div>
                    <p className="text-body-sm text-text-secondary">
                      Contraction scenarios show negative net impact, which is{' '}
                      <span className="text-accent-secondary font-medium">good news</span>. It means the
                      downside from scaling back is minimal — the primary value driver is the{' '}
                      <span className="text-accent-primary font-medium">upside expansion option</span>. The
                      $12M contraction option value acts as insurance, not a value creation mechanism.
                    </p>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: 0.2, ease: easeSmooth }}
                    className="bg-bg-tertiary border border-bg-quaternary rounded-lg p-5"
                  >
                    <div className="flex items-center gap-2 mb-3">
                      <Scale className="w-5 h-5 text-accent-info" />
                      <span className="text-heading-md text-text-primary">Regulator Interpretation</span>
                    </div>
                    <p className="text-body-sm text-text-secondary">
                      From a ratepayer perspective, the contraction option ensures that if Copilot fails
                      to deliver expected benefits, the utility can scale back without stranded costs.
                      The $12M protection limits ratepayer exposure while preserving the $189M upside
                      potential.
                    </p>
                  </motion.div>
                </div>

                {/* Visual: contraction impact bars */}
                <div className="mt-6">
                  <p className="text-label-sm text-text-tertiary mb-3">Net Impact of Contraction Scenarios</p>
                  <div className="space-y-3">
                    {contractionScenarios.map((scenario, i) => (
                      <motion.div
                        key={scenario.scenario}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.4, delay: i * 0.1, ease: easeSmooth }}
                        className="flex items-center gap-4"
                      >
                        <span className="text-body-sm text-text-secondary w-36 flex-shrink-0 text-right">
                          {scenario.scenario}
                        </span>
                        <div className="flex-1 h-8 bg-bg-tertiary rounded-full overflow-hidden relative">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${Math.abs(scenario.netImpact) / 100 * 100}%` }}
                            transition={{ duration: 0.8, delay: 0.3 + i * 0.1, ease: easeSmooth }}
                            className="h-full bg-accent-tertiary/60 rounded-full flex items-center justify-end pr-3"
                          >
                            <span className="text-mono-sm text-accent-tertiary font-medium">
                              ${scenario.netImpact}M
                            </span>
                          </motion.div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </DataCard>
            </div>
          )}

          {/* ============================================================ */}
          {/* SECTION: FULL PORTFOLIO  (Components 57-63)                    */}
          {/* ============================================================ */}
          {activeSection === 'portfolio' && (
            <div className="space-y-5">
              {/* Strategic Option Portfolio Cards */}
              <DataCard
                title="Strategic Option Portfolio"
                subtitle="Five real options embedded in the Copilot investment"
              >
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
                  {portfolioOptions.map((option, index) => {
                    const Icon = option.icon;
                    return (
                      <motion.div
                        key={option.title}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4, delay: index * 0.1, ease: easeSmooth }}
                        className="border rounded-lg p-4 bg-bg-tertiary hover:translate-y-[-4px] transition-all duration-300 group"
                        style={{ borderTopWidth: '3px', borderTopColor: option.typeColor }}
                      >
                        <div className="flex items-center gap-2 mb-3">
                          <Icon className="w-5 h-5" style={{ color: option.typeColor }} />
                          <span className="text-label-sm px-2 py-0.5 rounded" style={{ backgroundColor: `${option.typeColor}20`, color: option.typeColor }}>
                            {option.type}
                          </span>
                        </div>
                        <h4 className="text-heading-md text-text-primary mb-1">{option.title}</h4>
                        <p className="text-body-sm text-text-secondary mb-3">{option.description}</p>
                        <div className="text-mono-lg font-bold" style={{ color: option.typeColor }}>
                          {option.value}
                        </div>
                        <div className="mt-3 pt-3 border-t border-bg-quaternary space-y-1 opacity-70 group-hover:opacity-100 transition-opacity">
                          <p className="text-body-sm text-text-secondary">
                            <span className="text-text-tertiary">Trigger: </span>
                            {option.trigger}
                          </p>
                          <p className="text-body-sm text-text-secondary">
                            <span className="text-text-tertiary">Expiry: </span>
                            {option.expiry}
                          </p>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </DataCard>

              {/* Full Portfolio Summary Table */}
              <DataCard
                title="Complete Real Options Portfolio Summary"
                subtitle="Board-ready comparison of all strategic options"
              >
                <div className="overflow-x-auto mb-6">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-bg-tertiary">
                        <th className="text-label-sm text-text-tertiary text-left px-4 py-3">Option</th>
                        <th className="text-label-sm text-text-tertiary text-left px-4 py-3">Type</th>
                        <th className="text-label-sm text-text-tertiary text-right px-4 py-3">Value ($M)</th>
                        <th className="text-label-sm text-text-tertiary text-right px-4 py-3">Prob. of Exercise</th>
                        <th className="text-label-sm text-text-tertiary text-left px-4 py-3">Strategic Value</th>
                      </tr>
                    </thead>
                    <tbody>
                      {portfolioSummary.map((row, i) => (
                        <tr
                          key={row.option}
                          className={`border-b border-bg-quaternary hover:bg-bg-tertiary/50 transition-colors ${
                            i % 2 === 0 ? 'bg-bg-primary/50' : 'bg-bg-secondary'
                          }`}
                        >
                          <td className="text-body-md text-text-primary px-4 py-3">{row.option}</td>
                          <td className="px-4 py-3">
                            <span
                              className="text-label-sm px-2 py-1 rounded"
                              style={{ backgroundColor: `${row.typeColor}20`, color: row.typeColor }}
                            >
                              {row.type}
                            </span>
                          </td>
                          <td className="text-mono-sm text-text-primary text-right px-4 py-3">
                            <NumberAnimation value={row.value} prefix="$" suffix="M" decimals={row.value < 10 ? 2 : 1} />
                          </td>
                          <td className="text-mono-sm text-text-secondary text-right px-4 py-3">{row.probability}</td>
                          <td className="text-body-sm text-text-secondary px-4 py-3">{row.strategicValue}</td>
                        </tr>
                      ))}
                      {/* Portfolio Total Row */}
                      <tr className="bg-accent-primary-muted border-t-2 border-accent-primary">
                        <td className="text-body-md text-text-primary font-bold px-4 py-3">Portfolio Total</td>
                        <td className="px-4 py-3" />
                        <td className="text-mono-lg text-accent-primary text-right px-4 py-3 font-bold">
                          <NumberAnimation value={189} prefix="$" suffix="M" decimals={0} />
                        </td>
                        <td className="px-4 py-3" />
                        <td className="px-4 py-3" />
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* Horizontal Bar Chart: Portfolio */}
                <div className="h-[320px]">
                  <p className="text-label-sm text-text-tertiary mb-3 text-center">Option Value Distribution ($M)</p>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={portfolioBarData}
                      layout="vertical"
                      barSize={28}
                      margin={{ left: 20, right: 30 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" horizontal={false} />
                      <XAxis
                        type="number"
                        stroke="rgba(148,163,184,0.3)"
                        tick={{ fill: '#64748B', fontSize: 12 }}
                        tickLine={false}
                        domain={[0, 120]}
                      />
                      <YAxis
                        dataKey="name"
                        type="category"
                        stroke="rgba(148,163,184,0.3)"
                        tick={{ fill: '#94A3B8', fontSize: 12 }}
                        tickLine={false}
                        width={90}
                      />
                      <Tooltip content={<CustomTooltip />} />
                      <Bar dataKey="value" radius={[0, 6, 6, 0]}>
                        {portfolioBarData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.fill} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </DataCard>

              {/* Interpretations */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                {/* Board Interpretation */}
                <motion.div
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: 0.1, ease: easeSmooth }}
                  className="bg-bg-secondary border border-bg-quaternary rounded-card p-6"
                >
                  <div className="flex items-center gap-2 mb-3">
                    <FileText className="w-5 h-5 text-accent-primary" />
                    <span className="text-heading-lg text-text-primary">Board Interpretation</span>
                  </div>
                  <p className="text-body-md text-text-secondary leading-relaxed">
                    The Real Options Analysis values the Copilot investment at{' '}
                    <span className="text-accent-primary font-bold">$189M</span> —{' '}
                    <span className="text-accent-primary font-bold">$18M above traditional NPV</span>.
                    This $18M premium represents the value of management&apos;s flexibility to expand,
                    contract, or adapt the deployment based on observed results.
                  </p>
                  <div className="mt-4 space-y-2">
                    {[
                      { label: 'Only expansion has positive value creation', color: 'text-accent-secondary' },
                      { label: 'Downside protection is embedded at $12M', color: 'text-accent-primary' },
                      { label: 'Abandonment option is insurance, not strategy', color: 'text-text-secondary' },
                    ].map((item, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <ChevronRight className="w-4 h-4 text-accent-primary flex-shrink-0" />
                        <span className={`text-body-sm ${item.color} font-medium`}>{item.label}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>

                {/* Regulator Interpretation */}
                <motion.div
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: 0.2, ease: easeSmooth }}
                  className="bg-bg-secondary border border-bg-quaternary rounded-card p-6"
                >
                  <div className="flex items-center gap-2 mb-3">
                    <Scale className="w-5 h-5 text-accent-info" />
                    <span className="text-heading-lg text-text-primary">Regulator Interpretation</span>
                  </div>
                  <p className="text-body-md text-text-secondary leading-relaxed">
                    From a ratepayer perspective, the option to contract provides{' '}
                    <span className="text-accent-primary font-bold">$12M in downside protection</span> —
                    ensuring that if Copilot fails to deliver expected benefits, the utility can scale
                    back without stranded costs.
                  </p>
                  <div className="mt-4 space-y-2">
                    {[
                      { label: 'Minimal downside risk (contraction is value-destroying)', color: 'text-accent-secondary' },
                      { label: 'Massive upside potential ($110M expansion to 10K)', color: 'text-accent-secondary' },
                      { label: 'Ratepayer exposure is capped and well-defined', color: 'text-accent-primary' },
                    ].map((item, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <ChevronRight className="w-4 h-4 text-accent-info flex-shrink-0" />
                        <span className={`text-body-sm ${item.color} font-medium`}>{item.label}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              </div>

              {/* Risk Assessment */}
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: 0.3, ease: easeSmooth }}
                className="bg-bg-secondary border border-bg-quaternary rounded-card p-6"
              >
                <div className="flex items-center gap-2 mb-4">
                  <AlertTriangle className="w-5 h-5 text-accent-primary" />
                  <span className="text-heading-lg text-text-primary">Portfolio Risk Assessment</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="bg-bg-tertiary border border-bg-quaternary rounded-lg p-4 text-center">
                    <span className="text-label-sm text-text-tertiary">UPSIDE SCENARIOS</span>
                    <div className="text-mono-lg text-accent-secondary mt-1">$138M</div>
                    <span className="text-body-sm text-text-secondary">Expansion options (73%)</span>
                  </div>
                  <div className="bg-bg-tertiary border border-bg-quaternary rounded-lg p-4 text-center">
                    <span className="text-label-sm text-text-tertiary">PROTECTION VALUE</span>
                    <div className="text-mono-lg text-accent-primary mt-1">$38M</div>
                    <span className="text-body-sm text-text-secondary">Contract + abandon (20%)</span>
                  </div>
                  <div className="bg-bg-tertiary border border-bg-quaternary rounded-lg p-4 text-center">
                    <span className="text-label-sm text-text-tertiary">FLEXIBILITY VALUE</span>
                    <div className="text-mono-lg text-accent-info mt-1">$13M</div>
                    <span className="text-body-sm text-text-secondary">Defer + stage (7%)</span>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
