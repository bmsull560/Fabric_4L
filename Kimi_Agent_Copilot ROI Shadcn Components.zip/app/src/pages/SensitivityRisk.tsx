import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  Shield,
  ShieldCheck,
  AlertOctagon,
  TrendingDown,
  TrendingUp,
  Minus,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  Cell,
  ComposedChart,
} from 'recharts';
import { cn } from '@/lib/utils';
import DataCard from '@/components/DataCard';
import NumberAnimation from '@/components/NumberAnimation';

/* ─── easing ─── */
const EASE_SMOOTH = [0.22, 1, 0.36, 1] as [number, number, number, number];
const cardIn = {
  hidden: { opacity: 0, y: 25 },
  show: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.1, duration: 0.5, ease: EASE_SMOOTH },
  }),
};

/* ─── Severity badge helper ─── */
function SeverityBadge({ level }: { level: string }) {
  const colors: Record<string, string> = {
    High: 'bg-accent-tertiary-muted text-accent-tertiary',
    Medium: 'bg-accent-primary-muted text-accent-primary',
    Low: 'bg-accent-secondary-muted text-accent-secondary',
  };
  return (
    <span className={cn('text-label-sm px-2.5 py-1 rounded-md', colors[level] || colors.Low)}>
      {level.toUpperCase()}
    </span>
  );
}

/* ─── Condition badge helper ─── */
function ConditionBadge({ severity }: { severity: string }) {
  const config: Record<string, { bg: string; text: string }> = {
    EXTREME: { bg: 'bg-accent-tertiary-muted', text: 'text-accent-tertiary' },
    'COMBINED STRESS': { bg: 'bg-accent-tertiary-muted', text: 'text-accent-tertiary' },
    MODERATE: { bg: 'bg-accent-primary-muted', text: 'text-accent-primary' },
    PASSES: { bg: 'bg-accent-secondary-muted', text: 'text-accent-secondary' },
  };
  const c = config[severity] || config.MODERATE;
  return (
    <span className={cn('text-label-sm px-2.5 py-1 rounded-md', c.bg, c.text)}>{severity}</span>
  );
}

/* ─── Risk data ─── */
interface Risk {
  category: string;
  likelihood: string;
  impact: string;
  score: number;
  level: string;
  mitigations: string[];
}

const risks: Risk[] = [
  {
    category: 'Adoption Variability',
    likelihood: 'Medium',
    impact: 'High',
    score: 6,
    level: 'Medium',
    mitigations: [
      'Phased rollout with adoption gates',
      'Executive sponsorship program',
      'Champion network (2% of workforce)',
      'Monthly adoption tracking with intervention triggers',
    ],
  },
  {
    category: 'Data Governance',
    likelihood: 'Low',
    impact: 'Medium',
    score: 3,
    level: 'Low',
    mitigations: [
      'Microsoft 365 compliance center configuration',
      'Sensitivity label enforcement',
      'Quarterly data access audit',
      'Dedicated Copilot governance committee',
    ],
  },
  {
    category: 'Workforce Resistance',
    likelihood: 'Medium',
    impact: 'Medium',
    score: 4,
    level: 'Medium',
    mitigations: [
      'Change management program ($120K/year)',
      'Training certification incentives',
      'Productivity showcase sessions',
      'Manager enablement toolkit',
    ],
  },
  {
    category: 'Over-Reliance on AI',
    likelihood: 'Low',
    impact: 'High',
    score: 4,
    level: 'Medium',
    mitigations: [
      'Human-in-the-loop validation requirements',
      'Critical decision override protocols',
      'Quarterly AI dependency assessment',
      'Fallback workflow documentation',
    ],
  },
  {
    category: 'Regulatory Scrutiny',
    likelihood: 'Low',
    impact: 'High',
    score: 4,
    level: 'Medium',
    mitigations: [
      'Ratepayer benefit documentation',
      'PUC pre-filing consultation',
      'Independent ROI verification',
      'Transparent cost tracking',
    ],
  },
];

/* ─── Sensitivity ROI Cases ─── */
const sensitivityCases = [
  {
    label: 'Low Case',
    badgeColor: 'bg-accent-tertiary-muted text-accent-tertiary border-accent-tertiary/30',
    roi: 2500,
    annualBenefit: 66.6,
    annualCost: 2.88,
    net: 63.7,
    payback: 7,
    assumptions: [
      '50% productivity realization',
      '65% adoption rate',
      'Conservative operational gains',
      '$35/user license cost',
    ],
  },
  {
    label: 'Base Case',
    badgeColor: 'bg-accent-primary-muted text-accent-primary border-accent-primary/40',
    roi: 2742,
    annualBenefit: 81.8,
    annualCost: 2.88,
    net: 78.9,
    payback: 5.2,
    assumptions: [
      '85% productivity realization',
      '85% adoption rate',
      'Expected operational gains',
      '$30/user license cost',
    ],
  },
  {
    label: 'High Case',
    badgeColor: 'bg-accent-secondary-muted text-accent-secondary border-accent-secondary/30',
    roi: 3050,
    annualBenefit: 97.0,
    annualCost: 2.88,
    net: 94.1,
    payback: 4.0,
    assumptions: [
      '100% productivity realization',
      '100% adoption rate',
      'Optimistic operational gains',
      '$25/user license cost',
    ],
  },
];

/* ─── CFO Stress Tests ─── */
const stressTests = [
  {
    scenario: '10% Productivity Realization',
    description: 'Only 10% of projected productivity gains materialize',
    conditionSeverity: 'EXTREME',
    resultRoi: 274,
    netBenefit: 5.9,
    verdict: 'Still strongly positive — payback under 6 months',
    verdictBadge: 'PASSES',
    verdictColor: 'text-accent-secondary',
  },
  {
    scenario: '$40 License Cost',
    description: 'License cost rises to $40/user/month',
    conditionSeverity: 'MODERATE',
    resultRoi: 2412,
    netBenefit: 69.2,
    verdict: 'Minimal impact — cost is small fraction of benefit',
    verdictBadge: 'PASSES',
    verdictColor: 'text-accent-secondary',
  },
  {
    scenario: '50% Productivity Drop + License Increase',
    description: 'Worst case: 50% productivity cut AND $40/user license',
    conditionSeverity: 'COMBINED STRESS',
    resultRoi: 1206,
    netBenefit: 34.6,
    verdict: 'ROI still exceeds 1,000% — extremely robust model',
    verdictBadge: 'PASSES',
    verdictColor: 'text-accent-secondary',
  },
];

/* ─── NPV Tornado data ─── */
const npvTornadoData = [
  {
    driver: 'Productivity Impact',
    low: 85,
    base: 171,
    high: 257,
    swing: 172,
  },
  {
    driver: 'Adoption Speed',
    low: 102,
    base: 171,
    high: 198,
    swing: 96,
  },
  {
    driver: 'Steady-State Coverage',
    low: 98,
    base: 171,
    high: 205,
    swing: 107,
  },
  {
    driver: 'Discount Rate',
    low: 189,
    base: 171,
    high: 156,
    swing: 33,
  },
  {
    driver: 'Cost Inflation',
    low: 178,
    base: 171,
    high: 164,
    swing: 14,
  },
];

const sortedNpvTornado = [...npvTornadoData].sort((a, b) => b.swing - a.swing);

/* ─── Financial model summary data ─── */
const financialSummary = [
  { metric: 'Total Annual Benefit', low: 66.6, base: 81.8, high: 97.0, unit: '$M' },
  { metric: 'Total Annual Cost', low: 2.88, base: 2.88, high: 2.88, unit: '$M' },
  { metric: 'Net Annual Benefit', low: 63.7, base: 78.9, high: 94.1, unit: '$M' },
  { metric: 'ROI', low: 2500, base: 2742, high: 3050, unit: '%' },
  { metric: 'Payback (months)', low: 7, base: 5.2, high: 4, unit: 'mo' },
  { metric: '3-Year NPV @ 8%', low: 142, base: 171, high: 203, unit: '$M' },
];

/* ─── Custom tooltip for NPV tornado ─── */
function NpvTornadoTooltip({ active, payload }: { active?: boolean; payload?: Array<{ payload: { driver: string; low: number; high: number } }> }) {
  if (!active || !payload?.length) return null;
  const data = payload[0].payload;
  return (
    <div className="bg-bg-secondary border border-bg-quaternary rounded-lg px-3 py-2 shadow-xl">
      <p className="text-body-sm text-text-primary font-medium">{data.driver}</p>
      <p className="text-body-sm text-accent-tertiary">Low: ${data.low}M</p>
      <p className="text-body-sm text-accent-secondary">High: ${data.high}M</p>
      <p className="text-body-sm text-text-tertiary">Swing: ${data.high - data.low}M</p>
    </div>
  );
}

/* ─── Risk tooltip for heatmap ─── */
function RiskHeatmapDot({ risk, index }: { risk: Risk; index: number }) {
  const likelihoodMap: Record<string, number> = { Low: 1, Medium: 2.5, High: 4 };
  const impactMap: Record<string, number> = { Low: 1, Medium: 2.5, High: 4 };
  const x = likelihoodMap[risk.likelihood] || 2;
  const y = impactMap[risk.impact] || 2;
  const color =
    risk.level === 'High'
      ? '#F87171'
      : risk.level === 'Medium'
      ? '#D4A853'
      : '#4ADE80';

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 0.4 + index * 0.1, duration: 0.4, ease: EASE_SMOOTH }}
      className="absolute flex flex-col items-center"
      style={{
        left: `${(x / 5) * 100}%`,
        bottom: `${(y / 5) * 100}%`,
        transform: 'translate(-50%, 50%)',
      }}
    >
      <div
        className="rounded-full flex items-center justify-center border-2 border-bg-secondary"
        style={{
          backgroundColor: color,
          width: Math.max(24, risk.score * 6),
          height: Math.max(24, risk.score * 6),
        }}
      >
        <span className="text-[10px] font-bold text-text-inverse">{risk.score}</span>
      </div>
      <span className="text-[10px] text-text-tertiary mt-1 whitespace-nowrap bg-bg-secondary/80 px-1 rounded">
        {risk.category}
      </span>
    </motion.div>
  );
}

/* ─── Main Component ─── */
export default function SensitivityRisk() {
  const [openMitigation, setOpenMitigation] = useState<number | null>(null);

  return (
    <div className="px-8 py-6 space-y-6">
      {/* ── Header ── */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: EASE_SMOOTH }}
      >
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-lg bg-accent-primary-muted flex items-center justify-center">
            <ShieldAlert className="w-5 h-5 text-accent-primary" />
          </div>
          <div>
            <h1 className="text-display-md text-text-primary">Sensitivity &amp; Risk Analysis</h1>
            <p className="text-body-sm text-text-tertiary">
              Stress testing, risk assessment, and model robustness analysis
            </p>
          </div>
        </div>
      </motion.div>

      {/* ── Section: Sensitivity ROI Cases ── */}
      <DataCard
        title="Sensitivity ROI Cases"
        subtitle="Low, Base, and High scenarios for board consideration"
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mt-4">
          {sensitivityCases.map((c, i) => (
            <motion.div
              key={c.label}
              variants={cardIn}
              initial="hidden"
              animate="show"
              custom={i}
              className={cn(
                'bg-bg-primary border rounded-card p-5 hover:shadow-[0_4px_24px_rgba(212,168,83,0.08)] transition-all duration-300',
                c.label === 'Base Case'
                  ? 'border-accent-primary/40'
                  : 'border-bg-quaternary hover:border-accent-primary/30'
              )}
            >
              <div className="mb-4">
                <span className={cn('text-label-sm px-2.5 py-1 rounded-md border', c.badgeColor)}>
                  {c.label.toUpperCase()}
                </span>
              </div>
              <div className="mb-4">
                <span className="text-label-sm text-text-tertiary">ROI</span>
                <p
                  className={cn(
                    'text-mono-lg',
                    c.label === 'Base Case' ? 'text-accent-primary' : 'text-text-primary'
                  )}
                >
                  <NumberAnimation value={c.roi} suffix="%" />
                </p>
              </div>
              <div className="space-y-2 mb-4">
                <div className="flex justify-between">
                  <span className="text-body-sm text-text-secondary">Annual Benefit</span>
                  <span className="text-body-sm text-text-primary font-mono">${c.annualBenefit}M</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-body-sm text-text-secondary">Annual Cost</span>
                  <span className="text-body-sm text-text-primary font-mono">${c.annualCost}M</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-body-sm text-text-secondary">Net</span>
                  <span className="text-body-sm text-accent-secondary font-mono">${c.net}M</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-body-sm text-text-secondary">Payback</span>
                  <span className="text-body-sm text-text-primary font-mono">{c.payback} months</span>
                </div>
              </div>
              <div className="border-t border-bg-quaternary pt-3">
                <span className="text-label-sm text-text-tertiary mb-2 block">Assumptions</span>
                <ul className="space-y-1">
                  {c.assumptions.map((a) => (
                    <li key={a} className="text-body-sm text-text-secondary flex items-start gap-2">
                      <Minus className="w-3 h-3 text-text-tertiary mt-1 flex-shrink-0" />
                      {a}
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Waterfall comparison chart */}
        <div className="mt-8 h-[300px]">
          <h4 className="text-label-lg text-text-tertiary mb-2">Case Comparison — Annual Benefit ($M)</h4>
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart
              data={[
                { case: 'Low', benefit: 66.6, cost: 2.88, net: 63.7 },
                { case: 'Base', benefit: 81.8, cost: 2.88, net: 78.9 },
                { case: 'High', benefit: 97.0, cost: 2.88, net: 94.1 },
              ]}
              margin={{ top: 20, right: 20, left: 10, bottom: 10 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" />
              <XAxis
                dataKey="case"
                tick={{ fill: '#94A3B8', fontSize: 12 }}
                axisLine={{ stroke: 'rgba(148,163,184,0.3)' }}
              />
              <YAxis
                tick={{ fill: '#94A3B8', fontSize: 12 }}
                axisLine={{ stroke: 'rgba(148,163,184,0.3)' }}
                tickFormatter={(v: number) => `$${v}M`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#111827',
                  border: '1px solid #232D42',
                  borderRadius: '8px',
                }}
                formatter={(value: number, name: string) => [
                  `$${value}M`,
                  name === 'benefit' ? 'Benefit' : name === 'cost' ? 'Cost' : 'Net',
                ]}
              />
              <Bar dataKey="benefit" fill="#D4A853" radius={[4, 4, 0, 0]} opacity={0.85} name="benefit" />
              <Bar dataKey="cost" fill="#F87171" radius={[4, 4, 0, 0]} opacity={0.7} name="cost" />
              <Bar dataKey="net" fill="#4ADE80" radius={[4, 4, 0, 0]} opacity={0.6} name="net" />
              <ReferenceLine
                y={2.88}
                stroke="#F87171"
                strokeDasharray="4 4"
                strokeWidth={1.5}
                label={{ value: 'Cost', position: 'right', fill: '#F87171', fontSize: 11 }}
              />
            </ComposedChart>
          </ResponsiveContainer>
          <div className="flex items-center justify-center gap-5 mt-2">
            {[
              { color: '#D4A853', label: 'Benefit' },
              { color: '#F87171', label: 'Cost' },
              { color: '#4ADE80', label: 'Net' },
            ].map((item) => (
              <div key={item.label} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: item.color, opacity: 0.8 }} />
                <span className="text-body-sm text-text-secondary">{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      </DataCard>

      {/* ── Section: CFO Stress Tests ── */}
      <DataCard title="CFO Stress Tests" subtitle="Board-ready stress scenarios">
        <div className="space-y-4 mt-4">
          {stressTests.map((test, i) => (
            <motion.div
              key={test.scenario}
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + i * 0.15, duration: 0.5, ease: EASE_SMOOTH }}
              className="bg-bg-primary border border-bg-quaternary rounded-lg p-5 hover:border-accent-primary/30 transition-all duration-300"
            >
              <div className="flex flex-wrap items-center gap-3 mb-3">
                <h4 className="text-heading-md text-text-primary">{test.scenario}</h4>
                <ConditionBadge severity={test.conditionSeverity} />
              </div>
              <p className="text-body-md text-text-secondary mb-4">{test.description}</p>
              <div className="flex flex-wrap items-center gap-6">
                <div>
                  <span className="text-label-sm text-text-tertiary">Result ROI</span>
                  <p className="text-mono-lg text-text-primary">
                    <NumberAnimation value={test.resultRoi} suffix="%" />
                  </p>
                </div>
                <div>
                  <span className="text-label-sm text-text-tertiary">Net Benefit</span>
                  <p className="text-mono-md text-accent-secondary">${test.netBenefit}M</p>
                </div>
                <div className="flex-1 min-w-[200px]">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-body-sm text-text-secondary flex-1">{test.verdict}</span>
                    <ConditionBadge severity={test.verdictBadge} />
                  </div>
                  {/* Mini comparison bar */}
                  <div className="h-2.5 bg-bg-quaternary rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${Math.min((test.resultRoi / 2742) * 100, 100)}%` }}
                      transition={{ delay: 0.6 + i * 0.15, duration: 0.6, ease: EASE_SMOOTH }}
                      className="h-full rounded-full bg-gradient-to-r from-accent-secondary to-chart-6"
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </DataCard>

      {/* ── Section: Risk Assessment & Mitigation ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Left: Risk Matrix */}
        <DataCard title="Risk Assessment Matrix" subtitle="Likelihood vs Impact scoring">
          {/* Risk table */}
          <div className="overflow-x-auto mt-4">
            <table className="w-full">
              <thead>
                <tr className="bg-bg-tertiary">
                  {['Risk Category', 'Likelihood', 'Impact', 'Score', 'Level'].map((h) => (
                    <th
                      key={h}
                      className="text-label-sm text-text-tertiary text-left px-3 py-2.5 font-medium"
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {risks.map((risk, i) => (
                  <motion.tr
                    key={risk.category}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 + i * 0.08, duration: 0.4 }}
                    className="border-b border-bg-quaternary hover:bg-bg-tertiary/30 transition-colors"
                  >
                    <td className="px-3 py-3 text-body-sm text-text-primary">{risk.category}</td>
                    <td className="px-3 py-3">
                      <SeverityBadge level={risk.likelihood} />
                    </td>
                    <td className="px-3 py-3">
                      <SeverityBadge level={risk.impact} />
                    </td>
                    <td className="px-3 py-3 text-mono-sm text-text-primary text-center">
                      {risk.score}
                    </td>
                    <td className="px-3 py-3">
                      <SeverityBadge level={risk.level} />
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
          {/* Heatmap */}
          <div className="mt-6">
            <h4 className="text-label-lg text-text-tertiary mb-3">Risk Heatmap</h4>
            <div className="relative h-[240px] bg-bg-primary border border-bg-quaternary rounded-lg">
              {/* Grid */}
              <div className="absolute inset-0 grid grid-cols-5 grid-rows-5">
                {Array.from({ length: 25 }).map((_, i) => {
                  const col = (i % 5) + 1;
                  const row = 5 - Math.floor(i / 5);
                  const intensity = (col + row) / 10;
                  return (
                    <div
                      key={i}
                      className="border border-bg-quaternary/30"
                      style={{
                        backgroundColor:
                          intensity > 0.7
                            ? `rgba(248,113,113,${intensity * 0.15})`
                            : intensity > 0.4
                            ? `rgba(212,168,83,${intensity * 0.15})`
                            : `rgba(74,222,128,${intensity * 0.1})`,
                      }}
                    />
                  );
                })}
              </div>
              {/* Axis labels */}
              <div className="absolute bottom-1 left-0 right-0 text-center text-[10px] text-text-tertiary">
                Likelihood → Low&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;High
              </div>
              <div
                className="absolute left-1 top-0 bottom-0 text-[10px] text-text-tertiary flex items-center"
                style={{ writingMode: 'vertical-lr', transform: 'rotate(180deg)' }}
              >
                Impact → Low&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;High
              </div>
              {/* Risk dots */}
              {risks.map((risk, i) => (
                <RiskHeatmapDot key={risk.category} risk={risk} index={i} />
              ))}
            </div>
          </div>
        </DataCard>

        {/* Right: Mitigation Strategies */}
        <DataCard title="Mitigation Strategies" subtitle="Risk response actions">
          <div className="space-y-2 mt-4">
            {risks.map((risk, i) => (
              <motion.div
                key={risk.category}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 + i * 0.1, duration: 0.4, ease: EASE_SMOOTH }}
                className="border border-bg-quaternary rounded-lg overflow-hidden"
              >
                <button
                  onClick={() =>
                    setOpenMitigation(openMitigation === i ? null : i)
                  }
                  className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-bg-tertiary/30 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Shield className="w-4 h-4 text-accent-primary" />
                    <span className="text-body-sm text-text-primary font-medium">
                      {risk.category}
                    </span>
                    <SeverityBadge level={risk.level} />
                  </div>
                  <ChevronDown
                    className={cn(
                      'w-4 h-4 text-text-secondary transition-transform duration-200',
                      openMitigation === i && 'rotate-180'
                    )}
                  />
                </button>
                <AnimatePresence initial={false}>
                  {openMitigation === i && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: EASE_SMOOTH }}
                      className="overflow-hidden"
                    >
                      <div className="px-4 pb-3 space-y-2">
                        {risk.mitigations.map((m, mi) => (
                          <div
                            key={mi}
                            className="flex items-start gap-2 text-body-sm text-text-secondary"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5 text-accent-secondary mt-0.5 flex-shrink-0" />
                            {m}
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </div>
        </DataCard>
      </div>

      {/* ── Section: NPV Tornado Analysis ── */}
      <DataCard
        title="Sensitivity-Adjusted NPV Tornado Analysis"
        subtitle="Impact of key drivers on 3-Year NPV ($171M base)"
      >
        {/* Tornado chart */}
        <div className="mt-4 h-[340px]">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart
              data={sortedNpvTornado}
              layout="vertical"
              margin={{ top: 10, right: 30, left: 10, bottom: 10 }}
              barCategoryGap={14}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" horizontal={false} />
              <XAxis
                type="number"
                domain={[50, 280]}
                tick={{ fill: '#94A3B8', fontSize: 12 }}
                axisLine={{ stroke: 'rgba(148,163,184,0.3)' }}
                tickFormatter={(v: number) => `$${v}M`}
              />
              <YAxis
                dataKey="driver"
                type="category"
                tick={{ fill: '#94A3B8', fontSize: 12 }}
                axisLine={{ stroke: 'rgba(148,163,184,0.3)' }}
                width={160}
              />
              <Tooltip content={<NpvTornadoTooltip />} />
              <Bar dataKey="high" fill="#4ADE80" radius={[0, 4, 4, 0]} opacity={0.85} name="High" />
              <Bar dataKey="low" fill="#F87171" radius={[0, 4, 4, 0]} opacity={0.85} name="Low" />
              <ReferenceLine
                x={171}
                stroke="#D4A853"
                strokeDasharray="4 4"
                strokeWidth={1.5}
                label={{
                  value: 'Base $171M',
                  position: 'top',
                  fill: '#D4A853',
                  fontSize: 11,
                }}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
        {/* Legend */}
        <div className="flex items-center justify-center gap-5 mt-2">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-sm bg-accent-secondary/85" />
            <span className="text-body-sm text-text-secondary">High case (+variance)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-sm bg-accent-tertiary/85" />
            <span className="text-body-sm text-text-secondary">Low case (-variance)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-0.5 bg-accent-primary" style={{ borderTop: '2px dashed #D4A853' }} />
            <span className="text-body-sm text-text-secondary">Base NPV</span>
          </div>
        </div>

        {/* Table below chart */}
        <div className="overflow-x-auto mt-6">
          <table className="w-full">
            <thead>
              <tr className="bg-bg-tertiary">
                {['Driver', 'Low Case', 'Base', 'High Case', 'Swing'].map((h) => (
                  <th
                    key={h}
                    className="text-label-sm text-text-tertiary text-left px-4 py-3 font-medium"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {sortedNpvTornado.map((row, i) => (
                <motion.tr
                  key={row.driver}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6 + i * 0.08, duration: 0.4, ease: EASE_SMOOTH }}
                  className="border-b border-bg-quaternary hover:bg-bg-tertiary/30 transition-colors"
                >
                  <td className="px-4 py-3 text-body-sm text-text-primary font-medium">
                    {row.driver}
                  </td>
                  <td className="px-4 py-3 text-mono-sm text-accent-tertiary">${row.low}M</td>
                  <td className="px-4 py-3 text-mono-sm text-accent-primary">${row.base}M</td>
                  <td className="px-4 py-3 text-mono-sm text-accent-secondary">${row.high}M</td>
                  <td className="px-4 py-3 text-mono-sm text-text-primary">${row.swing}M</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </DataCard>

      {/* ── Section: Financial Model with Sensitivity Analysis ── */}
      <DataCard
        title="Complete Financial Model — Sensitivity Adjusted"
        subtitle="Comprehensive summary across all scenarios"
      >
        {/* Assumptions strip */}
        <div className="bg-bg-primary border border-bg-quaternary rounded-lg p-4 mt-4 mb-6">
          <h4 className="text-label-lg text-text-tertiary mb-2">Baseline Assumptions</h4>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: 'Users', value: '6,000' },
              { label: 'License', value: '$30/user/mo' },
              { label: 'Adoption', value: '85%' },
              { label: 'WACC', value: '8%' },
            ].map((a) => (
              <div key={a.label} className="flex items-center gap-2">
                <span className="text-body-sm text-text-secondary">{a.label}:</span>
                <span className="text-body-sm text-text-primary font-mono">{a.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Summary table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-bg-tertiary">
                {['Metric', 'Low Case', 'Base Case', 'High Case'].map((h) => (
                  <th
                    key={h}
                    className="text-label-sm text-text-tertiary text-left px-4 py-3 font-medium"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {financialSummary.map((row, i) => (
                <motion.tr
                  key={row.metric}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + i * 0.08, duration: 0.4, ease: EASE_SMOOTH }}
                  className="border-b border-bg-quaternary hover:bg-bg-tertiary/30 transition-colors"
                >
                  <td className="px-4 py-3.5 text-body-sm text-text-primary font-medium">
                    {row.metric}
                  </td>
                  <td className="px-4 py-3.5 text-mono-sm text-accent-tertiary">
                    {row.unit === '$M' ? '$' : ''}
                    {row.low.toLocaleString()}
                    {row.unit === '%' ? '%' : row.unit === 'mo' ? ' months' : 'M'}
                  </td>
                  <td className="px-4 py-3.5 text-mono-sm text-accent-primary">
                    {row.unit === '$M' ? '$' : ''}
                    {row.base.toLocaleString()}
                    {row.unit === '%' ? '%' : row.unit === 'mo' ? ' months' : 'M'}
                  </td>
                  <td className="px-4 py-3.5 text-mono-sm text-accent-secondary">
                    {row.unit === '$M' ? '$' : ''}
                    {row.high.toLocaleString()}
                    {row.unit === '%' ? '%' : row.unit === 'mo' ? ' months' : 'M'}
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Visual comparison bars */}
        <div className="mt-6 space-y-4">
          {financialSummary.slice(0, 4).map((row, i) => (
            <motion.div
              key={row.metric}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + i * 0.1, duration: 0.4, ease: EASE_SMOOTH }}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-body-sm text-text-secondary">{row.metric}</span>
              </div>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { value: row.low, color: '#F87171', label: 'Low' },
                  { value: row.base, color: '#D4A853', label: 'Base' },
                  { value: row.high, color: '#4ADE80', label: 'High' },
                ].map((bar) => {
                  const maxVal = row.metric.includes('Cost') ? row.high * 1.2 : row.high * 1.2;
                  const pct = Math.min((bar.value / maxVal) * 100, 100);
                  return (
                    <div key={bar.label} className="flex items-center gap-2">
                      <div className="flex-1 h-3 bg-bg-quaternary rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${pct}%` }}
                          transition={{ delay: 0.7 + i * 0.1, duration: 0.5, ease: EASE_SMOOTH }}
                          className="h-full rounded-full"
                          style={{ backgroundColor: bar.color }}
                        />
                      </div>
                      <span className="text-mono-sm text-text-secondary w-16 text-right">
                        {row.unit === '$M' ? '$' : ''}
                        {bar.value}
                        {row.unit === '%' ? '%' : row.unit === 'mo' ? 'mo' : 'M'}
                      </span>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          ))}
        </div>

        {/* CFO Interpretation callout */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.0, duration: 0.5, ease: EASE_SMOOTH }}
          className="mt-6 bg-accent-primary-muted border border-accent-primary/20 rounded-lg px-5 py-4 flex items-start gap-3"
        >
          <ShieldCheck className="w-5 h-5 text-accent-primary flex-shrink-0 mt-0.5" />
          <p className="text-body-md text-text-primary">
            The sensitivity analysis confirms a robust investment case. Even under the low scenario,
            Copilot delivers a <span className="text-accent-primary font-medium">2,500% ROI</span>{' '}
            with a <span className="text-accent-primary font-medium">7-month payback</span>. The base
            case NPV of <span className="text-accent-primary font-medium">$171M</span> represents
            substantial shareholder and ratepayer value.
          </p>
        </motion.div>
      </DataCard>
    </div>
  );
}
