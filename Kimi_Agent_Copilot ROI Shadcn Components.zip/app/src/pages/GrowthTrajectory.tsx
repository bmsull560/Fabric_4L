import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, LineChart, Line, ReferenceLine, BarChart, Bar, Cell,
} from 'recharts';
import {
  TrendingUp, Calendar, ArrowUpRight, Percent, DollarSign,
  ChevronLeft, ChevronRight, Calculator, Shield,
} from 'lucide-react';
import KpiCard from '../components/KpiCard';
import DataCard from '../components/DataCard';
import NumberAnimation from '../components/NumberAnimation';

/* ------------------------------------------------------------------ */
/*  DATA TYPES                                                         */
/* ------------------------------------------------------------------ */
interface MonthlyRow {
  month: string;
  monthNum: number;
  users: number;
  adoptionFactor: number;
  benefit: number;
  cost: number;
  netBenefit: number;
  monthlyRoi: number;
  cumBenefit: number;
  cumCost: number;
  cumNet: number;
  cumRoi: number;
}

interface DcfRow {
  month: number;
  monthLabel: string;
  cashInflow: number;
  cashOutflow: number;
  netCashFlow: number;
  discountFactor: number;
  presentValue: number;
  cumPv: number;
}

/* ------------------------------------------------------------------ */
/*  ANIMATION CONFIG                                                   */
/* ------------------------------------------------------------------ */
const cardEase = [0.22, 1, 0.36, 1] as [number, number, number, number];

/* ------------------------------------------------------------------ */
/*  DATA GENERATION — 37 months (Jan 2025 → Jan 2028)                  */
/* ------------------------------------------------------------------ */
const MONTH_NAMES = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

function generateMonthlyData(): MonthlyRow[] {
  const rows: MonthlyRow[] = [];
  const adoptionMap: Record<number, { factor: number; users: number; benefit: number }> = {
    1:  { factor: 0,   users: 0,    benefit: 0 },
    2:  { factor: 0,   users: 0,    benefit: 0 },
    3:  { factor: 0.2, users: 1200, benefit: 1.2 },
    4:  { factor: 0.35, users: 2100, benefit: 2.1 },
    5:  { factor: 0.5, users: 3000, benefit: 3.0 },
    6:  { factor: 0.65, users: 3900, benefit: 3.9 },
    7:  { factor: 0.8, users: 4800, benefit: 4.8 },
  };

  let cumBenefit = 0;
  let cumCost = 0;
  const monthlyCost = 0.21;

  for (let m = 1; m <= 37; m++) {
    const date = new Date(2025, m - 1, 1);
    const label = `${MONTH_NAMES[date.getMonth()]} ${date.getFullYear()}`;
    const ad = adoptionMap[m] ?? { factor: 1.0, users: 6000, benefit: 6.0 };
    const benefit = ad.benefit;
    const cost = monthlyCost;
    const net = benefit - cost;
    const roi = cost > 0 ? (net / cost) * 100 : 0;
    cumBenefit += benefit;
    cumCost += cost;
    const cumNet = cumBenefit - cumCost;
    const cumRoi = cumCost > 0 ? (cumNet / cumCost) * 100 : 0;

    rows.push({
      month: label,
      monthNum: m,
      users: ad.users,
      adoptionFactor: ad.factor,
      benefit,
      cost,
      netBenefit: net,
      monthlyRoi: roi,
      cumBenefit,
      cumCost,
      cumNet,
      cumRoi,
    });
  }
  return rows;
}

const monthlyData = generateMonthlyData();

/* ------------------------------------------------------------------ */
/*  DCF DATA GENERATION                                                */
/* ------------------------------------------------------------------ */
const ANNUAL_DISCOUNT = 0.08;
const MONTHLY_DISCOUNT_FACTOR = Math.pow(1 + ANNUAL_DISCOUNT, 1 / 12) - 1;

function generateDcfData(): DcfRow[] {
  const rows: DcfRow[] = [];
  let cumPv = 0;

  for (let m = 1; m <= 37; m++) {
    const md = monthlyData[m - 1];
    const discountFactor = 1 / Math.pow(1 + MONTHLY_DISCOUNT_FACTOR, m);
    const pv = md.netBenefit * discountFactor;
    cumPv += pv;
    rows.push({
      month: m,
      monthLabel: md.month,
      cashInflow: md.benefit,
      cashOutflow: md.cost,
      netCashFlow: md.netBenefit,
      discountFactor,
      presentValue: pv,
      cumPv,
    });
  }
  return rows;
}

const dcfData = generateDcfData();

/* ------------------------------------------------------------------ */
/*  ADOPTION RAMP TABLE DATA                                           */
/* ------------------------------------------------------------------ */
const adoptionPhases = [
  { phase: 'Foundation', months: '1–3', users: '0→1,200', factor: '0.0→0.20', benefit: '$0→$1.2M' },
  { phase: 'Early Scale', months: '4–6', users: '1,200→3,900', factor: '0.20→0.65', benefit: '$1.2M→$3.9M' },
  { phase: 'Mid Scale', months: '7–9', users: '3,900→6,000', factor: '0.65→1.00', benefit: '$3.9M→$6.0M' },
  { phase: 'Late Scale', months: '10–12', users: '6,000', factor: '1.00', benefit: '$6.0M' },
  { phase: 'Optimization', months: '13–18', users: '6,000', factor: '1.00', benefit: '$6.0M' },
  { phase: 'Steady State', months: '19–37', users: '6,000', factor: '1.00', benefit: '$6.0M' },
];

/* ------------------------------------------------------------------ */
/*  SENSITIVITY DATA                                                   */
/* ------------------------------------------------------------------ */
const sensitivityData = [
  { driver: 'Productivity Gain', low: 142, base: 171, high: 205, lowLabel: '−17%', highLabel: '+20%' },
  { driver: 'Adoption Speed', low: 148, base: 171, high: 198, lowLabel: 'Slow', highLabel: 'Fast' },
  { driver: 'Discount Rate', low: 185, base: 171, high: 158, lowLabel: '6%', highLabel: '10%' },
  { driver: 'Cost Inflation', low: 178, base: 171, high: 164, lowLabel: '−4%', highLabel: '+4%' },
  { driver: 'Coverage Scope', low: 128, base: 171, high: 214, lowLabel: 'Narrow', highLabel: 'Broad' },
];

/* ------------------------------------------------------------------ */
/*  CHART TOOLTIPS                                                     */
/* ------------------------------------------------------------------ */
const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-bg-secondary border border-bg-quaternary rounded-lg px-3 py-2 shadow-[0_4px_20px_rgba(0,0,0,0.3)]">
      <p className="text-body-sm text-text-primary font-medium mb-1">{label}</p>
      {payload.map((p: any, i: number) => (
        <p key={i} className="text-body-sm" style={{ color: p.color }}>
          {p.name}: {p.value >= 1000 ? `$${(p.value / 1000).toFixed(1)}B` : `$${p.value.toFixed(1)}M`}
        </p>
      ))}
    </div>
  );
};

const AdoptionTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-bg-secondary border border-bg-quaternary rounded-lg px-3 py-2 shadow-[0_4px_20px_rgba(0,0,0,0.3)]">
      <p className="text-body-sm text-text-primary font-medium">Month {label}</p>
      {payload.map((p: any, i: number) => (
        <p key={i} className="text-body-sm" style={{ color: p.color }}>
          {p.name}: {p.value?.toLocaleString?.()} {p.name === 'Users' ? 'users' : p.name === 'Adoption Factor' ? '' : `$${p.value}M`}
        </p>
      ))}
    </div>
  );
};

const SensitivityTooltip = ({ active, payload }: any) => {
  if (!active || !payload?.length) return null;
  const d = payload[0]?.payload;
  if (!d) return null;
  return (
    <div className="bg-bg-secondary border border-bg-quaternary rounded-lg px-3 py-2 shadow-[0_4px_20px_rgba(0,0,0,0.3)]">
      <p className="text-body-sm text-text-primary font-medium">{d.driver}</p>
      <p className="text-body-sm text-accent-secondary">High: ${d.high}M ({d.highLabel})</p>
      <p className="text-body-sm text-chart-1">Base: ${d.base}M</p>
      <p className="text-body-sm text-accent-tertiary">Low: ${d.low}M ({d.lowLabel})</p>
    </div>
  );
};

/* ------------------------------------------------------------------ */
/*  PAGINATED TABLE COMPONENT                                          */
/* ------------------------------------------------------------------ */
function PaginatedTable({ data }: { data: MonthlyRow[] }) {
  const [page, setPage] = useState(0);
  const pageSize = 12;
  const totalPages = Math.ceil(data.length / pageSize);
  const pageData = data.slice(page * pageSize, (page + 1) * pageSize);

  return (
    <div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-bg-tertiary">
              {['Month','Users','Benefit','Cost','Net Benefit','Monthly ROI','Cum. Benefit','Cum. ROI'].map(h => (
                <th key={h} className="text-label-sm text-text-tertiary text-left px-3 py-3 font-medium tracking-wider">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pageData.map((row, i) => {
              const isNegative = row.netBenefit < 0;
              const isBreakEven = row.netBenefit > 0 && row.monthNum <= 4;
              return (
                <motion.tr
                  key={row.month}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.03, duration: 0.3, ease: cardEase }}
                  className={`border-b border-bg-quaternary transition-colors duration-200 ${
                    isNegative ? 'bg-accent-tertiary-muted' :
                    isBreakEven ? 'bg-accent-secondary-muted' :
                    i % 2 === 0 ? 'bg-bg-primary' : 'bg-bg-secondary'
                  } ${isBreakEven ? 'border-l-2 border-l-accent-primary' : ''}`}
                  style={{ height: '44px' }}
                >
                  <td className="px-3 text-body-md text-text-primary">{row.month}</td>
                  <td className="px-3 text-mono-sm text-text-secondary text-right">{row.users.toLocaleString()}</td>
                  <td className="px-3 text-mono-sm text-text-secondary text-right">${row.benefit.toFixed(2)}M</td>
                  <td className="px-3 text-mono-sm text-text-secondary text-right">${row.cost.toFixed(2)}M</td>
                  <td className={`px-3 text-mono-sm text-right ${row.netBenefit >= 0 ? 'text-accent-secondary' : 'text-accent-tertiary'}`}>
                    {row.netBenefit >= 0 ? '+' : ''}${row.netBenefit.toFixed(2)}M
                  </td>
                  <td className={`px-3 text-mono-sm text-right ${row.monthlyRoi >= 0 ? 'text-accent-secondary' : 'text-accent-tertiary'}`}>
                    {row.monthlyRoi >= 0 ? '+' : ''}{row.monthlyRoi.toFixed(0)}%
                  </td>
                  <td className="px-3 text-mono-sm text-text-primary text-right font-medium">${row.cumBenefit.toFixed(1)}M</td>
                  <td className="px-3 text-mono-sm text-accent-secondary text-right">+{row.cumRoi.toFixed(0)}%</td>
                </motion.tr>
              );
            })}
          </tbody>
        </table>
      </div>
      {/* Pagination */}
      <div className="flex items-center justify-between mt-4 px-2">
        <span className="text-body-sm text-text-tertiary">
          Showing {page * pageSize + 1}–{Math.min((page + 1) * pageSize, data.length)} of {data.length} months
        </span>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setPage(p => Math.max(0, p - 1))}
            disabled={page === 0}
            className="p-1.5 rounded-button bg-bg-tertiary text-text-secondary hover:bg-bg-quaternary hover:text-text-primary disabled:opacity-30 disabled:cursor-not-allowed transition-all"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          {Array.from({ length: totalPages }, (_, i) => (
            <button
              key={i}
              onClick={() => setPage(i)}
              className={`w-8 h-8 rounded-button text-body-sm font-medium transition-all ${
                i === page ? 'bg-accent-primary text-text-inverse' : 'bg-bg-tertiary text-text-secondary hover:bg-bg-quaternary'
              }`}
            >
              {i + 1}
            </button>
          ))}
          <button
            onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
            disabled={page === totalPages - 1}
            className="p-1.5 rounded-button bg-bg-tertiary text-text-secondary hover:bg-bg-quaternary hover:text-text-primary disabled:opacity-30 disabled:cursor-not-allowed transition-all"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  DCF TABLE                                                          */
/* ------------------------------------------------------------------ */
function DcfTable({ data }: { data: DcfRow[] }) {
  const keyMonths = [1, 2, 3, 4, 5, 6, 7, 12, 18, 24, 30, 37];
  const filtered = data.filter(d => keyMonths.includes(d.month));

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="bg-bg-tertiary">
            {['Month','Cash Inflow','Cash Outflow','Net Cash Flow','Discount Factor','Present Value','Cumulative PV'].map(h => (
              <th key={h} className="text-label-sm text-text-tertiary text-left px-3 py-3 font-medium tracking-wider">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {filtered.map((row, i) => (
            <motion.tr
              key={row.month}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.04, duration: 0.3, ease: cardEase }}
              className={`border-b border-bg-quaternary ${i % 2 === 0 ? 'bg-bg-primary' : 'bg-bg-secondary'}`}
              style={{ height: '48px' }}
            >
              <td className="px-3 text-body-md text-text-primary font-medium">{row.monthLabel}</td>
              <td className="px-3 text-mono-sm text-accent-secondary text-right">${row.cashInflow.toFixed(2)}M</td>
              <td className="px-3 text-mono-sm text-accent-tertiary text-right">${row.cashOutflow.toFixed(2)}M</td>
              <td className={`px-3 text-mono-sm text-right ${row.netCashFlow >= 0 ? 'text-accent-secondary' : 'text-accent-tertiary'}`}>
                {row.netCashFlow >= 0 ? '+' : ''}${row.netCashFlow.toFixed(2)}M
              </td>
              <td className="px-3 text-mono-sm text-text-secondary text-right">{row.discountFactor.toFixed(4)}</td>
              <td className="px-3 text-mono-sm text-chart-1 text-right">${row.presentValue.toFixed(2)}M</td>
              <td className="px-3 text-mono-sm text-accent-primary text-right font-medium">${row.cumPv.toFixed(1)}M</td>
            </motion.tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  WACC SLIDER COMPONENT                                              */
/* ------------------------------------------------------------------ */
function WaccSlider() {
  const [rate, setRate] = useState(8);
  const monthlyFactor = (Math.pow(1 + rate / 100, 1 / 12) - 1) * 100;

  // Recalculate NPV with new rate
  const npvAtRate = useMemo(() => {
    let npv = 0;
    for (let m = 1; m <= 37; m++) {
      const md = monthlyData[m - 1];
      const df = 1 / Math.pow(1 + rate / 100, m / 12);
      npv += md.netBenefit * df;
    }
    return npv;
  }, [rate]);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <div className="flex-1">
          <input
            type="range"
            min={4}
            max={12}
            step={0.5}
            value={rate}
            onChange={e => setRate(parseFloat(e.target.value))}
            className="w-full h-2 bg-bg-quaternary rounded-full appearance-none cursor-pointer accent-accent-primary"
            style={{ accentColor: '#D4A853' }}
          />
          <div className="flex justify-between mt-1">
            <span className="text-body-sm text-text-tertiary">4%</span>
            <span className="text-body-sm text-text-tertiary">12%</span>
          </div>
        </div>
        <div className="text-right min-w-[120px]">
          <div className="text-mono-md text-accent-primary">{rate.toFixed(1)}%</div>
          <div className="text-label-sm text-text-tertiary">ANNUAL</div>
        </div>
      </div>
      <div className="bg-bg-tertiary rounded-lg p-3">
        <div className="flex justify-between items-center">
          <span className="text-body-md text-text-secondary">Monthly discount factor</span>
          <span className="text-mono-sm text-text-primary">{monthlyFactor.toFixed(4)}%</span>
        </div>
        <div className="flex justify-between items-center mt-2">
          <span className="text-body-md text-text-secondary">Recalculated NPV</span>
          <span className="text-mono-md text-accent-primary">
            $<NumberAnimation value={npvAtRate} prefix="" suffix="M" decimals={1} />
          </span>
        </div>
      </div>
      {/* Mini NPV curve */}
      <div className="h-[120px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={Array.from({ length: 17 }, (_, i) => {
            const r = 4 + i * 0.5;
            let npv = 0;
            for (let m = 1; m <= 37; m++) {
              const md = monthlyData[m - 1];
              const df = 1 / Math.pow(1 + r / 100, m / 12);
              npv += md.netBenefit * df;
            }
            return { rate: r, npv };
          })}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" />
            <XAxis dataKey="rate" tick={{ fill: '#64748B', fontSize: 11 }} axisLine={{ stroke: 'rgba(148,163,184,0.3)' }} />
            <YAxis tick={{ fill: '#64748B', fontSize: 11 }} axisLine={{ stroke: 'rgba(148,163,184,0.3)' }} />
            <Tooltip content={({ active, payload }) => {
              if (!active || !payload?.length) return null;
              return (
                <div className="bg-bg-secondary border border-bg-quaternary rounded-lg px-3 py-2 shadow-lg">
                  <p className="text-body-sm text-text-primary">Rate: {payload[0].payload.rate}%</p>
                  <p className="text-body-sm text-chart-1">NPV: ${payload[0].payload.npv.toFixed(1)}M</p>
                </div>
              );
            }} />
            <Line type="monotone" dataKey="npv" stroke="#D4A853" strokeWidth={2} dot={false} />
            <ReferenceLine x={rate} stroke="#F87171" strokeDasharray="3 3" />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  MAIN COMPONENT                                                     */
/* ------------------------------------------------------------------ */
export default function GrowthTrajectory() {
  /* -- KPI values -- */
  const peakMonthlyBenefit = 6.0;
  const cumulativeBenefit = monthlyData[monthlyData.length - 1].cumBenefit;
  const totalNpv = dcfData[dcfData.length - 1].cumPv;

  return (
    <div className="px-8 py-6 space-y-6">
      {/* ====== HEADER ====== */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: cardEase }}
      >
        <div className="flex items-center gap-3 mb-1">
          <span className="text-label-lg text-text-tertiary tracking-wider">FINANCIAL MODELS</span>
          <span className="text-text-tertiary">/</span>
          <span className="text-label-lg text-accent-primary tracking-wider">3-YEAR GROWTH</span>
        </div>
        <h1 className="text-display-lg text-text-primary">3-Year Growth Trajectory</h1>
        <p className="text-body-lg text-text-secondary mt-2">
          Jan 2025 — Jan 2028 benefit / cost / ROI evolution with full DCF/NPV analysis
        </p>
        <span className="inline-block mt-3 px-3 py-1 rounded-md bg-accent-primary-muted text-label-sm text-accent-primary">
          37 MONTHS
        </span>
      </motion.div>

      {/* ====== KPI CARDS ====== */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <KpiCard
          icon={TrendingUp}
          label="Peak Monthly Benefit"
          value={peakMonthlyBenefit}
          valuePrefix="$"
          valueSuffix="M"
          valueDecimals={1}
          subtitle="Steady-state full deployment"
          index={0}
        />
        <KpiCard
          icon={DollarSign}
          label="Cumulative 3-Year Benefit"
          value={cumulativeBenefit}
          valuePrefix="$"
          valueSuffix="M"
          valueDecimals={1}
          subtitle="Before discounting"
          index={1}
        />
        <KpiCard
          icon={Calculator}
          label="3-Year NPV @ 8%"
          value={totalNpv}
          valuePrefix="$"
          valueSuffix="M"
          valueDecimals={1}
          subtitle="DCF-adjusted present value"
          index={2}
        />
      </div>

      {/* ====== ADOPTION RAMP MODEL ====== */}
      <DataCard title="Monthly Adoption Ramp" subtitle="User adoption curve from pilot to steady state">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Adoption Chart */}
          <div className="lg:col-span-2 h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlyData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="adoptGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#D4A853" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#D4A853" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" />
                <XAxis dataKey="monthNum" tick={{ fill: '#64748B', fontSize: 11 }} axisLine={{ stroke: 'rgba(148,163,184,0.3)' }} />
                <YAxis tick={{ fill: '#64748B', fontSize: 11 }} axisLine={{ stroke: 'rgba(148,163,184,0.3)' }} />
                <Tooltip content={<AdoptionTooltip />} />
                <Area type="monotone" dataKey="users" name="Users" stroke="#D4A853" strokeWidth={2} fill="url(#adoptGrad)" />
                <ReferenceLine x={3} stroke="#60A5FA" strokeDasharray="3 3" label={{ value: 'Foundation', fill: '#60A5FA', fontSize: 10, position: 'top' }} />
                <ReferenceLine x={12} stroke="#4ADE80" strokeDasharray="3 3" label={{ value: 'Scale', fill: '#4ADE80', fontSize: 10, position: 'top' }} />
                <ReferenceLine x={24} stroke="#D4A853" strokeDasharray="3 3" label={{ value: 'Steady State', fill: '#D4A853', fontSize: 10, position: 'top' }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          {/* Adoption Table */}
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-bg-tertiary">
                  {['Phase','Months','Users','Factor'].map(h => (
                    <th key={h} className="text-label-sm text-text-tertiary text-left px-2 py-2 font-medium">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {adoptionPhases.map((phase, i) => (
                  <motion.tr
                    key={phase.phase}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.06, duration: 0.3, ease: cardEase }}
                    className="border-b border-bg-quaternary"
                    style={{ height: '44px' }}
                  >
                    <td className="px-2 text-body-sm text-text-primary font-medium">{phase.phase}</td>
                    <td className="px-2 text-mono-sm text-text-secondary">{phase.months}</td>
                    <td className="px-2 text-mono-sm text-text-secondary">{phase.users}</td>
                    <td className="px-2 text-mono-sm text-accent-primary">{phase.factor}</td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </DataCard>

      {/* ====== MONTHLY ROI TABLE ====== */}
      <DataCard title="Monthly ROI Detail" subtitle="Complete month-by-month financial performance">
        <PaginatedTable data={monthlyData} />
      </DataCard>

      {/* ====== CUMULATIVE ROI TRAJECTORY ====== */}
      <DataCard title="Cumulative Benefit Trajectory" subtitle="Cumulative benefit growth and ROI progression">
        <div className="h-[380px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={monthlyData} margin={{ top: 10, right: 50, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="cumGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#D4A853" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#D4A853" stopOpacity={0.05} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" />
              <XAxis dataKey="month" tick={{ fill: '#64748B', fontSize: 10 }} axisLine={{ stroke: 'rgba(148,163,184,0.3)' }} />
              <YAxis yAxisId="left" tick={{ fill: '#64748B', fontSize: 11 }} axisLine={{ stroke: 'rgba(148,163,184,0.3)' }} label={{ value: 'Cum. Benefit ($M)', angle: -90, position: 'insideLeft', fill: '#64748B', fontSize: 11 }} />
              <YAxis yAxisId="right" orientation="right" tick={{ fill: '#64748B', fontSize: 11 }} axisLine={{ stroke: 'rgba(148,163,184,0.3)' }} label={{ value: 'Cum. ROI (%)', angle: 90, position: 'insideRight', fill: '#64748B', fontSize: 11 }} />
              <Tooltip content={<CustomTooltip />} />
              <Area yAxisId="left" type="monotone" dataKey="cumBenefit" name="Cumulative Benefit" stroke="#D4A853" strokeWidth={2.5} fill="url(#cumGrad)" />
              <Line yAxisId="right" type="monotone" dataKey="cumRoi" name="Cumulative ROI" stroke="#4ADE80" strokeWidth={2} dot={false} />
              <ReferenceLine yAxisId="left" y={7.77} stroke="#F87171" strokeDasharray="5 5" label={{ value: 'Break-even ($7.8M cost)', fill: '#F87171', fontSize: 10 }} />
              <ReferenceLine yAxisId="left" y={totalNpv} stroke="#60A5FA" strokeDasharray="5 5" label={{ value: `NPV ($${totalNpv.toFixed(0)}M)`, fill: '#60A5FA', fontSize: 10 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        {/* Annotation pills */}
        <div className="flex flex-wrap gap-3 mt-4">
          {[
            { label: 'Break-even', value: 'Month 3', color: '#F87171' },
            { label: 'Full Adoption', value: 'Month 8', color: '#D4A853' },
            { label: 'NPV Achieved', value: 'Month 37', color: '#60A5FA' },
          ].map(tag => (
            <div key={tag.label} className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-bg-tertiary">
              <div className="w-2 h-2 rounded-full" style={{ backgroundColor: tag.color }} />
              <span className="text-label-sm text-text-tertiary">{tag.label}</span>
              <span className="text-body-sm text-text-primary font-medium">{tag.value}</span>
            </div>
          ))}
        </div>
      </DataCard>

      {/* ====== DCF / NPV ANALYSIS ====== */}
      <DataCard
        title="Discounted Cash Flow Analysis"
        subtitle="8% annual discount rate, monthly discount factor"
        actions={
          <div className="flex items-center gap-2">
            <button className="px-3 py-1.5 rounded-button bg-bg-tertiary text-body-sm text-text-secondary hover:text-text-primary hover:bg-bg-quaternary transition-all">
              Export DCF
            </button>
          </div>
        }
      >
        {/* Core inputs */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-5">
          {[
            { label: 'Annual Benefit (SS)', value: '$72.0M' },
            { label: 'Monthly Benefit (SS)', value: '$6.0M' },
            { label: 'Monthly Cost', value: '$0.21M' },
            { label: 'Monthly Net (SS)', value: '$5.79M' },
            { label: 'Annual Discount Rate', value: '8.0%' },
          ].map(item => (
            <div key={item.label} className="bg-bg-tertiary rounded-lg p-3 text-center">
              <div className="text-label-sm text-text-tertiary">{item.label}</div>
              <div className="text-mono-sm text-text-primary mt-1 font-medium">{item.value}</div>
            </div>
          ))}
        </div>

        <DcfTable data={dcfData} />

        {/* Summary box */}
        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.8, duration: 0.5, ease: cardEase }}
          className="mt-5 bg-bg-tertiary border border-accent-primary/30 rounded-lg p-5 animate-glow-pulse"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div>
              <div className="text-label-sm text-text-tertiary">Steady-State Monthly PV</div>
              <div className="text-mono-lg text-text-primary mt-1">
                $<NumberAnimation value={5.64} decimals={2} suffix="M" />
              </div>
            </div>
            <div>
              <div className="text-label-sm text-text-tertiary">Total NPV (37 months)</div>
              <div className="text-mono-lg text-accent-primary mt-1">
                $<NumberAnimation value={totalNpv} decimals={1} suffix="M" />
              </div>
            </div>
            <div>
              <div className="text-label-sm text-text-tertiary">Benefit / Cost Ratio</div>
              <div className="text-mono-lg text-accent-secondary mt-1">
                <NumberAnimation value={28.4} decimals={1} suffix="x" />
              </div>
            </div>
          </div>
        </motion.div>
      </DataCard>

      {/* ====== WACC / DISCOUNT RATE MODEL ====== */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <DataCard title="Discount Rate Model" subtitle="Interactive WACC adjustment">
          <div className="space-y-3 mb-4">
            <div className="flex items-center justify-between">
              <span className="text-body-md text-text-secondary">Annual discount rate</span>
              <span className="text-mono-md text-accent-primary">8.00%</span>
            </div>
            <div className="bg-bg-primary rounded-lg p-3 font-mono text-body-sm text-text-secondary">
              <span className="text-accent-info">(1 + 0.08)</span>
              <sup className="text-accent-primary">(1/12)</sup> - 1 = <span className="text-accent-secondary">{(MONTHLY_DISCOUNT_FACTOR * 100).toFixed(4)}%</span>
            </div>
            <div className="text-body-sm text-text-tertiary">
              Conservative estimate for regulated utility. Comparable to industry WACC range of 6.5% – 9.0%.
            </div>
          </div>
          <WaccSlider />
        </DataCard>

        {/* ====== SENSITIVITY TORNADO ====== */}
        <DataCard title="Sensitivity-Adjusted NPV" subtitle="Tornado chart — 5 key drivers">
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={sensitivityData}
                layout="vertical"
                margin={{ top: 10, right: 30, left: 20, bottom: 0 }}
                barSize={12}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" />
                <XAxis type="number" domain={[100, 220]} tick={{ fill: '#64748B', fontSize: 11 }} axisLine={{ stroke: 'rgba(148,163,184,0.3)' }} />
                <YAxis dataKey="driver" type="category" tick={{ fill: '#94A3B8', fontSize: 11 }} axisLine={{ stroke: 'rgba(148,163,184,0.3)' }} width={110} />
                <Tooltip content={<SensitivityTooltip />} />
                <ReferenceLine x={171} stroke="#D4A853" strokeDasharray="3 3" label={{ value: 'Base $171M', fill: '#D4A853', fontSize: 10, position: 'top' }} />
                <Bar dataKey="low" name="Low" fill="#F87171" radius={[0, 4, 4, 0]} />
                <Bar dataKey="high" name="High" fill="#4ADE80" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-3 gap-2 mt-3">
            {[
              { label: 'Base NPV', value: '$171M', color: 'text-chart-1' },
              { label: 'Worst Case', value: '$128M', color: 'text-accent-tertiary' },
              { label: 'Best Case', value: '$214M', color: 'text-accent-secondary' },
            ].map(item => (
              <div key={item.label} className="text-center bg-bg-tertiary rounded-lg p-2">
                <div className="text-label-sm text-text-tertiary">{item.label}</div>
                <div className={`text-mono-sm ${item.color} font-medium mt-0.5`}>{item.value}</div>
              </div>
            ))}
          </div>
        </DataCard>
      </div>
    </div>
  );
}
