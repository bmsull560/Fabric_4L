import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Monitor,
  Briefcase,
  Wrench,
  Headset,
  Users,
  Clock,
  DollarSign,
  TrendingUp,
  Activity,
  UserCheck,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import KpiCard from '../components/KpiCard';
import DataCard from '../components/DataCard';
import NumberAnimation from '../components/NumberAnimation';
import { Slider } from '../components/ui/slider';
import { Label } from '../components/ui/label';
import { Input } from '../components/ui/input';

/* ──────────────────────────── animation helpers ──────────────────────────── */

const cardEntrance = {
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] },
};

/* ──────────────────────────── chart tooltip ──────────────────────────── */

const ChartTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-[#111827] border border-[#232D42] rounded-lg px-3 py-2 shadow-[0_4px_20px_rgba(0,0,0,0.3)]">
      {label && <p className="text-body-sm text-text-primary font-medium mb-1">{label}</p>}
      {payload.map((p: any, i: number) => (
        <p key={i} className="text-body-sm" style={{ color: p.color }}>
          {p.name}: {typeof p.value === 'number' ? p.value.toLocaleString() : p.value}
        </p>
      ))}
    </div>
  );
};

/* ──────────────────────────── segment definitions ──────────────────────────── */

interface Segment {
  id: string;
  name: string;
  label: string;
  headcount: number;
  defaultHrsSaved: number;
  defaultRate: number;
  color: string;
  gradientColor: string;
  icon: React.ElementType;
  useCases: string[];
}

const segments: Segment[] = [
  {
    id: 'it',
    name: 'IT Workers',
    label: 'Information Technology',
    headcount: 2000,
    defaultHrsSaved: 15,
    defaultRate: 85,
    color: '#60A5FA',
    gradientColor: 'from-[#60A5FA] to-[#3B82F6]',
    icon: Monitor,
    useCases: ['Code review', 'Documentation', 'Incident response', 'Security analysis'],
  },
  {
    id: 'corporate',
    name: 'Corporate Knowledge Workers',
    label: 'Corporate Knowledge Workers',
    headcount: 4000,
    defaultHrsSaved: 10,
    defaultRate: 72,
    color: '#D4A853',
    gradientColor: 'from-[#D4A853] to-[#B8943A]',
    icon: Briefcase,
    useCases: ['Report generation', 'Data analysis', 'Presentation creation', 'Email drafting'],
  },
  {
    id: 'field',
    name: 'Field Technicians',
    label: 'Field Technicians',
    headcount: 3000,
    defaultHrsSaved: 6,
    defaultRate: 58,
    color: '#4ADE80',
    gradientColor: 'from-[#4ADE80] to-[#22C55E]',
    icon: Wrench,
    useCases: ['Work order prep', 'Documentation', 'Parts lookup', 'Troubleshooting guides'],
  },
  {
    id: 'cs',
    name: 'Customer Service',
    label: 'Customer Service Representatives',
    headcount: 1000,
    defaultHrsSaved: 8,
    defaultRate: 48,
    color: '#F472B6',
    gradientColor: 'from-[#F472B6] to-[#EC4899]',
    icon: Headset,
    useCases: ['Response drafting', 'Knowledge base lookup', 'Escalation prep', 'Call summarization'],
  },
];

/* ──────────────────────────── donut data ──────────────────────────── */

const donutData = segments.map((s) => ({
  name: s.name,
  value: s.headcount / 100,
  color: s.color,
}));

/* ──────────────────────────── ──────────────────────────── */

export default function Workforce() {
  const [hourlyRate, setHourlyRate] = useState(70);
  const [hrsSaved, setHrsSaved] = useState<Record<string, number>>({
    it: 15,
    corporate: 10,
    field: 6,
    cs: 8,
  });
  const [adoptionRate, setAdoptionRate] = useState(85);

  /* ── calculations ── */
  const calculations = segments.map((seg) => {
    const hrs = hrsSaved[seg.id] ?? seg.defaultHrsSaved;
    const rate = seg.defaultRate;
    const monthlyHrs = seg.headcount * hrs;
    const monthlyValue = monthlyHrs * rate;
    const annualValue = monthlyValue * 12;
    return {
      ...seg,
      hrsSavedPerUser: hrs,
      blendedRate: rate,
      monthlyHrs,
      monthlyValue,
      annualValue,
    };
  });

  const totalMonthlyHrs = calculations.reduce((sum, c) => sum + c.monthlyHrs, 0);
  const totalMonthlyValue = calculations.reduce((sum, c) => sum + c.monthlyValue, 0);
  const totalAnnualValue = calculations.reduce((sum, c) => sum + c.annualValue, 0);
  const adoptionFactor = adoptionRate / 100;
  const adjustedAnnualValue = totalAnnualValue * adoptionFactor;

  const totalHeadcount = segments.reduce((sum, s) => sum + s.headcount, 0);

  /* ── bar chart data (hours saved) ── */
  const hoursBarData = calculations.map((c) => ({
    segment: c.name,
    hours: c.hrsSavedPerUser,
    employees: c.headcount,
    color: c.color,
  }));

  /* ── area chart data (cumulative over 12 months) ── */
  const areaData = Array.from({ length: 12 }, (_, month) => {
    const point: Record<string, any> = { month: `Month ${month + 1}` };
    calculations.forEach((c) => {
      point[c.id] = Math.round((c.monthlyValue * (month + 1)) / 1e5) / 10;
    });
    return point;
  });

  /* ── table data with % of total ── */
  const tableData = calculations.map((c) => ({
    ...c,
    pctOfTotal: totalAnnualValue > 0 ? ((c.annualValue / totalAnnualValue) * 100).toFixed(1) : '0.0',
  }));

  /* ── KPI data ── */
  const workforceKpis = [
    {
      icon: Users,
      label: 'TOTAL WORKFORCE',
      value: totalHeadcount,
      valueSuffix: '',
      valueDecimals: 0,
      trend: { direction: 'positive' as const, text: '4 segments' },
      subtitle: '10,000-employee utility',
    },
    {
      icon: Clock,
      label: 'MONTHLY HOURS SAVED',
      value: Math.round(totalMonthlyHrs * adoptionFactor),
      valueSuffix: '',
      valueDecimals: 0,
      trend: { direction: 'positive' as const, text: 'Across all segments' },
      subtitle: 'At current adoption',
    },
    {
      icon: DollarSign,
      label: 'MONTHLY VALUE',
      value: Math.round((totalMonthlyValue * adoptionFactor) / 1e5) / 10,
      valuePrefix: '$',
      valueSuffix: 'M',
      valueDecimals: 1,
      trend: { direction: 'positive' as const, text: 'At blended rates' },
      subtitle: 'Before adoption adjustment',
    },
    {
      icon: TrendingUp,
      label: 'ANNUAL PRODUCTIVITY VALUE',
      value: Math.round(adjustedAnnualValue / 1e5) / 10,
      valuePrefix: '$',
      valueSuffix: 'M',
      valueDecimals: 1,
      trend: { direction: 'positive' as const, text: `${adoptionRate}% adoption` },
      subtitle: 'Adjusted for adoption',
    },
  ];

  return (
    <div className="px-8 py-6 space-y-5">
      {/* ── Page Header ── */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] }}
      >
        <h1 className="text-display-lg text-text-primary font-bold">Workforce & Productivity</h1>
        <p className="text-body-md text-text-secondary mt-2">
          Workforce segmentation, hours saved, and dollar value calculations across four operational segments
        </p>
      </motion.div>

      {/* ── KPI Strip ── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {workforceKpis.map((kpi, index) => (
          <KpiCard key={kpi.label} {...kpi} index={index} />
        ))}
      </div>

      {/* ── Interactive Controls ── */}
      <motion.div {...cardEntrance} transition={{ ...cardEntrance.transition, delay: 0.05 }}>
        <DataCard title="Interactive Model Controls" subtitle="Adjust parameters to recalculate productivity values">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Blended Rate Input */}
            <div>
              <Label className="text-label-sm text-text-tertiary mb-2 block">Fully Loaded Labor Cost ($/hr)</Label>
              <div className="flex items-center gap-3">
                <DollarSign className="w-4 h-4 text-text-tertiary" />
                <Input
                  type="number"
                  value={hourlyRate}
                  onChange={(e) => setHourlyRate(Number(e.target.value))}
                  className="bg-[#1A2235] border-[#232D42] text-mono-sm text-text-primary h-10"
                  min={30}
                  max={200}
                />
                <span className="text-body-sm text-text-secondary">/hr</span>
              </div>
              <Slider
                value={[hourlyRate]}
                onValueChange={(v) => setHourlyRate(v[0])}
                min={30}
                max={150}
                step={1}
                className="mt-2"
              />
            </div>

            {/* Adoption Rate */}
            <div>
              <Label className="text-label-sm text-text-tertiary mb-2 block">Adoption Rate (%)</Label>
              <div className="flex items-center gap-3">
                <UserCheck className="w-4 h-4 text-text-tertiary" />
                <Input
                  type="number"
                  value={adoptionRate}
                  onChange={(e) => setAdoptionRate(Math.min(100, Math.max(0, Number(e.target.value))))}
                  className="bg-[#1A2235] border-[#232D42] text-mono-sm text-text-primary h-10"
                  min={0}
                  max={100}
                />
                <span className="text-body-sm text-text-secondary">%</span>
              </div>
              <Slider
                value={[adoptionRate]}
                onValueChange={(v) => setAdoptionRate(v[0])}
                min={50}
                max={100}
                step={1}
                className="mt-2"
              />
            </div>

            {/* Hours Saved Summary */}
            <div className="flex items-center gap-3 bg-[#1A2235] rounded-lg p-3 border border-[#232D42]">
              <div className="w-10 h-10 rounded-lg bg-accent-primary-muted flex items-center justify-center">
                <Activity className="w-5 h-5 text-accent-primary" />
              </div>
              <div>
                <span className="text-label-sm text-text-tertiary block">Total Monthly Hours Saved</span>
                <span className="text-mono-md text-accent-primary">
                  <NumberAnimation value={Math.round(totalMonthlyHrs)} />
                </span>
              </div>
            </div>
          </div>

          {/* Hours Saved Per Segment */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-4">
            {segments.map((seg) => (
              <div key={seg.id} className="bg-[#1A2235] rounded-lg p-3 border border-[#232D42]">
                <div className="flex items-center gap-2 mb-2">
                  <seg.icon className="w-4 h-4" style={{ color: seg.color }} />
                  <span className="text-body-sm text-text-secondary">{seg.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    value={hrsSaved[seg.id] ?? seg.defaultHrsSaved}
                    onChange={(e) =>
                      setHrsSaved((prev) => ({ ...prev, [seg.id]: Number(e.target.value) }))
                    }
                    className="bg-[#111827] border-[#232D42] text-mono-sm text-text-primary h-8 w-20"
                    min={0}
                    max={40}
                  />
                  <span className="text-body-sm text-text-tertiary">hrs/mo saved</span>
                </div>
                <Slider
                  value={[hrsSaved[seg.id] ?? seg.defaultHrsSaved]}
                  onValueChange={(v) => setHrsSaved((prev) => ({ ...prev, [seg.id]: v[0] }))}
                  min={0}
                  max={30}
                  step={1}
                  className="mt-2"
                />
              </div>
            ))}
          </div>
        </DataCard>
      </motion.div>

      {/* ── 4 Segment Cards ── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {calculations.map((seg, index) => (
          <motion.div
            key={seg.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.5,
              delay: index * 0.1,
              ease: [0.22, 1, 0.36, 1] as [number, number, number, number],
            }}
            className="bg-[#111827] border border-[#232D42] rounded-card p-5 hover:border-accent-primary/30 hover:shadow-[0_4px_24px_rgba(212,168,83,0.08)] transition-all duration-300 group"
          >
            {/* Top color strip */}
            <div
              className="h-1 rounded-full mb-4"
              style={{ background: `linear-gradient(to right, ${seg.color}, ${seg.color}88)` }}
            />

            {/* Icon + Headcount */}
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${seg.color}20` }}>
                <seg.icon className="w-5 h-5" style={{ color: seg.color }} />
              </div>
              <span className="text-mono-md text-text-primary font-semibold">{seg.headcount.toLocaleString()}</span>
            </div>

            {/* Labels */}
            <span className="text-label-sm text-text-tertiary block">{seg.label}</span>

            {/* Hours Saved */}
            <div className="mt-3">
              <span className="text-heading-md text-accent-primary">{seg.hrsSavedPerUser} hrs</span>
              <span className="text-body-sm text-text-tertiary ml-2">/month saved</span>
            </div>

            {/* Rate + Values */}
            <div className="mt-3 space-y-1">
              <div className="flex justify-between">
                <span className="text-body-sm text-text-secondary">Hourly Rate</span>
                <span className="text-mono-sm text-text-primary">${seg.blendedRate}/hr</span>
              </div>
              <div className="flex justify-between">
                <span className="text-body-sm text-text-secondary">Monthly Value</span>
                <span className="text-mono-sm text-text-primary">
                  ${seg.monthlyValue >= 1e6 ? (seg.monthlyValue / 1e6).toFixed(2) + 'M' : (seg.monthlyValue / 1e3).toFixed(0) + 'K'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-body-sm text-text-secondary">Annual Value</span>
                <span className="text-mono-sm text-accent-primary">${(seg.annualValue / 1e6).toFixed(1)}M</span>
              </div>
            </div>

            {/* Use Cases */}
            <div className="mt-3 pt-3 border-t border-[#232D42]">
              <span className="text-label-sm text-text-tertiary block mb-1">Key Use Cases</span>
              <div className="flex flex-wrap gap-1">
                {seg.useCases.map((uc) => (
                  <span key={uc} className="px-2 py-0.5 rounded bg-[#1A2235] text-body-sm text-text-secondary">
                    {uc}
                  </span>
                ))}
              </div>
            </div>

            {/* View Details button on hover */}
            <button className="mt-3 w-full py-2 rounded-button text-body-sm text-text-secondary hover:text-text-primary hover:bg-[#1A2235] transition-all opacity-0 group-hover:opacity-100 duration-200">
              View Details
            </button>
          </motion.div>
        ))}
      </div>

      {/* ── Hard Productivity Calculations ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Table */}
        <motion.div {...cardEntrance} transition={{ ...cardEntrance.transition, delay: 0.2 }} className="lg:col-span-2">
          <DataCard title="Hard Productivity Calculations" subtitle="Verifiable, conservative estimates based on time-motion analysis">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-[#1A2235]">
                    <th className="text-label-sm text-text-tertiary text-left py-3 px-3">Segment</th>
                    <th className="text-label-sm text-text-tertiary text-right py-3 px-3">Headcount</th>
                    <th className="text-label-sm text-text-tertiary text-right py-3 px-3">Hrs/Mo Saved</th>
                    <th className="text-label-sm text-text-tertiary text-right py-3 px-3">Blended Rate</th>
                    <th className="text-label-sm text-text-tertiary text-right py-3 px-3">Monthly Value</th>
                    <th className="text-label-sm text-text-tertiary text-right py-3 px-3">Annual Value</th>
                    <th className="text-label-sm text-text-tertiary text-right py-3 px-3">% of Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#232D42]">
                  {tableData.map((row, idx) => (
                    <motion.tr
                      key={row.id}
                      className="hover:bg-[#1A2235]/50 transition-colors"
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3, delay: idx * 0.05 }}
                    >
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: row.color }} />
                          <span className="text-body-md text-text-primary">{row.name}</span>
                        </div>
                      </td>
                      <td className="py-3 px-3 text-mono-sm text-text-primary text-right">{row.headcount.toLocaleString()}</td>
                      <td className="py-3 px-3 text-mono-sm text-text-primary text-right">{row.hrsSavedPerUser}</td>
                      <td className="py-3 px-3 text-mono-sm text-text-primary text-right">${row.blendedRate}</td>
                      <td className="py-3 px-3 text-mono-sm text-text-primary text-right">
                        ${row.monthlyValue >= 1e6 ? (row.monthlyValue / 1e6).toFixed(2) + 'M' : (row.monthlyValue / 1e3).toFixed(0) + 'K'}
                      </td>
                      <td className="py-3 px-3 text-mono-sm text-accent-primary text-right">${(row.annualValue / 1e6).toFixed(1)}M</td>
                      <td className="py-3 px-3 text-mono-sm text-text-secondary text-right">{row.pctOfTotal}%</td>
                    </motion.tr>
                  ))}
                  {/* Total Row */}
                  <tr className="bg-[#1A2235] font-semibold border-t-2 border-[#232D42]">
                    <td className="py-3 px-3 text-body-md text-text-primary">TOTAL</td>
                    <td className="py-3 px-3 text-mono-sm text-text-primary text-right">{totalHeadcount.toLocaleString()}</td>
                    <td className="py-3 px-3 text-mono-sm text-text-tertiary text-right">—</td>
                    <td className="py-3 px-3 text-mono-sm text-text-tertiary text-right">—</td>
                    <td className="py-3 px-3 text-mono-sm text-text-primary text-right">
                      ${(totalMonthlyValue / 1e6).toFixed(2)}M
                    </td>
                    <td className="py-3 px-3 text-mono-sm text-accent-primary text-right">${(totalAnnualValue / 1e6).toFixed(1)}M</td>
                    <td className="py-3 px-3 text-mono-sm text-text-secondary text-right">100%</td>
                  </tr>
                  {/* Adoption Adjustment Row */}
                  <tr className="bg-accent-primary-muted italic">
                    <td className="py-3 px-3 text-body-md text-text-primary">Adoption Adjustment ({adoptionRate}%)</td>
                    <td className="py-3 px-3 text-mono-sm text-text-tertiary text-right">—</td>
                    <td className="py-3 px-3 text-mono-sm text-text-tertiary text-right">—</td>
                    <td className="py-3 px-3 text-mono-sm text-text-tertiary text-right">—</td>
                    <td className="py-3 px-3 text-mono-sm text-text-tertiary text-right">—</td>
                    <td className="py-3 px-3 text-mono-sm text-accent-primary text-right font-semibold">
                      ${(adjustedAnnualValue / 1e6).toFixed(1)}M
                    </td>
                    <td className="py-3 px-3 text-mono-sm text-text-secondary text-right">Adjusted</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </DataCard>
        </motion.div>

        {/* Summary Panel */}
        <motion.div {...cardEntrance} transition={{ ...cardEntrance.transition, delay: 0.25 }} className="lg:col-span-1">
          <DataCard title="Summary Metrics" subtitle="Key productivity aggregates">
            <div className="space-y-4">
              {/* Block 1: Total Monthly Hours */}
              <div className="bg-[#1A2235] rounded-lg p-4 border border-[#232D42]">
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="w-4 h-4 text-accent-info" />
                  <span className="text-label-sm text-text-tertiary">Total Monthly Hours Saved</span>
                </div>
                <span className="text-mono-lg text-text-primary block">
                  <NumberAnimation value={Math.round(totalMonthlyHrs * adoptionFactor)} />
                </span>
                <span className="text-body-sm text-text-tertiary">Across all segments at {adoptionRate}% adoption</span>
              </div>

              {/* Block 2: Dollar Value */}
              <div className="bg-[#1A2235] rounded-lg p-4 border border-[#232D42]">
                <div className="flex items-center gap-2 mb-2">
                  <DollarSign className="w-4 h-4 text-accent-secondary" />
                  <span className="text-label-sm text-text-tertiary">Dollar Value of Productivity</span>
                </div>
                <span className="text-mono-lg text-text-primary block">
                  $<NumberAnimation value={Math.round(totalMonthlyValue / 1e4) / 100} decimals={2} suffix="M/month" />
                </span>
                <span className="text-body-sm text-text-tertiary">At blended rates by segment</span>
              </div>

              {/* Block 3: Annualized */}
              <div className="bg-[#1A2235] rounded-lg p-4 border border-[#232D42]">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-4 h-4 text-accent-primary" />
                  <span className="text-label-sm text-text-tertiary">Annualized Productivity Value</span>
                </div>
                <span className="text-mono-lg text-accent-primary block">
                  $<NumberAnimation value={Math.round(adjustedAnnualValue / 1e5) / 10} decimals={1} suffix="M" />
                </span>
                <span className="text-body-sm text-text-tertiary">After {adoptionRate}% adoption adjustment</span>
              </div>
            </div>
          </DataCard>
        </motion.div>
      </div>

      {/* ── Hours Saved Bar Chart ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <motion.div {...cardEntrance} transition={{ ...cardEntrance.transition, delay: 0.25 }}>
          <DataCard title="Monthly Hours Saved — Distribution" subtitle="Hours saved per employee by segment">
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={hoursBarData} layout="vertical" barSize={32} barGap={4}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" horizontal={true} vertical={false} />
                <XAxis
                  type="number"
                  stroke="rgba(148,163,184,0.3)"
                  tick={{ fill: '#64748B', fontSize: 12 }}
                  axisLine={{ stroke: 'rgba(148,163,184,0.3)' }}
                  domain={[0, 20]}
                />
                <YAxis
                  dataKey="segment"
                  type="category"
                  stroke="rgba(148,163,184,0.3)"
                  tick={{ fill: '#94A3B8', fontSize: 12 }}
                  axisLine={{ stroke: 'rgba(148,163,184,0.3)' }}
                  width={120}
                />
                <Tooltip
                  content={({ active, payload }) => {
                    if (!active || !payload?.length) return null;
                    const d = payload[0]?.payload;
                    return (
                      <div className="bg-[#111827] border border-[#232D42] rounded-lg px-3 py-2 shadow-[0_4px_20px_rgba(0,0,0,0.3)]">
                        <p className="text-body-sm text-text-primary font-medium">{d?.segment}</p>
                        <p className="text-body-sm text-text-secondary">Hours saved: {d?.hours}/mo</p>
                        <p className="text-body-sm text-text-secondary">Employees: {d?.employees?.toLocaleString()}</p>
                      </div>
                    );
                  }}
                />
                <Bar dataKey="hours" name="Hours Saved/Month" radius={[0, 4, 4, 0]}>
                  {hoursBarData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </DataCard>
        </motion.div>

        {/* Cumulative Value Area Chart */}
        <motion.div {...cardEntrance} transition={{ ...cardEntrance.transition, delay: 0.3 }}>
          <DataCard title="Cumulative Value Over 12 Months" subtitle="Monthly productivity value accumulation by segment ($ Millions)">
            <ResponsiveContainer width="100%" height={280}>
              <AreaChart data={areaData}>
                <defs>
                  {calculations.map((c) => (
                    <linearGradient key={c.id} id={`grad-${c.id}`} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={c.color} stopOpacity={0.3} />
                      <stop offset="95%" stopColor={c.color} stopOpacity={0.05} />
                    </linearGradient>
                  ))}
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" vertical={false} />
                <XAxis
                  dataKey="month"
                  stroke="rgba(148,163,184,0.3)"
                  tick={{ fill: '#64748B', fontSize: 11 }}
                  axisLine={{ stroke: 'rgba(148,163,184,0.3)' }}
                />
                <YAxis
                  stroke="rgba(148,163,184,0.3)"
                  tick={{ fill: '#64748B', fontSize: 12 }}
                  axisLine={{ stroke: 'rgba(148,163,184,0.3)' }}
                  tickFormatter={(v) => `$${v}M`}
                />
                <Tooltip content={<ChartTooltip />} />
                <Legend
                  iconType="circle"
                  iconSize={8}
                  formatter={(value: string) => {
                    const seg = segments.find((s) => s.id === value);
                    return <span className="text-body-sm text-text-secondary ml-1">{seg?.name ?? value}</span>;
                  }}
                />
                {calculations.map((c) => (
                  <Area
                    key={c.id}
                    type="monotone"
                    dataKey={c.id}
                    name={c.id}
                    stroke={c.color}
                    fill={`url(#grad-${c.id})`}
                    strokeWidth={2}
                  />
                ))}
              </AreaChart>
            </ResponsiveContainer>
          </DataCard>
        </motion.div>
      </div>

      {/* ── Segment Distribution Donut ── */}
      <motion.div {...cardEntrance} transition={{ ...cardEntrance.transition, delay: 0.35 }}>
        <DataCard title="Workforce Segment Distribution" subtitle="Employee headcount by operational segment">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie
                  data={donutData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={90}
                  paddingAngle={3}
                  dataKey="value"
                  stroke="none"
                >
                  {donutData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip content={<ChartTooltip />} />
              </PieChart>
            </ResponsiveContainer>

            {/* Legend cards */}
            <div className="grid grid-cols-2 gap-3">
              {segments.map((seg) => {
                const calc = calculations.find((c) => c.id === seg.id);
                const pct = ((seg.headcount / totalHeadcount) * 100).toFixed(0);
                return (
                  <div key={seg.id} className="bg-[#1A2235] rounded-lg p-3 border border-[#232D42]">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: seg.color }} />
                      <span className="text-body-sm text-text-primary font-medium">{seg.name}</span>
                    </div>
                    <div className="text-mono-md text-text-primary">{seg.headcount.toLocaleString()}</div>
                    <div className="flex justify-between items-center mt-1">
                      <span className="text-body-sm text-text-tertiary">{pct}% of workforce</span>
                      <span className="text-mono-sm text-accent-primary">${calc ? (calc.annualValue / 1e6).toFixed(1) : 0}M/yr</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </DataCard>
      </motion.div>
    </div>
  );
}
