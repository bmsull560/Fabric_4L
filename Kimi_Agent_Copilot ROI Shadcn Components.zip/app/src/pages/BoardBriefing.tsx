import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Target,
  CheckCircle,
  TrendingUp,
  Shield,
  Scale,
  Zap,
  Headset,
  Users,
  DollarSign,
  Clock,
  Gavel,
  ChevronDown,
  ChevronUp,
  Presentation,
  Star,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts';
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from '@/components/ui/accordion';
import KpiCard from '@/components/KpiCard';
import DataCard from '@/components/DataCard';
import NumberAnimation from '@/components/NumberAnimation';

const cardEasing = [0.22, 1, 0.36, 1] as [number, number, number, number];

/* ──────────────────────── DATA ──────────────────────── */

const strategicRationale = [
  {
    icon: Target,
    title: 'Competitive Imperative',
    text: 'Peer utilities are deploying AI productivity tools. Failure to adopt creates competitive disadvantage in operational efficiency and customer service.',
    reference: 'Industry Adoption Benchmarks',
    color: '#D4A853',
  },
  {
    icon: CheckCircle,
    title: 'Proven Technology',
    text: 'Microsoft 365 Copilot is a production-ready tool with demonstrated enterprise ROI across 10,000+ organizations.',
    reference: 'Microsoft Customer Evidence',
    color: '#4ADE80',
  },
  {
    icon: TrendingUp,
    title: 'Financially Compelling',
    text: 'Conservative ROI of 2,500% with 100% probability of positive return. Payback in under 6 months.',
    reference: 'Financial Model, Monte Carlo Simulation',
    color: '#A78BFA',
  },
  {
    icon: Shield,
    title: 'Risk-Managed',
    text: 'Phased deployment with contraction options limits downside. No stranded cost risk.',
    reference: 'Real Options Analysis, Risk Assessment',
    color: '#60A5FA',
  },
  {
    icon: Scale,
    title: 'Regulator-Safe',
    text: 'Investment meets prudence standard with documented ratepayer benefit of $12.4M annually.',
    reference: 'Regulatory Justification',
    color: '#F472B6',
  },
];

const operationalImpactCards = [
  { title: 'Field Operations', metric: '18% truck roll reduction', value: '$8.4M annual savings', icon: Zap, color: '#D4A853' },
  { title: 'Customer Service', metric: '31% AHT reduction', value: '$4.8M annual savings', icon: Headset, color: '#4ADE80' },
  { title: 'Energy Trading', metric: '23% margin improvement', value: '$6.2M annual value', icon: TrendingUp, color: '#60A5FA' },
  { title: 'IT/Cybersecurity', metric: '42% incident response acceleration', value: '$2.7M annual value', icon: Shield, color: '#A78BFA' },
];

const boardPrioritiesTable = [
  { priority: 'Operational Excellence', contribution: '$22.1M efficiency gains', impact: 'High', status: 'Aligned' as const },
  { priority: 'Customer Satisfaction', contribution: '31% service improvement', impact: 'High', status: 'Aligned' as const },
  { priority: 'Regulatory Compliance', contribution: 'Automated reporting', impact: 'Medium', status: 'Aligned' as const },
  { priority: 'Financial Discipline', contribution: '2,742% ROI, 5-month payback', impact: 'High', status: 'Aligned' as const },
  { priority: 'Workforce Development', contribution: 'AI literacy, productivity', impact: 'Medium', status: 'Aligned' as const },
  { priority: 'Risk Management', contribution: 'Contraction options', impact: 'High', status: 'Aligned' as const },
  { priority: 'Technology Leadership', contribution: 'AI-native enterprise', impact: 'High', status: 'Aligned' as const },
];

const miniRoiBarData = [
  { name: 'Conservative', value: 2500 },
  { name: 'Base Case', value: 2742 },
  { name: 'High Case', value: 3200 },
];

const miniNpvs = [
  { month: 'M3', value: 15 },
  { month: 'M6', value: 42 },
  { month: 'M9', value: 78 },
  { month: 'M12', value: 120 },
  { month: 'M15', value: 135 },
  { month: 'M18', value: 150 },
  { month: 'M24', value: 165 },
  { month: 'M30', value: 170 },
  { month: 'M36', value: 171 },
];

const accordionSections = [
  {
    title: 'Deployment Phasing',
    content: [
      'Phase 1 (Q1): 2,000 IT workers + 500 executives',
      'Phase 2 (Q2): +2,000 corporate knowledge workers',
      'Phase 3 (Q3-Q4): +1,500 field + customer service',
    ],
  },
  {
    title: 'Investment Timeline',
    content: [
      'Year 1: $2.88M (licensing) + $180K (training) + $120K (change)',
      'Year 2: $2.88M (licensing) + $120K (change)',
      'Year 3: $2.88M (licensing) + $120K (change)',
    ],
  },
  {
    title: 'Success Metrics',
    content: [
      'Adoption rate > 70% by Month 12',
      'Productivity hours > 8 per user per month',
      'Operational savings > $15M in Year 1',
      'Employee satisfaction score > 4.0/5',
    ],
  },
  {
    title: 'Risk Factors',
    content: [
      'Adoption variability: Medium risk, mitigated by change management',
      'Data governance: Low risk, Microsoft 365 compliance built-in',
      'Workforce resistance: Medium risk, mitigated by champion network',
    ],
  },
  {
    title: 'Next Steps',
    content: [
      'Week 1: Board approval',
      'Week 2: Microsoft EA amendment',
      'Week 3: Pilot group identification',
      'Week 4: Training schedule publication',
      'Month 2: Pilot launch',
    ],
  },
];

/* ──────────────────────── BADGE ──────────────────────── */

function ImpactBadge({ level }: { level: 'High' | 'Medium' | 'Low' }) {
  const cls =
    level === 'High'
      ? 'text-accent-secondary bg-accent-secondary-muted'
      : level === 'Medium'
        ? 'text-accent-primary bg-accent-primary-muted'
        : 'text-text-tertiary bg-bg-tertiary';
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-md text-label-sm ${cls}`}>
      {level}
    </span>
  );
}

function StatusBadge({ status }: { status: 'Aligned' | 'Pending' | 'At Risk' }) {
  const cls =
    status === 'Aligned'
      ? 'text-accent-secondary bg-accent-secondary-muted'
      : status === 'Pending'
        ? 'text-accent-primary bg-accent-primary-muted'
        : 'text-accent-tertiary bg-accent-tertiary-muted';
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-md text-label-sm ${cls}`}>
      {status}
    </span>
  );
}

/* ──────────────────────── TOOLTIP ──────────────────────── */

function MiniTooltip({ active, payload, label }: any) {
  if (!active || !payload) return null;
  return (
    <div className="bg-bg-secondary border border-bg-quaternary rounded-md p-2 shadow-lg">
      <p className="text-body-sm text-text-primary">{label}</p>
      <p className="text-mono-sm text-accent-primary">{payload[0]?.value}% ROI</p>
    </div>
  );
}

/* ═══════════════════════════ PAGE ═══════════════════════════ */

export default function BoardBriefing() {
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleButton = (type: string) => {
    setFeedback(
      type === 'APPROVE'
        ? 'Approval registered for recommendation to deploy Microsoft 365 Copilot.'
        : type === 'DEFER'
          ? 'Deferral noted. Additional analysis will be prepared for the next board meeting.'
          : 'Request for additional analysis forwarded to management team.'
    );
    setTimeout(() => setFeedback(null), 4000);
  };

  return (
    <div>
      {/* ── Page Header ── */}
      <div className="px-8 py-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: cardEasing }}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-3">
              <Presentation className="w-5 h-5 text-accent-primary" />
              <span className="text-label-lg text-text-tertiary">BOARD BRIEFING</span>
            </div>
            <span className="px-3 py-1 bg-accent-tertiary-muted text-accent-tertiary rounded-md text-label-sm border border-accent-tertiary/30">
              CONFIDENTIAL — BOARD ONLY
            </span>
          </div>
          <h1 className="text-display-xl text-text-primary font-bold tracking-tight">
            Board Executive Summary
          </h1>
          <p className="text-body-lg text-text-secondary mt-2 max-w-3xl">
            Microsoft 365 Copilot Enterprise Deployment — Decision Briefing
          </p>
          <p className="text-body-sm text-text-tertiary mt-1">Prepared for Board of Directors</p>
        </motion.div>
      </div>

      {/* ── Decision Frame ── */}
      <div className="px-8 pb-6">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1, ease: cardEasing }}
          className="bg-accent-primary-muted border border-accent-primary/40 rounded-card p-6"
        >
          <div className="flex items-start gap-4">
            <Gavel className="w-6 h-6 text-accent-primary flex-shrink-0 mt-1" />
            <div>
              <h2 className="text-heading-lg text-accent-primary mb-2">Decision Frame</h2>
              <p className="text-body-lg text-text-primary leading-relaxed">
                The Board is asked to approve a{' '}
                <span className="text-mono-md text-accent-primary font-medium">$2.88M</span>{' '}
                annual investment in Microsoft 365 Copilot for{' '}
                <span className="text-mono-md text-accent-primary font-medium">6,000 employees</span>,
                with an expected 3-year NPV of{' '}
                <span className="text-mono-md text-accent-secondary font-medium">$171M</span>{' '}
                and a base-case ROI of{' '}
                <span className="text-mono-md text-accent-primary font-medium">2,742%</span>.
              </p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* ── KPI Strip ── */}
      <div className="px-8 pb-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5">
        <KpiCard
          icon={DollarSign}
          label="Total Annual Benefit"
          value={72.05}
          valuePrefix="$"
          valueSuffix="M"
          valueDecimals={1}
          subtitle="Midpoint of $66.6M-$77.5M range"
          trend={{ direction: 'positive', text: 'Range: $66.6M-$77.5M' }}
          index={0}
        />
        <KpiCard
          icon={DollarSign}
          label="Annual Cost"
          value={2.56}
          valuePrefix="$"
          valueSuffix="M"
          valueDecimals={2}
          subtitle="Licensing + training + change mgmt"
          trend={{ direction: 'negative', text: 'Fixed cost' }}
          index={1}
        />
        <KpiCard
          icon={TrendingUp}
          label="Net Benefit"
          value={69.5}
          valuePrefix="$"
          valueSuffix="M"
          valueDecimals={1}
          subtitle="Midpoint of $64M-$75M range"
          trend={{ direction: 'positive', text: 'High confidence' }}
          index={2}
        />
        <KpiCard
          icon={Star}
          label="ROI"
          value={2742}
          valueSuffix="%"
          subtitle="Monte Carlo mean"
          trend={{ direction: 'positive', text: 'Range: 2,500%-2,900%' }}
          index={3}
        />
        <KpiCard
          icon={Clock}
          label="Payback Period"
          value={5}
          valueSuffix=" months"
          subtitle="Midpoint of 4-6 months"
          trend={{ direction: 'positive', text: 'Under 6 months' }}
          index={4}
        />
      </div>

      <div className="px-8 pb-8 space-y-5">
        {/* ── Strategic Rationale ── */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2, ease: cardEasing }}
          className="bg-bg-secondary border border-bg-quaternary rounded-card p-6"
        >
          <h2 className="text-heading-lg text-text-primary mb-6">Strategic Rationale</h2>
          <div className="space-y-4">
            {strategicRationale.map((item, i) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.4, delay: 0.1 * i, ease: cardEasing }}
                  className="flex items-start gap-4 bg-bg-primary border border-bg-quaternary rounded-card p-4 hover:border-bg-quaternary/80 transition-all duration-300"
                >
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: `${item.color}20` }}
                  >
                    <Icon className="w-5 h-5" style={{ color: item.color }} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-mono-sm" style={{ color: item.color }}>
                        0{i + 1}
                      </span>
                      <h3 className="text-heading-md text-text-primary">{item.title}</h3>
                    </div>
                    <p className="text-body-md text-text-secondary">{item.text}</p>
                    <p className="text-body-sm text-text-tertiary mt-1">
                      See: {item.reference}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* ── Financial Impact + Monte Carlo ── */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Mini NPV Chart */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3, ease: cardEasing }}
          >
            <DataCard title="3-Year NPV" subtitle="$171M at 8% discount rate">
              <div className="h-32 mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={miniNpvs}>
                    <defs>
                      <linearGradient id="npvGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#D4A853" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#D4A853" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.08)" />
                    <XAxis dataKey="month" tick={{ fill: '#64748B', fontSize: 10 }} axisLine={false} tickLine={false} />
                    <YAxis hide />
                    <Area
                      type="monotone"
                      dataKey="value"
                      stroke="#D4A853"
                      strokeWidth={2}
                      fill="url(#npvGrad)"
                      animationBegin={300}
                      animationDuration={1000}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-2 text-center">
                <span className="text-mono-lg text-accent-primary">$171M</span>
                <p className="text-body-sm text-text-tertiary">3-year cumulative NPV</p>
              </div>
            </DataCard>
          </motion.div>

          {/* Mini ROI Bar */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.35, ease: cardEasing }}
          >
            <DataCard title="ROI (Conservative)" subtitle="Base case: 2,742%">
              <div className="h-32 mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={miniRoiBarData} barCategoryGap="30%">
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.08)" />
                    <XAxis dataKey="name" tick={{ fill: '#64748B', fontSize: 10 }} axisLine={false} tickLine={false} />
                    <YAxis hide />
                    <Tooltip content={<MiniTooltip />} />
                    <Bar dataKey="value" fill="#D4A853" radius={[4, 4, 0, 0]} animationBegin={400} animationDuration={800}>
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-2 text-center">
                <span className="text-mono-lg text-accent-primary">2,500%</span>
                <p className="text-body-sm text-text-tertiary">Conservative case</p>
              </div>
            </DataCard>
          </motion.div>

          {/* Payback Mini Card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4, ease: cardEasing }}
          >
            <DataCard title="Payback Period" subtitle="Conservative: 7 months">
              <div className="flex flex-col items-center justify-center py-4">
                <div className="relative w-28 h-28">
                  <svg className="w-28 h-28 -rotate-90" viewBox="0 0 112 112">
                    <circle cx="56" cy="56" r="46" fill="none" stroke="#232D42" strokeWidth="8" />
                    <motion.circle
                      cx="56"
                      cy="56"
                      r="46"
                      fill="none"
                      stroke="#4ADE80"
                      strokeWidth="8"
                      strokeLinecap="round"
                      strokeDasharray={289.38}
                      initial={{ strokeDashoffset: 289.38 }}
                      animate={{ strokeDashoffset: 289.38 - (5.2 / 12) * 289.38 }}
                      transition={{ duration: 1.2, ease: cardEasing, delay: 0.5 }}
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-mono-md text-accent-secondary">5.2</span>
                    <span className="text-body-sm text-text-tertiary">months</span>
                  </div>
                </div>
                <p className="text-body-sm text-text-secondary mt-3">5.2 out of 12 months</p>
              </div>
            </DataCard>
          </motion.div>
        </div>

        {/* ── Monte Carlo Risk Analysis ── */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.45, ease: cardEasing }}
          className="bg-bg-secondary border border-bg-quaternary rounded-card p-6"
        >
          <div className="flex items-center gap-3 mb-4">
            <Target className="w-5 h-5 text-accent-primary" />
            <h2 className="text-heading-lg text-text-primary">Risk Analysis — Monte Carlo Results</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              {[
                { label: 'Simulation iterations', value: '10,000', color: 'text-text-primary' },
                { label: 'Mean ROI', value: '2,742%', color: 'text-accent-primary' },
                { label: 'Probability of positive ROI', value: '100%', color: 'text-accent-secondary' },
                { label: 'Probability of ROI > 1,000%', value: '94.2%', color: 'text-accent-secondary' },
                { label: 'Worst case (1st percentile)', value: '1,187% ROI', color: 'text-accent-primary' },
              ].map((item, i) => (
                <motion.div
                  key={item.label}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 + i * 0.06 }}
                  className="flex items-center justify-between px-4 py-2.5 bg-bg-primary rounded-lg border border-bg-quaternary"
                >
                  <span className="text-body-md text-text-secondary">{item.label}</span>
                  <span className={`text-mono-sm font-semibold ${item.color}`}>{item.value}</span>
                </motion.div>
              ))}
              <div className="mt-3 inline-flex items-center gap-2 px-3 py-1.5 bg-accent-secondary-muted text-accent-secondary rounded-md text-label-sm">
                <CheckCircle className="w-3.5 h-3.5" />
                All stress tests passed
              </div>
            </div>

            {/* Mini histogram */}
            <div className="flex flex-col justify-center">
              <p className="text-label-sm text-text-tertiary mb-3 text-center">ROI DISTRIBUTION</p>
              <div className="flex items-end justify-center gap-1 h-28">
                {[5, 8, 12, 18, 28, 42, 58, 72, 85, 92, 96, 88, 75, 58, 42, 30, 20, 14, 10, 7].map((h, i) => (
                  <motion.div
                    key={i}
                    initial={{ height: 0 }}
                    animate={{ height: `${h}%` }}
                    transition={{ duration: 0.6, delay: 0.3 + i * 0.03, ease: cardEasing }}
                    className="w-3 rounded-t"
                    style={{
                      backgroundColor:
                        i < 3 ? '#F87171' : i < 7 ? '#D4A853' : '#4ADE80',
                    }}
                  />
                ))}
              </div>
              <div className="flex justify-between text-body-sm text-text-tertiary mt-2">
                <span>1,000%</span>
                <span>2,000%</span>
                <span>3,000%</span>
                <span>4,000%+</span>
              </div>
            </div>
          </div>
        </motion.div>

        {/* ── Operational Impact ── */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5, ease: cardEasing }}
        >
          <DataCard title="Operational Impact Summary" subtitle="Key operational improvements by function">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
              {operationalImpactCards.map((card, i) => {
                const Icon = card.icon;
                return (
                  <motion.div
                    key={card.title}
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.55 + i * 0.08, ease: cardEasing }}
                    className="bg-bg-primary border border-bg-quaternary rounded-card p-4 hover:border-bg-quaternary/80 transition-all duration-300"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <div
                        className="w-8 h-8 rounded-full flex items-center justify-center"
                        style={{ backgroundColor: `${card.color}20` }}
                      >
                        <Icon className="w-4 h-4" style={{ color: card.color }} />
                      </div>
                      <h3 className="text-heading-md text-text-primary">{card.title}</h3>
                    </div>
                    <p className="text-body-md text-accent-secondary font-medium">{card.metric}</p>
                    <p className="text-mono-sm text-text-primary mt-1">{card.value}</p>
                  </motion.div>
                );
              })}
            </div>
          </DataCard>
        </motion.div>

        {/* ── Workforce Continuity ── */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.55, ease: cardEasing }}
        >
          <DataCard title="Workforce Impact" subtitle="Employee empowerment and change management">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
              {[
                { label: 'Employees Empowered', value: '6,000', sub: 'With AI assistance', icon: Users },
                { label: 'Avg Time Savings', value: '10.3 hrs', sub: 'Per employee per month', icon: Clock },
                { label: 'No Headcount Reduction', value: 'Reinvest', sub: 'Reinvestment in growth', icon: CheckCircle },
                { label: 'Training Investment', value: '$180K', sub: 'One-time + $120K annual', icon: DollarSign },
                { label: 'Change Management', value: 'Phased', sub: 'Full support provided', icon: Shield },
                { label: 'Adoption Target', value: '>70%', sub: 'By Month 12', icon: Target },
              ].map((item, i) => {
                const Icon = item.icon;
                return (
                  <motion.div
                    key={item.label}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.6 + i * 0.06 }}
                    className="flex items-center gap-3 bg-bg-primary border border-bg-quaternary rounded-lg p-3"
                  >
                    <div className="w-9 h-9 rounded-full bg-accent-primary-muted flex items-center justify-center flex-shrink-0">
                      <Icon className="w-4 h-4 text-accent-primary" />
                    </div>
                    <div>
                      <span className="text-label-sm text-text-tertiary">{item.label}</span>
                      <p className="text-mono-sm text-text-primary font-medium">{item.value}</p>
                      <p className="text-body-sm text-text-tertiary">{item.sub}</p>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </DataCard>
        </motion.div>

        {/* ── Board Priorities Alignment ── */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6, ease: cardEasing }}
        >
          <DataCard title="Alignment with Board Strategic Priorities" subtitle="Mapping board priorities to Copilot impact">
            <div className="overflow-x-auto mt-4">
              <table className="w-full">
                <thead>
                  <tr className="bg-bg-tertiary">
                    <th className="text-label-sm text-text-tertiary text-left px-4 py-3">Board Priority</th>
                    <th className="text-label-sm text-text-tertiary text-left px-4 py-3">Copilot Contribution</th>
                    <th className="text-label-sm text-text-tertiary text-center px-4 py-3">Impact</th>
                    <th className="text-label-sm text-text-tertiary text-center px-4 py-3">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {boardPrioritiesTable.map((row, i) => (
                    <motion.tr
                      key={row.priority}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.65 + i * 0.06 }}
                      className="border-b border-bg-quaternary hover:bg-bg-tertiary/30 transition-colors"
                    >
                      <td className="px-4 py-3 text-body-md text-text-primary font-medium">
                        {row.priority}
                      </td>
                      <td className="px-4 py-3 text-body-sm text-text-secondary">
                        {row.contribution}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <ImpactBadge level={row.impact as 'High' | 'Medium' | 'Low'} />
                      </td>
                      <td className="px-4 py-3 text-center">
                        <StatusBadge status={row.status} />
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </DataCard>
        </motion.div>

        {/* ── Board Recommendation ── */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.65, ease: cardEasing }}
        >
          <DataCard
            title="Board Recommendation"
            subtitle="Management recommendation with conditions"
          >
            <div className="bg-accent-primary-muted border border-accent-primary/30 rounded-lg p-5 mt-4">
              <p className="text-body-lg text-text-primary leading-relaxed mb-4">
                Management recommends the Board approve the deployment of Microsoft 365 Copilot to
                6,000 employees beginning Q1 2025, with the following conditions:
              </p>
              <ol className="space-y-3 mb-6">
                {[
                  { label: 'Phased deployment', text: '2,000 users in Q1, scaling to 6,000 by Q4' },
                  { label: 'Quarterly review', text: 'Board review of adoption metrics and ROI realization at each quarterly meeting' },
                  { label: 'Contraction option', text: 'Management retains authority to reduce deployment if adoption falls below 50% at Month 12' },
                  { label: 'Regulatory pre-filing', text: 'Consult with PUC counsel before public filing' },
                  { label: 'Independent verification', text: 'Engage third party to validate Year 1 ROI claims' },
                ].map((item, i) => (
                  <motion.li
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.7 + i * 0.08 }}
                    className="flex items-start gap-3 text-body-md text-text-secondary"
                  >
                    <span className="w-6 h-6 rounded-full bg-accent-primary/20 text-accent-primary flex items-center justify-center text-body-sm font-medium flex-shrink-0 mt-0.5">
                      {i + 1}
                    </span>
                    <div>
                      <span className="text-text-primary font-medium">{item.label}:</span>{' '}
                      {item.text}
                    </div>
                  </motion.li>
                ))}
              </ol>

              {/* CTA Row */}
              <div className="flex flex-wrap items-center gap-3 border-t border-accent-primary/20 pt-5">
                <motion.button
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1.0 }}
                  onClick={() => handleButton('APPROVE')}
                  className="px-6 py-2.5 bg-accent-primary text-text-inverse font-medium rounded-button hover:bg-accent-primary-hover hover:shadow-[0_4px_16px_rgba(212,168,83,0.3)] active:scale-[0.98] transition-all duration-200"
                >
                  APPROVE
                </motion.button>
                <motion.button
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1.1 }}
                  onClick={() => handleButton('DEFER')}
                  className="px-6 py-2.5 bg-bg-tertiary text-text-primary font-medium rounded-button border border-bg-quaternary hover:border-accent-primary/40 hover:bg-bg-quaternary transition-all duration-200"
                >
                  DEFER
                </motion.button>
                <motion.button
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1.2 }}
                  onClick={() => handleButton('ANALYSIS')}
                  className="px-6 py-2.5 text-text-secondary font-medium rounded-button hover:text-text-primary hover:bg-bg-tertiary transition-all duration-200"
                >
                  REQUEST ADDITIONAL ANALYSIS
                </motion.button>
              </div>

              {/* Feedback */}
              <AnimatePresence>
                {feedback && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.3 }}
                    className="mt-4 overflow-hidden"
                  >
                    <div className="bg-accent-secondary-muted border border-accent-secondary/30 rounded-lg p-3 text-body-md text-accent-secondary text-center">
                      {feedback}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </DataCard>
        </motion.div>

        {/* ── Detailed Decision Framing (Accordion) ── */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.7, ease: cardEasing }}
        >
          <DataCard title="Detailed Decision Framing" subtitle="Expandable sections for board members wanting detail">
            <Accordion type="multiple" className="mt-4 space-y-2">
              {accordionSections.map((section, i) => (
                <AccordionItem
                  key={section.title}
                  value={`item-${i}`}
                  className="border border-bg-quaternary rounded-lg bg-bg-primary overflow-hidden data-[state=open]:border-bg-quaternary/80"
                >
                  <AccordionTrigger className="px-4 py-3 text-heading-md text-text-primary hover:no-underline hover:bg-bg-tertiary/30 transition-colors">
                    {section.title}
                  </AccordionTrigger>
                  <AccordionContent className="px-4 pb-4">
                    <ul className="space-y-2">
                      {section.content.map((line, j) => (
                        <li key={j} className="flex items-start gap-2 text-body-md text-text-secondary">
                          <span className="w-1 h-1 rounded-full bg-accent-primary mt-2 flex-shrink-0" />
                          {line}
                        </li>
                      ))}
                    </ul>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </DataCard>
        </motion.div>
      </div>
    </div>
  );
}
