import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, LineChart, Line, ReferenceLine, BarChart, Bar,
} from 'recharts';
import {
  ArrowUpRight, DollarSign, TrendingUp, Activity,
  Zap, Users, Target, ChevronDown,
} from 'lucide-react';
import KpiCard from '../components/KpiCard';
import DataCard from '../components/DataCard';
import NumberAnimation from '../components/NumberAnimation';

/* ------------------------------------------------------------------ */
/*  TYPES                                                              */
/* ------------------------------------------------------------------ */
interface MonthlyData {
  month: number;
  monthLabel: string;
  linearBenefit: number;
  expBenefit: number;
  cumLinear: number;
  cumExp: number;
  roiLinear: number;
  roiExp: number;
  npvCumLinear: number;
  npvCumExp: number;
  users: number;
  maturityLevel: number;
}

/* ------------------------------------------------------------------ */
/*  ANIMATION EASING                                                   */
/* ------------------------------------------------------------------ */
const cardEase = [0.22, 1, 0.36, 1] as [number, number, number, number];

/* ------------------------------------------------------------------ */
/*  DATA GENERATION — 60 months (Jan 2025 → Dec 2029)                  */
/* ------------------------------------------------------------------ */
const MONTH_NAMES = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

function monthLabel(m: number): string {
  const year = 2025 + Math.floor((m - 1) / 12);
  const mo = (m - 1) % 12;
  return `${MONTH_NAMES[mo]} ${year}`;
}

// S-curve adoption: logistic function N(t) = K / (1 + e^(-r(t-t0)))
function scurveUsers(t: number): number {
  const K = 10000;
  const r = 0.15;
  const t0 = 18;
  return Math.round(K / (1 + Math.exp(-r * (t - t0))));
}

// Monthly cost = $0.21M
const MONTHLY_COST = 0.21;

function generateExponentialData(): MonthlyData[] {
  const data: MonthlyData[] = [];
  let cumLinear = 0;
  let cumExp = 0;
  let cumCost = 0;
  let pvLinear = 0;
  let pvExp = 0;

  // Exponential growth rate: 4% per month (compound)
  const EXP_RATE = 0.04;
  const DISCOUNT_10 = 0.10;

  for (let m = 1; m <= 60; m++) {
    const users = scurveUsers(m);
    // Linear benefit: $6.0M steady after ramp-up
    const linearBenefit = m <= 2 ? 0 : m <= 7 ? [0, 0, 1.2, 2.1, 3.0, 3.9, 4.8][m - 1] : 6.0;

    // Exponential: starts at $6.0M at month 8, grows 4% monthly
    let expBenefit: number;
    if (m <= 2) expBenefit = 0;
    else if (m === 3) expBenefit = 1.2;
    else if (m === 4) expBenefit = 2.1;
    else if (m === 5) expBenefit = 3.0;
    else if (m === 6) expBenefit = 3.9;
    else if (m === 7) expBenefit = 4.8;
    else {
      // Month 8 = $6.0M, then compound 4%
      expBenefit = 6.0 * Math.pow(1 + EXP_RATE, m - 8);
    }

    cumLinear += linearBenefit;
    cumExp += expBenefit;
    cumCost += MONTHLY_COST;

    const roiLinear = cumCost > 0 ? ((cumLinear - cumCost) / cumCost) * 100 : 0;
    const roiExp = cumCost > 0 ? ((cumExp - cumCost) / cumCost) * 100 : 0;

    // NPV at 10%
    const df = 1 / Math.pow(1 + DISCOUNT_10 / 12, m);
    pvLinear += (linearBenefit - MONTHLY_COST) * df;
    pvExp += (expBenefit - MONTHLY_COST) * df;

    // Maturity level mapping
    let maturityLevel = 1;
    if (m >= 12) maturityLevel = 2;
    if (m >= 18) maturityLevel = 3;
    if (m >= 24) maturityLevel = 4;
    if (m >= 30) maturityLevel = 5;
    if (m >= 36) maturityLevel = 6;
    if (m >= 42) maturityLevel = 7;
    if (m >= 48) maturityLevel = 8;
    if (m >= 54) maturityLevel = 9;
    if (m >= 60) maturityLevel = 10;

    data.push({
      month: m,
      monthLabel: monthLabel(m),
      linearBenefit,
      expBenefit,
      cumLinear,
      cumExp,
      roiLinear,
      roiExp,
      npvCumLinear: pvLinear,
      npvCumExp: pvExp,
      users,
      maturityLevel,
    });
  }
  return data;
}

const expData = generateExponentialData();

/* ------------------------------------------------------------------ */
/*  SELECTED MONTHS TABLE DATA                                         */
/* ------------------------------------------------------------------ */
const selectedMonths = [6, 12, 18, 24, 30, 36, 42, 48, 54, 60];
const benefitTableData = selectedMonths.map(m => {
  const d = expData[m - 1];
  return {
    month: d.monthLabel,
    linearBenefit: d.linearBenefit,
    expBenefit: d.expBenefit,
    multiplier: d.expBenefit / d.linearBenefit,
    cumLinear: d.cumLinear,
    cumExp: d.cumExp,
    users: d.users,
    maturityLevel: d.maturityLevel,
  };
});

/* ------------------------------------------------------------------ */
/*  S-CURVE PHASE DATA                                                 */
/* ------------------------------------------------------------------ */
const scurvePhases = [
  { phase: 'Early Adoption', months: '1–12', users: '0→4,200', rate: 'Slow', narrative: 'Champions prove value' },
  { phase: 'Acceleration', months: '13–30', users: '4,200→8,500', rate: 'Fast', narrative: 'Peer effects drive adoption' },
  { phase: 'Expansion', months: '31–60', users: '8,500→10,000', rate: 'Slowing', narrative: 'New use cases expand ceiling' },
];

/* ------------------------------------------------------------------ */
/*  YEARLY S-CURVE DATA                                                */
/* ------------------------------------------------------------------ */
const yearlyScurve = [
  { year: '2025', users: 6000, maxPotential: 6000 },
  { year: '2026', users: 7100, maxPotential: 7500 },
  { year: '2027', users: 8400, maxPotential: 8800 },
  { year: '2028', users: 9900, maxPotential: 10200 },
  { year: '2029', users: 11700, maxPotential: 12000 },
  { year: '2030', users: 13800, maxPotential: 13800 },
];

/* ------------------------------------------------------------------ */
/*  ROADMAP MILESTONES                                                 */
/* ------------------------------------------------------------------ */
const roadmapMilestones = [
  { year: '2025', milestone: 'Copilot Deployment', capability: 'Level 1-2: Initiation → Adoption', color: '#60A5FA' },
  { year: '2026', milestone: 'Workflow Integration', capability: 'Level 3: Integration', color: '#60A5FA' },
  { year: '2027', milestone: 'Agent Orchestration', capability: 'Level 4: Orchestration', color: '#D4A853' },
  { year: '2028', milestone: 'Autonomous Operations', capability: 'Level 5-6: Acceleration → Expansion', color: '#4ADE80' },
  { year: '2030', milestone: 'AI-Native Enterprise', capability: 'Level 7: Autonomy', color: '#A78BFA' },
];

/* ------------------------------------------------------------------ */
/*  CUSTOM TOOLTIPS                                                    */
/* ------------------------------------------------------------------ */
const ExpTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-bg-secondary border border-bg-quaternary rounded-lg px-3 py-2 shadow-[0_4px_20px_rgba(0,0,0,0.3)]">
      <p className="text-body-sm text-text-primary font-medium mb-1">{label}</p>
      {payload.map((p: any, i: number) => (
        <p key={i} className="text-body-sm" style={{ color: p.color }}>
          {p.name}: {p.value >= 1000 ? `$${(p.value / 1000).toFixed(1)}B` : `$${p.value.toFixed(1)}M`}
        </p>
      ))}
    </div>
  );
};

const SCurveTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-bg-secondary border border-bg-quaternary rounded-lg px-3 py-2 shadow-[0_4px_20px_rgba(0,0,0,0.3)]">
      <p className="text-body-sm text-text-primary font-medium">Month {label}</p>
      {payload.map((p: any, i: number) => (
        <p key={i} className="text-body-sm" style={{ color: p.color }}>
          {p.name}: {p.value?.toLocaleString?.()} {p.name === 'Users' ? 'users' : p.name === 'Maturity' ? '' : `$${p.value}M`}
        </p>
      ))}
    </div>
  );
};

/* ------------------------------------------------------------------ */
/*  TAB CONTENT COMPONENTS                                             */
/* ------------------------------------------------------------------ */
function TabRoiTrajectory() {
  return (
    <div className="h-[380px]">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={expData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" />
          <XAxis dataKey="monthLabel" tick={{ fill: '#64748B', fontSize: 10 }} axisLine={{ stroke: 'rgba(148,163,184,0.3)' }} interval={5} />
          <YAxis tick={{ fill: '#64748B', fontSize: 11 }} axisLine={{ stroke: 'rgba(148,163,184,0.3)' }} />
          <Tooltip content={<ExpTooltip />} />
          <Line type="monotone" dataKey="roiLinear" name="Linear ROI %" stroke="#64748B" strokeWidth={1.5} strokeDasharray="6 4" dot={false} />
          <Line type="monotone" dataKey="roiExp" name="Exponential ROI %" stroke="#D4A853" strokeWidth={2.5} dot={false} />
          <ReferenceLine y={10000} stroke="#4ADE80" strokeDasharray="3 3" label={{ value: '10,000%', fill: '#4ADE80', fontSize: 10 }} />
          <ReferenceLine y={14900} stroke="#D4A853" strokeDasharray="3 3" label={{ value: '14,900%', fill: '#D4A853', fontSize: 10 }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

function TabNpvDiscounted() {
  return (
    <div className="h-[380px]">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={expData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="npvGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#D4A853" stopOpacity={0.4} />
              <stop offset="95%" stopColor="#D4A853" stopOpacity={0.05} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" />
          <XAxis dataKey="monthLabel" tick={{ fill: '#64748B', fontSize: 10 }} axisLine={{ stroke: 'rgba(148,163,184,0.3)' }} interval={5} />
          <YAxis tick={{ fill: '#64748B', fontSize: 11 }} axisLine={{ stroke: 'rgba(148,163,184,0.3)' }} />
          <Tooltip content={<ExpTooltip />} />
          <Area type="monotone" dataKey="npvCumExp" name="Exponential NPV" stroke="#D4A853" strokeWidth={2} fill="url(#npvGrad)" />
          <Line type="monotone" dataKey="npvCumLinear" name="Linear NPV" stroke="#64748B" strokeWidth={1.5} strokeDasharray="6 4" dot={false} />
          <ReferenceLine y={487} stroke="#4ADE80" strokeDasharray="3 3" label={{ value: '5yr NPV $487M', fill: '#4ADE80', fontSize: 10 }} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

function TabRealOptions() {
  // Simulate option values growing over time
  const optionData = expData.map(d => {
    const expand = d.cumExp * 0.08;
    const contract = d.cumExp * 0.03;
    const defer = d.cumExp * 0.02;
    const stage = d.cumExp * 0.04;
    return {
      ...d,
      expand,
      contract,
      defer,
      stage,
      total: expand + contract + defer + stage,
    };
  });

  return (
    <div className="h-[380px]">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={optionData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" />
          <XAxis dataKey="monthLabel" tick={{ fill: '#64748B', fontSize: 10 }} axisLine={{ stroke: 'rgba(148,163,184,0.3)' }} interval={5} />
          <YAxis tick={{ fill: '#64748B', fontSize: 11 }} axisLine={{ stroke: 'rgba(148,163,184,0.3)' }} />
          <Tooltip content={<ExpTooltip />} />
          <Area type="monotone" dataKey="expand" name="Expand" stackId="opts" stroke="#D4A853" fill="rgba(212,168,83,0.3)" />
          <Area type="monotone" dataKey="stage" name="Stage" stackId="opts" stroke="#4ADE80" fill="rgba(74,222,128,0.25)" />
          <Area type="monotone" dataKey="contract" name="Contract" stackId="opts" stroke="#60A5FA" fill="rgba(96,165,250,0.2)" />
          <Area type="monotone" dataKey="defer" name="Defer" stackId="opts" stroke="#A78BFA" fill="rgba(167,139,250,0.2)" />
          <ReferenceLine y={512} stroke="#D4A853" strokeDasharray="3 3" label={{ value: 'Total $512M', fill: '#D4A853', fontSize: 10 }} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  EXPANDABLE SECTION                                                 */
/* ------------------------------------------------------------------ */
function ExpandableSection({ title, children, defaultOpen = false }: { title: string; children: React.ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border border-bg-quaternary rounded-lg overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between px-4 py-3 bg-bg-tertiary hover:bg-bg-quaternary transition-colors"
      >
        <span className="text-body-md text-text-primary font-medium">{title}</span>
        <ChevronDown className={`w-4 h-4 text-text-secondary transition-transform duration-200 ${open ? 'rotate-180' : ''}`} />
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: cardEase }}
            className="overflow-hidden"
          >
            <div className="p-4">{children}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  MAIN COMPONENT                                                     */
/* ------------------------------------------------------------------ */
export default function ExponentialModel() {
  const [activeTab, setActiveTab] = useState<'roi' | 'npv' | 'options'>('roi');

  // Final values
  const final = expData[expData.length - 1];
  const totalCost = 60 * MONTHLY_COST; // $12.6M
  const netBenefit = final.cumExp - totalCost;
  const fiveYearRoi = (netBenefit / totalCost) * 100;

  // Peak monthly benefit at month 60
  const peakMonthly = final.expBenefit;

  const tabs = [
    { key: 'roi' as const, label: 'ROI Trajectory' },
    { key: 'npv' as const, label: 'NPV Discounted' },
    { key: 'options' as const, label: 'Real Options' },
  ];

  return (
    <div className="px-8 py-6 space-y-6">
      {/* ====== HEADER ====== */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: cardEase }}
      >
        <div className="flex items-center gap-3 mb-1">
          <span className="text-label-lg text-text-tertiary tracking-wider">FINANCIAL MODELS</span>
          <span className="text-text-tertiary">/</span>
          <span className="text-label-lg text-accent-primary tracking-wider">5-YEAR EXPONENTIAL</span>
        </div>
        <h1 className="text-display-lg text-text-primary">5-Year Exponential Value Model</h1>
        <p className="text-body-lg text-text-secondary mt-2">
          From linear IT productivity to exponential intelligence multiplier
        </p>
        <div className="mt-4 bg-accent-info-muted rounded-lg p-4 border-l-2 border-accent-info">
          <p className="text-body-md text-text-secondary leading-relaxed">
            The linear productivity model understates long-term value. As Copilot evolves from a
            drafting assistant to an autonomous agent orchestrator, benefit growth shifts from linear
            to exponential — driven by compounding workflow integration, autonomous agent deployment,
            and organizational intelligence amplification.
          </p>
        </div>
      </motion.div>

      {/* ====== KPI CARDS ====== */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        <KpiCard
          icon={TrendingUp}
          label="5-Year ROI"
          value={fiveYearRoi}
          valueSuffix="%"
          valueDecimals={0}
          subtitle="Exponential growth scenario"
          index={0}
        />
        <KpiCard
          icon={DollarSign}
          label="5-Year NPV"
          value={487}
          valuePrefix="$"
          valueSuffix="M"
          valueDecimals={0}
          subtitle="10% discount rate"
          index={1}
        />
        <KpiCard
          icon={Activity}
          label="5-Year ROA"
          value={512}
          valuePrefix="$"
          valueSuffix="M"
          valueDecimals={0}
          subtitle="Real options with expansion"
          index={2}
        />
        <KpiCard
          icon={ArrowUpRight}
          label="Peak Monthly Benefit"
          value={peakMonthly}
          valuePrefix="$"
          valueSuffix="M"
          valueDecimals={1}
          subtitle={`Month 60, exponential phase`}
          index={3}
        />
      </div>

      {/* ====== COMBINED 3-TAB MODEL ====== */}
      <DataCard title="5-Year Combined Model — ROI + NPV + ROA" subtitle="Switch between analytical views">
        {/* Tab Navigation */}
        <div className="flex border-b border-bg-quaternary mb-4">
          {tabs.map(t => (
            <button
              key={t.key}
              onClick={() => setActiveTab(t.key)}
              className={`px-5 py-3 text-body-md font-medium transition-all duration-200 border-b-2 ${
                activeTab === t.key
                  ? 'text-text-primary border-accent-primary'
                  : 'text-text-secondary border-transparent hover:text-text-primary'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.25, ease: cardEase }}
          >
            {activeTab === 'roi' && <TabRoiTrajectory />}
            {activeTab === 'npv' && <TabNpvDiscounted />}
            {activeTab === 'options' && <TabRealOptions />}
          </motion.div>
        </AnimatePresence>

        {/* Summary stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
          {[
            { label: '5-Year Cum. Benefit', value: `$${(final.cumExp / 1000).toFixed(2)}B`, color: 'text-chart-1' },
            { label: 'Total Cost', value: `$${totalCost.toFixed(1)}M`, color: 'text-accent-tertiary' },
            { label: 'Net Benefit', value: `$${(netBenefit / 1000).toFixed(3)}B`, color: 'text-accent-secondary' },
            { label: 'Benefit/Cost', value: `${(final.cumExp / totalCost).toFixed(1)}x`, color: 'text-chart-1' },
          ].map(s => (
            <div key={s.label} className="bg-bg-tertiary rounded-lg p-3 text-center">
              <div className="text-label-sm text-text-tertiary">{s.label}</div>
              <div className={`text-mono-sm ${s.color} font-medium mt-0.5`}>{s.value}</div>
            </div>
          ))}
        </div>
      </DataCard>

      {/* ====== BENEFIT TABLE (Selected Months) ====== */}
      <DataCard title="Selected-Month Benefit Trajectory" subtitle="Linear vs. exponential comparison at key milestones">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-bg-tertiary">
                {['Month','Linear Benefit','Exp. Benefit','Multiplier','Cum. Linear','Cum. Exp.','Users','Maturity'].map(h => (
                  <th key={h} className="text-label-sm text-text-tertiary text-left px-3 py-3 font-medium tracking-wider">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {benefitTableData.map((row, i) => (
                <motion.tr
                  key={row.month}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.06, duration: 0.3, ease: cardEase }}
                  className={`border-b border-bg-quaternary ${i % 2 === 0 ? 'bg-bg-primary' : 'bg-bg-secondary'}`}
                  style={{ height: '48px' }}
                >
                  <td className="px-3 text-body-md text-text-primary font-medium">{row.month}</td>
                  <td className="px-3 text-mono-sm text-text-secondary text-right">${row.linearBenefit.toFixed(1)}M</td>
                  <td className="px-3 text-mono-sm text-accent-primary text-right font-medium">${row.expBenefit.toFixed(1)}M</td>
                  <td className="px-3 text-mono-sm text-accent-secondary text-right">{row.multiplier.toFixed(2)}x</td>
                  <td className="px-3 text-mono-sm text-text-secondary text-right">${row.cumLinear.toFixed(1)}M</td>
                  <td className="px-3 text-mono-sm text-accent-primary text-right font-medium">${row.cumExp.toFixed(1)}M</td>
                  <td className="px-3 text-mono-sm text-text-secondary text-right">{row.users.toLocaleString()}</td>
                  <td className="px-3 text-mono-sm text-accent-info text-right">Lv.{row.maturityLevel}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Dual-line chart */}
        <div className="h-[260px] mt-5">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={benefitTableData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="premiumGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#D4A853" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#D4A853" stopOpacity={0.05} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" />
              <XAxis dataKey="month" tick={{ fill: '#64748B', fontSize: 10 }} axisLine={{ stroke: 'rgba(148,163,184,0.3)' }} />
              <YAxis tick={{ fill: '#64748B', fontSize: 11 }} axisLine={{ stroke: 'rgba(148,163,184,0.3)' }} />
              <Tooltip content={<ExpTooltip />} />
              <Line type="monotone" dataKey="cumLinear" name="Cumulative Linear" stroke="#64748B" strokeWidth={2} strokeDasharray="6 4" dot={{ fill: '#64748B', r: 3 }} />
              <Area type="monotone" dataKey="cumExp" name="Cumulative Exponential" stroke="#D4A853" strokeWidth={2.5} fill="url(#premiumGrad)" dot={{ fill: '#D4A853', r: 3 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </DataCard>

      {/* ====== S-CURVE ADOPTION MODEL ====== */}
      <DataCard
        title="Copilot Exponential Adoption S-Curve"
        subtitle="Mathematical model of enterprise AI adoption"
      >
        {/* Formula callout */}
        <div className="bg-bg-tertiary rounded-lg p-4 mb-5 font-mono text-body-md text-text-secondary">
          <span className="text-accent-info">N(t)</span> ={' '}
          <span className="text-accent-primary">K</span> / (1 + e
          <sup className="text-accent-secondary">-r(t - t₀)</sup>) where{' '}
          <span className="text-accent-primary">K = 10,000</span>,{' '}
          <span className="text-accent-secondary">r = 0.15</span>,{' '}
          <span className="text-chart-1">t₀ = 18</span>
        </div>

        {/* S-Curve Chart */}
        <div className="h-[340px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={expData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="phase1" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#60A5FA" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#60A5FA" stopOpacity={0.05} />
                </linearGradient>
                <linearGradient id="phase2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#D4A853" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#D4A853" stopOpacity={0.05} />
                </linearGradient>
                <linearGradient id="phase3" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#4ADE80" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#4ADE80" stopOpacity={0.05} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" />
              <XAxis dataKey="month" tick={{ fill: '#64748B', fontSize: 11 }} axisLine={{ stroke: 'rgba(148,163,184,0.3)' }} />
              <YAxis tick={{ fill: '#64748B', fontSize: 11 }} axisLine={{ stroke: 'rgba(148,163,184,0.3)' }} domain={[0, 10000]} />
              <Tooltip content={<SCurveTooltip />} />
              {/* We show users as the main S-curve */}
              <Area type="monotone" dataKey="users" name="Users" stroke="#D4A853" strokeWidth={2.5} fill="url(#phase2)" />
              <ReferenceLine x={12} stroke="#60A5FA" strokeDasharray="3 3" label={{ value: 'Phase 1', fill: '#60A5FA', fontSize: 10, position: 'top' }} />
              <ReferenceLine x={30} stroke="#4ADE80" strokeDasharray="3 3" label={{ value: 'Phase 2', fill: '#4ADE80', fontSize: 10, position: 'top' }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Phase pills */}
        <div className="flex flex-wrap gap-3 mt-4 mb-5">
          {[
            { label: 'Phase 1', range: 'Months 1-12', name: 'Early Adoption', color: '#60A5FA', desc: 'Foundation & Learning' },
            { label: 'Phase 2', range: 'Months 13-30', name: 'Acceleration', color: '#D4A853', desc: 'Explosive Growth' },
            { label: 'Phase 3', range: 'Months 31-60', name: 'Expansion', color: '#4ADE80', desc: 'Ceiling Expansion' },
          ].map(phase => (
            <div key={phase.label} className="flex items-center gap-2 px-3 py-2 rounded-lg bg-bg-tertiary">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: phase.color }} />
              <div>
                <span className="text-label-sm text-text-tertiary">{phase.label} · {phase.range}</span>
                <div className="text-body-sm text-text-primary font-medium">{phase.name}</div>
              </div>
            </div>
          ))}
        </div>

        {/* S-Curve Table */}
        <div className="overflow-x-auto mb-5">
          <table className="w-full">
            <thead>
              <tr className="bg-bg-tertiary">
                {['Phase','Months','Users','Rate','Narrative'].map(h => (
                  <th key={h} className="text-label-sm text-text-tertiary text-left px-3 py-3 font-medium tracking-wider">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {scurvePhases.map((phase, i) => (
                <motion.tr
                  key={phase.phase}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.06, duration: 0.3, ease: cardEase }}
                  className="border-b border-bg-quaternary"
                  style={{ height: '48px' }}
                >
                  <td className="px-3 text-body-md text-text-primary font-medium">{phase.phase}</td>
                  <td className="px-3 text-mono-sm text-text-secondary">{phase.months}</td>
                  <td className="px-3 text-mono-sm text-accent-primary">{phase.users}</td>
                  <td className="px-3">
                    <span className={`inline-block px-2 py-0.5 rounded text-label-sm ${
                      phase.rate === 'Slow' ? 'bg-accent-info-muted text-accent-info' :
                      phase.rate === 'Fast' ? 'bg-accent-secondary-muted text-accent-secondary' :
                      'bg-accent-primary-muted text-accent-primary'
                    }`}>
                      {phase.rate}
                    </span>
                  </td>
                  <td className="px-3 text-body-sm text-text-secondary">{phase.narrative}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Expandable Narratives */}
        <div className="space-y-2">
          <ExpandableSection title="Early Adoption Phase" defaultOpen>
            <ul className="space-y-2 text-body-md text-text-secondary">
              <li className="flex items-start gap-2">
                <Users className="w-4 h-4 text-accent-info mt-0.5 flex-shrink-0" />
                Champions and early adopters (10-15% of workforce) demonstrate value through concrete use cases
              </li>
              <li className="flex items-start gap-2">
                <Target className="w-4 h-4 text-accent-info mt-0.5 flex-shrink-0" />
                Use case library develops organically from pilot team successes
              </li>
              <li className="flex items-start gap-2">
                <Zap className="w-4 h-4 text-accent-info mt-0.5 flex-shrink-0" />
                IT establishes support infrastructure and governance framework
              </li>
            </ul>
          </ExpandableSection>
          <ExpandableSection title="Acceleration Phase">
            <ul className="space-y-2 text-body-md text-text-secondary">
              <li className="flex items-start gap-2">
                <Users className="w-4 h-4 text-accent-primary mt-0.5 flex-shrink-0" />
                Majority adoption triggered by peer proof points and visible productivity gains
              </li>
              <li className="flex items-start gap-2">
                <TrendingUp className="w-4 h-4 text-accent-primary mt-0.5 flex-shrink-0" />
                Network effects: more users = more shared prompts = more organizational value
              </li>
              <li className="flex items-start gap-2">
                <ArrowUpRight className="w-4 h-4 text-accent-primary mt-0.5 flex-shrink-0" />
                Management mandates and performance incentives drive remaining holdouts
              </li>
            </ul>
          </ExpandableSection>
          <ExpandableSection title="Expansion Phase">
            <ul className="space-y-2 text-body-md text-text-secondary">
              <li className="flex items-start gap-2">
                <Zap className="w-4 h-4 text-accent-secondary mt-0.5 flex-shrink-0" />
                Ceiling rises as Copilot capabilities expand with autonomous agent deployment
              </li>
              <li className="flex items-start gap-2">
                <Activity className="w-4 h-4 text-accent-secondary mt-0.5 flex-shrink-0" />
                Autonomous agents multiply per-user value beyond simple productivity gains
              </li>
              <li className="flex items-start gap-2">
                <TrendingUp className="w-4 h-4 text-accent-secondary mt-0.5 flex-shrink-0" />
                Pre-Singularity alignment: intelligence amplification across the enterprise
              </li>
            </ul>
          </ExpandableSection>
        </div>

        {/* Strategic Interpretation */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.5, ease: cardEase }}
          className="mt-5 bg-accent-primary-muted rounded-lg p-5 border border-accent-primary/20"
        >
          <h4 className="text-heading-md text-accent-primary mb-3">Strategic Interpretation</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {[
              { label: 'Rising Ceiling', desc: 'Each Copilot update expands the value frontier — the ceiling is not fixed' },
              { label: 'Explosive Middle', desc: 'Months 18-30 deliver the steepest value growth as adoption compounds' },
              { label: 'Non-Plateauing Plateau', desc: 'Unlike typical S-curves, AI capability growth prevents true saturation' },
              { label: 'Kurzweil Alignment', desc: 'Exponential technology adoption follows the Law of Accelerating Returns' },
            ].map(item => (
              <div key={item.label} className="flex items-start gap-2">
                <ArrowUpRight className="w-4 h-4 text-accent-primary mt-0.5 flex-shrink-0" />
                <div>
                  <span className="text-body-sm text-accent-primary font-medium">{item.label}: </span>
                  <span className="text-body-sm text-text-secondary">{item.desc}</span>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </DataCard>

      {/* ====== YEARLY S-CURVE TABLE ====== */}
      <DataCard title="Annual Adoption Potential" subtitle="Users and maximum potential ceiling">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-bg-tertiary">
                {['Year','Users','Max Potential','Capacity Used','Growth'].map(h => (
                  <th key={h} className="text-label-sm text-text-tertiary text-left px-3 py-3 font-medium tracking-wider">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {yearlyScurve.map((row, i) => {
                const pct = ((row.users / row.maxPotential) * 100).toFixed(0);
                const prevUsers = i > 0 ? yearlyScurve[i - 1].users : row.users;
                const growth = i > 0 ? (((row.users - prevUsers) / prevUsers) * 100).toFixed(0) : '-';
                return (
                  <motion.tr
                    key={row.year}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.06, duration: 0.3, ease: cardEase }}
                    className={`border-b border-bg-quaternary ${i % 2 === 0 ? 'bg-bg-primary' : 'bg-bg-secondary'}`}
                    style={{ height: '48px' }}
                  >
                    <td className="px-3 text-body-md text-text-primary font-medium">{row.year}</td>
                    <td className="px-3 text-mono-sm text-accent-primary">{row.users.toLocaleString()}</td>
                    <td className="px-3 text-mono-sm text-text-secondary">{row.maxPotential.toLocaleString()}</td>
                    <td className="px-3">
                      <div className="flex items-center gap-2">
                        <div className="w-20 h-2 bg-bg-quaternary rounded-full overflow-hidden">
                          <div className="h-full rounded-full bg-gradient-to-r from-accent-primary to-accent-secondary" style={{ width: `${pct}%` }} />
                        </div>
                        <span className="text-mono-sm text-text-secondary">{pct}%</span>
                      </div>
                    </td>
                    <td className="px-3 text-mono-sm text-accent-secondary">{growth !== '-' ? `+${growth}%` : '-'}</td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </DataCard>

      {/* ====== ROADMAP TIMELINE ====== */}
      <DataCard title="Enterprise AI Roadmap: 2025 — 2030" subtitle="From AI adoption to pre-Singularity enterprise architecture">
        <div className="relative">
          {/* Timeline track */}
          <div className="absolute top-6 left-0 right-0 h-0.5 bg-bg-quaternary" />
          <div className="grid grid-cols-5 gap-4 relative">
            {roadmapMilestones.map((m, i) => (
              <motion.div
                key={m.year}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1, duration: 0.4, ease: cardEase }}
                className="relative pt-8 text-center"
              >
                {/* Dot */}
                <div
                  className="absolute top-4 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full border-2 border-bg-primary z-10"
                  style={{ backgroundColor: m.color }}
                />
                {/* Era marker */}
                <div className="text-label-sm font-medium mb-1" style={{ color: m.color }}>{m.year}</div>
                <div className="text-body-sm text-text-primary font-medium">{m.milestone}</div>
                <div className="text-body-sm text-text-tertiary mt-1">{m.capability}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </DataCard>
    </div>
  );
}
