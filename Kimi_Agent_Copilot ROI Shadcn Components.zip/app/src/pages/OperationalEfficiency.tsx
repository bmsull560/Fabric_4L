import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Truck,
  TrendingUp,
  Headset,
  Shield,
  ChevronDown,
  ChevronUp,
  Wrench,
  Zap,
  BarChart3,
  PieChart,
  DollarSign,
  Clock,
  Users,
} from 'lucide-react';
import {
  PieChart as RePieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ComposedChart,
} from 'recharts';
import KpiCard from '@/components/KpiCard';
import DataCard from '@/components/DataCard';
import NumberAnimation from '@/components/NumberAnimation';

const cardEasing = [0.22, 1, 0.36, 1] as [number, number, number, number];

/* ──────────────────────── DATA ──────────────────────── */

const driverCategories = [
  {
    id: 'field',
    icon: Truck,
    iconColor: 'text-accent-primary',
    iconBg: 'bg-accent-primary-muted',
    title: 'Field Operations',
    metric: '18% truck roll reduction',
    dollar: '$8.4M/year',
    gauge: 18,
    gaugeColor: '#D4A853',
    details: [
      'Pre-trip planning automation: 12 min saved per dispatch',
      'Real-time parts inventory lookup: 8 min saved per call',
      'Mobile documentation assistance: 15 min saved per work order',
    ],
  },
  {
    id: 'trading',
    icon: TrendingUp,
    iconColor: 'text-[#60A5FA]',
    iconBg: 'bg-[rgba(96,165,250,0.15)]',
    title: 'Energy Trading & Load Forecasting',
    metric: '23% margin improvement',
    dollar: '$6.2M/year',
    gauge: 23,
    gaugeColor: '#60A5FA',
    details: [
      'Real-time market data synthesis: faster position decisions',
      'Load forecast accuracy: 8% improvement via pattern recognition',
      'Regulatory filing prep: 40% time reduction',
    ],
  },
  {
    id: 'cs',
    icon: Headset,
    iconColor: 'text-accent-secondary',
    iconBg: 'bg-accent-secondary-muted',
    title: 'Customer Service',
    metric: '31% AHT reduction',
    dollar: '$4.8M/year',
    gauge: 31,
    gaugeColor: '#4ADE80',
    details: [
      'Average handle time: 8.2 min → 5.7 min',
      'First-call resolution: 68% → 79%',
      'Agent satisfaction score: +18 points',
    ],
  },
  {
    id: 'it',
    icon: Shield,
    iconColor: 'text-[#A78BFA]',
    iconBg: 'bg-[rgba(167,139,250,0.15)]',
    title: 'IT / Cybersecurity',
    metric: '42% incident response acceleration',
    dollar: '$2.7M/year',
    gauge: 42,
    gaugeColor: '#A78BFA',
    details: [
      'Threat analysis automation: 35 min saved per incident',
      'Documentation & compliance: 22 min saved per ticket',
      'Code review acceleration: 28% faster deployments',
    ],
  },
];

const pieData = [
  { name: 'IT Workers', value: 36.2, color: '#60A5FA' },
  { name: 'Corporate Knowledge', value: 40.9, color: '#D4A853' },
  { name: 'Field Technicians', value: 14.8, color: '#4ADE80' },
  { name: 'Customer Service', value: 5.5, color: '#F472B6' },
  { name: 'Adoption Reserve', value: 2.6, color: '#64748B' },
];

const barData = [
  {
    name: 'Conservative',
    Productivity: 57.1,
    Revenue: 9.0,
    Operational: 17.7,
    Customer: 4.2,
  },
  {
    name: 'Base Case',
    Productivity: 69.9,
    Revenue: 12.9,
    Operational: 22.1,
    Customer: 4.8,
  },
  {
    name: 'High Case',
    Productivity: 80.6,
    Revenue: 16.3,
    Operational: 25.4,
    Customer: 5.5,
  },
];

const modelTableRows = [
  {
    category: 'Truck Rolls',
    items: [
      { metric: 'Avg cost per roll', current: '$285', copilot: '$285', improvement: '—', annualValue: '—', confidence: 'High' as const },
      { metric: 'Rolls per month', current: '4,200', copilot: '3,444', improvement: '-18%', annualValue: '$2.59M', confidence: 'High' as const },
      { metric: 'Planning time/roll', current: '22 min', copilot: '10 min', improvement: '-55%', annualValue: '$1.86M', confidence: 'High' as const },
      { metric: 'Total truck roll value', current: '', copilot: '', improvement: '', annualValue: '$8.40M', confidence: 'High' as const, isTotal: true },
    ],
    color: '#D4A853',
  },
  {
    category: 'Outage Restoration',
    items: [
      { metric: 'Avg restoration time', current: '187 min', copilot: '154 min', improvement: '-18%', annualValue: '$2.10M', confidence: 'Medium' as const },
      { metric: 'Customer-minutes saved', current: '2.1M/mo', copilot: '2.8M/mo', improvement: '+33%', annualValue: '$1.20M', confidence: 'Medium' as const },
      { metric: 'Dispatch efficiency', current: 'Baseline', copilot: '+15%', improvement: '', annualValue: '$0.80M', confidence: 'Medium' as const },
      { metric: 'Total outage value', current: '', copilot: '', improvement: '', annualValue: '$4.10M', confidence: 'Medium' as const, isTotal: true },
    ],
    color: '#4ADE80',
  },
  {
    category: 'Customer Service',
    items: [
      { metric: 'AHT', current: '8.2 min', copilot: '5.7 min', improvement: '-31%', annualValue: '$2.40M', confidence: 'High' as const },
      { metric: 'Escalation rate', current: '24%', copilot: '16%', improvement: '-33%', annualValue: '$1.20M', confidence: 'Medium' as const },
      { metric: 'Training time/new hire', current: '80 hrs', copilot: '48 hrs', improvement: '-40%', annualValue: '$0.72M', confidence: 'Medium' as const },
      { metric: 'Total CS value', current: '', copilot: '', improvement: '', annualValue: '$4.32M', confidence: 'High' as const, isTotal: true },
    ],
    color: '#F472B6',
  },
  {
    category: 'Energy Trading',
    items: [
      { metric: 'Decision latency', current: '45 min', copilot: '22 min', improvement: '-51%', annualValue: '$1.80M', confidence: 'Medium' as const },
      { metric: 'Forecast accuracy', current: '91%', copilot: '98%', improvement: '+7pp', annualValue: '$2.40M', confidence: 'Medium' as const },
      { metric: 'Filing prep time', current: '12 hrs', copilot: '5 hrs', improvement: '-58%', annualValue: '$0.90M', confidence: 'High' as const },
      { metric: 'Total trading value', current: '', copilot: '', improvement: '', annualValue: '$5.10M', confidence: 'Medium' as const, isTotal: true },
    ],
    color: '#60A5FA',
  },
];

const roiSummaryRows = [
  { category: 'Productivity (time savings)', value: 69.9, pct: 70.0, confidence: 'High' as const },
  { category: 'Operational Efficiency', value: 22.1, pct: 27.0, confidence: 'High' as const },
  { category: 'Customer Service Improvement', value: 4.8, pct: 5.8, confidence: 'High' as const },
  { category: 'Trading Optimization', value: 6.2, pct: 7.6, confidence: 'Medium' as const },
];

const donutColors = ['#D4A853', '#4ADE80', '#60A5FA', '#A78BFA'];

/* ──────────────────────── MINI GAUGE ──────────────────────── */

function MiniGauge({ value, color }: { value: number; color: string }) {
  const radius = 36;
  const circumference = 2 * Math.PI * radius;
  const strokeDash = (value / 100) * circumference;

  return (
    <div className="relative w-20 h-20 flex items-center justify-center">
      <svg className="w-20 h-20 -rotate-90" viewBox="0 0 80 80">
        <circle
          cx="40"
          cy="40"
          r={radius}
          fill="none"
          stroke="#232D42"
          strokeWidth="6"
        />
        <motion.circle
          cx="40"
          cy="40"
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth="6"
          strokeLinecap="round"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: circumference - strokeDash }}
          transition={{ duration: 1.2, ease: cardEasing }}
        />
      </svg>
      <span className="absolute text-mono-sm font-semibold text-text-primary">
        {value}%
      </span>
    </div>
  );
}

/* ──────────────────────── CUSTOM TOOLTIP ──────────────────────── */

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload) return null;
  return (
    <div className="bg-bg-secondary border border-bg-quaternary rounded-lg p-3 shadow-xl">
      <p className="text-body-sm font-medium text-text-primary mb-1">{label}</p>
      {payload.map((entry: any, i: number) => (
        <p key={i} className="text-body-sm" style={{ color: entry.color }}>
          {entry.name}: ${entry.value}M
        </p>
      ))}
    </div>
  );
}

function PieTooltip({ active, payload }: any) {
  if (!active || !payload?.length) return null;
  const p = payload[0];
  return (
    <div className="bg-bg-secondary border border-bg-quaternary rounded-lg p-3 shadow-xl">
      <p className="text-body-sm font-medium text-text-primary">{p.name}</p>
      <p className="text-mono-sm" style={{ color: p.payload.color }}>
        {p.value}%
      </p>
    </div>
  );
}

/* ──────────────────────── CONFIDENCE BADGE ──────────────────────── */

function ConfidenceBadge({ level }: { level: 'High' | 'Medium' | 'Developing' }) {
  const colors =
    level === 'High'
      ? 'text-accent-secondary bg-accent-secondary-muted'
      : level === 'Medium'
        ? 'text-accent-primary bg-accent-primary-muted'
        : 'text-text-tertiary bg-bg-tertiary';
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-md text-label-sm ${colors}`}>
      {level}
    </span>
  );
}

/* ═══════════════════════════ PAGE ═══════════════════════════ */

export default function OperationalEfficiency() {
  const [expandedDrivers, setExpandedDrivers] = useState<Record<string, boolean>>({});

  const toggleDriver = (id: string) => {
    setExpandedDrivers((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div>
      {/* ── Page Header ── */}
      <div className="px-8 py-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: cardEasing }}
        >
          <div className="flex items-center gap-3 mb-2">
            <Wrench className="w-5 h-5 text-accent-primary" />
            <span className="text-label-lg text-text-tertiary">OPERATIONAL</span>
          </div>
          <h1 className="text-display-xl text-text-primary font-bold tracking-tight">
            Operational Efficiency
          </h1>
          <p className="text-body-lg text-text-secondary mt-2 max-w-3xl">
            Utility-sector operational value drivers. Field operations, energy trading,
            customer service, and IT/cybersecurity — all quantified with dollar impact.
          </p>
        </motion.div>
      </div>

      {/* ── KPI Strip ── */}
      <div className="px-8 pb-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <KpiCard
          icon={Zap}
          label="Total Operational Value"
          value={22.1}
          valuePrefix="$"
          valueSuffix="M"
          valueDecimals={1}
          trend={{ direction: 'positive', text: '+27% of total benefit' }}
          subtitle="Annual savings across all categories"
          index={0}
        />
        <KpiCard
          icon={Truck}
          label="Truck Roll Reduction"
          value={18}
          valueSuffix="%"
          subtitle="Largest operational category"
          trend={{ direction: 'positive', text: '$8.4M annual value' }}
          index={1}
        />
        <KpiCard
          icon={Clock}
          label="AHT Reduction"
          value={31}
          valueSuffix="%"
          subtitle="Customer service efficiency"
          trend={{ direction: 'positive', text: '$4.8M annual value' }}
          index={2}
        />
        <KpiCard
          icon={TrendingUp}
          label="Trading Margin"
          value={23}
          valueSuffix="%"
          subtitle="Energy trading optimization"
          trend={{ direction: 'positive', text: '$6.2M annual value' }}
          index={3}
        />
      </div>

      <div className="px-8 pb-8 space-y-5">
        {/* ── Utility-Sector Value Drivers ── */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1, ease: cardEasing }}
          className="bg-bg-secondary border border-bg-quaternary rounded-card p-6"
        >
          <div className="flex items-start justify-between mb-6">
            <div>
              <h2 className="text-heading-lg text-text-primary">Utility-Sector Value Drivers</h2>
              <p className="text-body-sm text-text-tertiary mt-1">
                Sector-specific operational improvements from Copilot deployment
              </p>
            </div>
            <span className="text-mono-lg text-accent-primary font-medium">
              <NumberAnimation value={22.1} prefix="$" suffix="M" decimals={1} />{' '}
              <span className="text-body-sm text-text-tertiary">annually</span>
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {driverCategories.map((cat, i) => {
              const Icon = cat.icon;
              const isExpanded = expandedDrivers[cat.id];
              return (
                <motion.div
                  key={cat.id}
                  initial={{ opacity: 0, y: 30, scale: 0.97 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  transition={{ duration: 0.5, delay: 0.12 * i, ease: cardEasing }}
                  className="bg-bg-primary border border-bg-quaternary rounded-card p-5 hover:border-bg-quaternary/80 transition-all duration-300"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4">
                      <div
                        className={`w-12 h-12 rounded-full ${cat.iconBg} flex items-center justify-center flex-shrink-0`}
                      >
                        <Icon className={`w-6 h-6 ${cat.iconColor}`} />
                      </div>
                      <div>
                        <h3 className="text-heading-md text-text-primary">{cat.title}</h3>
                        <p className="text-body-md text-accent-secondary mt-1">{cat.metric}</p>
                        <p className="text-mono-md text-accent-primary mt-1">{cat.dollar}</p>
                      </div>
                    </div>
                    <MiniGauge value={cat.gauge} color={cat.gaugeColor} />
                  </div>

                  <button
                    onClick={() => toggleDriver(cat.id)}
                    className="flex items-center gap-1 mt-4 text-body-sm text-text-tertiary hover:text-text-primary transition-colors"
                  >
                    {isExpanded ? (
                      <>
                        Hide details <ChevronUp className="w-4 h-4" />
                      </>
                    ) : (
                      <>
                        Show details <ChevronDown className="w-4 h-4" />
                      </>
                    )}
                  </button>

                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.25 }}
                        className="overflow-hidden"
                      >
                        <ul className="mt-3 space-y-2">
                          {cat.details.map((d, j) => (
                            <li key={j} className="flex items-start gap-2 text-body-sm text-text-secondary">
                              <span className="w-1 h-1 rounded-full bg-accent-primary mt-2 flex-shrink-0" />
                              {d}
                            </li>
                          ))}
                        </ul>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* ── Operational Efficiency Model Table ── */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3, ease: cardEasing }}
        >
          <DataCard
            title="Operational Efficiency Model — Detailed Calculations"
            subtitle="Interactive table with quantified impacts per operational category"
          >
            <div className="overflow-x-auto mt-4">
              <table className="w-full">
                <thead>
                  <tr className="bg-bg-tertiary">
                    <th className="text-label-sm text-text-tertiary text-left px-4 py-3">Category</th>
                    <th className="text-label-sm text-text-tertiary text-left px-4 py-3">Metric</th>
                    <th className="text-label-sm text-text-tertiary text-right px-4 py-3">Current</th>
                    <th className="text-label-sm text-text-tertiary text-right px-4 py-3">Copilot</th>
                    <th className="text-label-sm text-text-tertiary text-right px-4 py-3">Improvement</th>
                    <th className="text-label-sm text-text-tertiary text-right px-4 py-3">Annual Value</th>
                    <th className="text-label-sm text-text-tertiary text-center px-4 py-3">Confidence</th>
                  </tr>
                </thead>
                <tbody>
                  {modelTableRows.map((row, ri) =>
                    row.items.map((item, ii) => {
                      const isTotal = item.isTotal;
                      return (
                        <motion.tr
                          key={`${ri}-${ii}`}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.3, delay: ri * 0.04 + ii * 0.04 }}
                          className={`border-b border-bg-quaternary ${isTotal ? 'bg-bg-tertiary/50 font-semibold' : 'hover:bg-bg-tertiary/30'} transition-colors`}
                        >
                          {ii === 0 ? (
                            <td
                              className="px-4 py-3 text-body-md text-text-primary font-medium border-l-[3px]"
                              style={{ borderLeftColor: row.color }}
                              rowSpan={row.items.length}
                            >
                              {row.category}
                            </td>
                          ) : null}
                          <td className={`px-4 py-3 text-body-md ${isTotal ? 'text-text-primary' : 'text-text-secondary'}`}>
                            {item.metric}
                          </td>
                          <td className="px-4 py-3 text-mono-sm text-text-secondary text-right">
                            {item.current}
                          </td>
                          <td className="px-4 py-3 text-mono-sm text-accent-primary text-right">
                            {item.copilot}
                          </td>
                          <td className="px-4 py-3 text-mono-sm text-accent-secondary text-right">
                            {item.improvement}
                          </td>
                          <td className="px-4 py-3 text-mono-sm text-text-primary text-right font-medium">
                            {item.annualValue}
                          </td>
                          <td className="px-4 py-3 text-center">
                            {!isTotal && <ConfidenceBadge level={item.confidence} />}
                          </td>
                        </motion.tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Summary bar */}
            <div className="mt-6 bg-bg-tertiary rounded-lg p-4 flex flex-wrap items-center gap-6">
              <div>
                <span className="text-label-sm text-text-tertiary">Total Annual Operational Value</span>
                <span className="text-mono-lg text-accent-primary ml-3">
                  <NumberAnimation value={22.1} prefix="$" suffix="M" decimals={1} />
                </span>
              </div>
              <div>
                <span className="text-label-sm text-text-tertiary">As % of total benefit</span>
                <span className="text-mono-md text-text-primary ml-3">27%</span>
              </div>
              <div>
                <span className="text-label-sm text-text-tertiary">Weighted confidence</span>
                <span className="ml-3">
                  <ConfidenceBadge level="High" />
                </span>
              </div>
            </div>
          </DataCard>
        </motion.div>

        {/* ── Productivity Gain Distribution (Pie) + Annual Financial Impact (Bar) ── */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Pie Chart */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4, ease: cardEasing }}
          >
            <DataCard
              title="Productivity Gain Distribution"
              subtitle="Share of productivity gains by workforce segment"
            >
              <div className="h-72 mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <RePieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={3}
                      dataKey="value"
                      animationBegin={300}
                      animationDuration={800}
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip content={<PieTooltip />} />
                    <Legend
                      verticalAlign="bottom"
                      iconType="circle"
                      iconSize={8}
                      formatter={(value: string) => (
                        <span className="text-body-sm text-text-secondary ml-1">{value}</span>
                      )}
                    />
                  </RePieChart>
                </ResponsiveContainer>
              </div>
              <div className="text-center mt-2">
                <p className="text-body-sm text-text-tertiary">Adoption Reserve (2.6%) represents unrealized potential</p>
              </div>
            </DataCard>
          </motion.div>

          {/* Bar Chart */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.48, ease: cardEasing }}
          >
            <DataCard
              title="Annual Financial Impact"
              subtitle="Scenario comparison across benefit categories"
            >
              <div className="h-72 mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={barData} barCategoryGap="20%">
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.12)" />
                    <XAxis
                      dataKey="name"
                      tick={{ fill: '#94A3B8', fontSize: 12 }}
                      axisLine={{ stroke: 'rgba(148,163,184,0.3)' }}
                    />
                    <YAxis
                      tick={{ fill: '#94A3B8', fontSize: 12 }}
                      axisLine={{ stroke: 'rgba(148,163,184,0.3)' }}
                      tickFormatter={(v) => `$${v}M`}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend
                      iconType="square"
                      iconSize={8}
                      formatter={(value: string) => (
                        <span className="text-body-sm text-text-secondary ml-1">{value}</span>
                      )}
                    />
                    <Bar dataKey="Productivity" stackId="a" fill="#D4A853" radius={[0, 0, 0, 0]} />
                    <Bar dataKey="Revenue" stackId="a" fill="#60A5FA" radius={[0, 0, 0, 0]} />
                    <Bar dataKey="Operational" stackId="a" fill="#4ADE80" radius={[0, 0, 0, 0]} />
                    <Bar dataKey="Customer" stackId="a" fill="#F472B6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="flex items-center gap-2 mt-2">
                <DollarSign className="w-4 h-4 text-accent-tertiary" />
                <p className="text-body-sm text-accent-tertiary">
                  Cost overlay: $2.88M annual investment threshold
                </p>
              </div>
            </DataCard>
          </motion.div>
        </div>

        {/* ── Final ROI Summary ── */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.56, ease: cardEasing }}
          className="grid grid-cols-1 lg:grid-cols-3 gap-5"
        >
          <div className="lg:col-span-2">
            <DataCard
              title="Final ROI Summary — Utility Sector"
              subtitle="Comprehensive breakdown of total annual benefit"
            >
              <div className="overflow-x-auto mt-4">
                <table className="w-full">
                  <thead>
                    <tr className="bg-bg-tertiary">
                      <th className="text-label-sm text-text-tertiary text-left px-4 py-3">Category</th>
                      <th className="text-label-sm text-text-tertiary text-right px-4 py-3">Annual Value</th>
                      <th className="text-label-sm text-text-tertiary text-right px-4 py-3">% of Total</th>
                      <th className="text-label-sm text-text-tertiary text-center px-4 py-3">Confidence</th>
                    </tr>
                  </thead>
                  <tbody>
                    {roiSummaryRows.map((row, i) => (
                      <motion.tr
                        key={row.category}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.6 + i * 0.05 }}
                        className="border-b border-bg-quaternary hover:bg-bg-tertiary/30 transition-colors"
                      >
                        <td className="px-4 py-3 text-body-md text-text-secondary">{row.category}</td>
                        <td className="px-4 py-3 text-mono-sm text-text-primary text-right">
                          ${row.value}M
                        </td>
                        <td className="px-4 py-3 text-mono-sm text-text-secondary text-right">
                          {row.pct}%
                        </td>
                        <td className="px-4 py-3 text-center">
                          <ConfidenceBadge level={row.confidence} />
                        </td>
                      </motion.tr>
                    ))}
                    {/* Totals */}
                    <tr className="bg-bg-tertiary/50 font-semibold">
                      <td className="px-4 py-3 text-body-md text-text-primary">TOTAL BENEFIT</td>
                      <td className="px-4 py-3 text-mono-sm text-accent-primary text-right">$103.0M</td>
                      <td className="px-4 py-3" />
                      <td className="px-4 py-3" />
                    </tr>
                    <tr className="bg-bg-tertiary/50 font-semibold">
                      <td className="px-4 py-3 text-body-md text-text-primary">TOTAL COST</td>
                      <td className="px-4 py-3 text-mono-sm text-accent-tertiary text-right">$2.88M</td>
                      <td className="px-4 py-3" />
                      <td className="px-4 py-3" />
                    </tr>
                    <tr className="bg-bg-tertiary/50 font-semibold">
                      <td className="px-4 py-3 text-body-md text-text-primary">NET BENEFIT</td>
                      <td className="px-4 py-3 text-mono-sm text-accent-secondary text-right">$100.1M</td>
                      <td className="px-4 py-3" />
                      <td className="px-4 py-3" />
                    </tr>
                    <tr className="bg-bg-tertiary/50 font-semibold">
                      <td className="px-4 py-3 text-body-md text-accent-primary">ROI</td>
                      <td className="px-4 py-3 text-mono-sm text-accent-primary text-right">3,375%</td>
                      <td className="px-4 py-3" />
                      <td className="px-4 py-3" />
                    </tr>
                  </tbody>
                </table>
              </div>
              <p className="text-body-sm text-text-tertiary mt-3">
                Note: Customer service and trading values overlap with operational; net unique benefit approximately $81.8M.
              </p>

              {/* Adjusted summary */}
              <div className="mt-4 border-t border-bg-quaternary pt-4">
                <h4 className="text-heading-md text-text-primary mb-2">Adjusted (Non-Overlapping) Summary</h4>
                <div className="grid grid-cols-2 gap-2">
                  <div className="flex justify-between px-4 py-2 bg-bg-tertiary/30 rounded">
                    <span className="text-body-sm text-text-secondary">Total Annual Benefit (unique)</span>
                    <span className="text-mono-sm text-text-primary font-medium">$81.8M</span>
                  </div>
                  <div className="flex justify-between px-4 py-2 bg-bg-tertiary/30 rounded">
                    <span className="text-body-sm text-text-secondary">Total Annual Cost</span>
                    <span className="text-mono-sm text-accent-tertiary font-medium">$2.88M</span>
                  </div>
                  <div className="flex justify-between px-4 py-2 bg-bg-tertiary/30 rounded">
                    <span className="text-body-sm text-text-secondary">Net Annual Benefit</span>
                    <span className="text-mono-sm text-accent-secondary font-medium">$78.9M</span>
                  </div>
                  <div className="flex justify-between px-4 py-2 bg-bg-tertiary/30 rounded">
                    <span className="text-body-sm text-text-secondary">ROI</span>
                    <span className="text-mono-sm text-accent-primary font-medium">2,836%</span>
                  </div>
                </div>
              </div>
            </DataCard>
          </div>

          {/* Donut Chart for Benefit Composition */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.64, ease: cardEasing }}
          >
            <DataCard
              title="Benefit Composition"
              subtitle="Proportional breakdown of total value"
            >
              <div className="h-64 mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <RePieChart>
                    <Pie
                      data={[
                        { name: 'Productivity', value: 70 },
                        { name: 'Operational', value: 22 },
                        { name: 'Customer Service', value: 5 },
                        { name: 'Trading', value: 7 },
                      ]}
                      cx="50%"
                      cy="50%"
                      innerRadius={55}
                      outerRadius={90}
                      paddingAngle={3}
                      dataKey="value"
                      animationBegin={500}
                      animationDuration={800}
                    >
                      {donutColors.map((color, index) => (
                        <Cell key={`cell-${index}`} fill={color} />
                      ))}
                    </Pie>
                    <Tooltip content={<PieTooltip />} />
                    <Legend
                      verticalAlign="bottom"
                      iconType="circle"
                      iconSize={8}
                      formatter={(value: string) => (
                        <span className="text-body-sm text-text-secondary ml-1">{value}</span>
                      )}
                    />
                  </RePieChart>
                </ResponsiveContainer>
              </div>
              <div className="text-center mt-2">
                <span className="text-mono-md text-accent-primary">$103.0M</span>
                <p className="text-body-sm text-text-tertiary">Total Annual Benefit</p>
              </div>
            </DataCard>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
