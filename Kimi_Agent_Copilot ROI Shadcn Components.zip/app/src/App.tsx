import { HashRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import ExecutiveOverview from './pages/ExecutiveOverview';
import ROIModel from './pages/ROIModel';
import Workforce from './pages/Workforce';
import OperationalEfficiency from './pages/OperationalEfficiency';
import MonteCarlo from './pages/MonteCarlo';
import SensitivityRisk from './pages/SensitivityRisk';
import RealOptions from './pages/RealOptions';
import GrowthTrajectory from './pages/GrowthTrajectory';
import ExponentialModel from './pages/ExponentialModel';
import MaturityModel from './pages/MaturityModel';
import EnterpriseArchitecture from './pages/EnterpriseArchitecture';
import Regulatory from './pages/Regulatory';
import BoardBriefing from './pages/BoardBriefing';
import Implementation from './pages/Implementation';

function App() {
  return (
    <HashRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<ExecutiveOverview />} />
          <Route path="/roi-model" element={<ROIModel />} />
          <Route path="/workforce" element={<Workforce />} />
          <Route path="/operational" element={<OperationalEfficiency />} />
          <Route path="/monte-carlo" element={<MonteCarlo />} />
          <Route path="/sensitivity-risk" element={<SensitivityRisk />} />
          <Route path="/real-options" element={<RealOptions />} />
          <Route path="/growth-trajectory" element={<GrowthTrajectory />} />
          <Route path="/exponential" element={<ExponentialModel />} />
          <Route path="/maturity" element={<MaturityModel />} />
          <Route path="/architecture" element={<EnterpriseArchitecture />} />
          <Route path="/regulatory" element={<Regulatory />} />
          <Route path="/board" element={<BoardBriefing />} />
          <Route path="/implementation" element={<Implementation />} />
        </Routes>
      </Layout>
    </HashRouter>
  );
}

export default App;
